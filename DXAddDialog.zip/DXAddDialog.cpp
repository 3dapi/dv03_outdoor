//-----------------------------------------------------------------------------
// File: DXAddDialog.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"
#include "DXAddDialog.h"



CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;



INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMyD3DApplication d3dApp;
	
	g_pApp  = &d3dApp;
	g_hInst = hInst;
	
	InitCommonControls();
	if( FAILED( d3dApp.Create( hInst ) ) )
		return 0;
	
	return d3dApp.Run();
}





CMyD3DApplication::CMyD3DApplication()
{
	m_strWindowTitle            = TEXT( "DXAddDialog" );
	m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;
	
	m_pD3DXFont                 = NULL;
	m_bLoadingApp               = TRUE;
	
	m_hTool		= 0;
	m_hPnnl	=0;
}


CMyD3DApplication::~CMyD3DApplication()
{
}


HRESULT CMyD3DApplication::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	
	m_bLoadingApp = FALSE;
	
	return S_OK;
}



HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
										 D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
	UNREFERENCED_PARAMETER( dwBehavior );
	UNREFERENCED_PARAMETER( pCaps );
	
	BOOL bCapsAcceptable;
	
	// TODO: Perform checks to see if these display caps are acceptable.
	bCapsAcceptable = TRUE;
	
	if( bCapsAcceptable )         
		return S_OK;
	else
		return E_FAIL;
}



HRESULT CMyD3DApplication::InitDeviceObjects()
{
	// TODO: create device objects
	
	m_hTool = CreateDialog( (HINSTANCE)GetModuleHandle(NULL)
		,	MAKEINTRESOURCE(IDD_DLG_TOOL),
		,	this->m_hWnd
		,	DialogProc);
	
	
	::ShowWindow(m_hTool, SW_SHOW);
	m_hPnnl = GetDlgItem(m_hTool, IDC_PANNEL);
	
	return S_OK;
}




HRESULT CMyD3DApplication::RestoreDeviceObjects()
{

	LOGFONT hFont = { 20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
		ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
		ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" };

	if( FAILED( D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
		return -1;





	if(this->m_bWindowed)
	{
		m_SpW.hW = m_hPnnl;
		
		D3DPRESENT_PARAMETERS	par;
		memset(&par, 0, sizeof(D3DPRESENT_PARAMETERS));
		
		par.SwapEffect = D3DSWAPEFFECT_DISCARD;
		par.Windowed = TRUE;
		par.BackBufferHeight= 0;
		par.BackBufferWidth = 0;
		par.hDeviceWindow = m_SpW.hW;
		
		if( FAILED(m_pd3dDevice->CreateAdditionalSwapChain(&par, &m_SpW.pC)) )
			return -1;		// Create addtional swap chain failed
		
		if( FAILED(m_SpW.pC->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &m_SpW.pB)) )
			return -1;		// Get back buffer Failed
		
		if ( FAILED(m_pd3dDevice->CreateDepthStencilSurface(par.BackBufferWidth
			, par.BackBufferHeight
			, m_d3dpp.AutoDepthStencilFormat
			, D3DMULTISAMPLE_NONE, 0, 0, &m_SpW.pS, NULL)))
			return -1;
	}
	
	return S_OK;
}




HRESULT CMyD3DApplication::FrameMove()
{
	
	if(this->m_bWindowed)
	{
		LPDIRECT3DSURFACE9		pTOrg=NULL;
		LPDIRECT3DSURFACE9		pSOrg=NULL;
		
		m_pd3dDevice->GetRenderTarget(0, &pTOrg);
		m_pd3dDevice->GetDepthStencilSurface(&pSOrg);
		
		
		
		m_pd3dDevice->SetRenderTarget(0, m_SpW.pB);
		m_pd3dDevice->SetDepthStencilSurface(m_SpW.pS);
		
		
		HRESULT hr;
		hr =m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,0x0000FFff, 1.0f, 0L );
		
		m_pd3dDevice->BeginScene();
		
		m_pd3dDevice->EndScene();
		
		m_SpW.pC->Present(0, 0, 0, 0, 0);
		
		m_pd3dDevice->SetRenderTarget(0, pTOrg);
		m_pd3dDevice->SetDepthStencilSurface(pSOrg);
		
		
		if(pTOrg)
			pTOrg->Release();
		
		if(pSOrg)
			pSOrg->Release();
	}
	
	return S_OK;
}




HRESULT CMyD3DApplication::Render()
{
	// Clear the viewport
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER,
		0x000000ff, 1.0f, 0L );
	
	// Begin the scene
	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
	{
		// TODO: render world
		
		// Render stats and help text  
		RenderText();
		
		// End the scene.
		m_pd3dDevice->EndScene();
	}
	
	return S_OK;
}



HRESULT CMyD3DApplication::RenderText()
{
	D3DCOLOR fontColor        = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rct;
	ZeroMemory( &rct, sizeof(rct) );       
	
	m_pD3DXFont->Begin();
	rct.left   = 2;
	rct.right  = m_d3dsdBackBuffer.Width - 20;
	
	// Output display stats
	INT nNextLine = 40; 
	
	lstrcpy( szMsg, m_strDeviceStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText( szMsg, -1, &rct, 0, fontColor );
	
	lstrcpy( szMsg, m_strFrameStats );
	nNextLine -= 20; rct.top = nNextLine; rct.bottom = rct.top + 20;    
	m_pD3DXFont->DrawText( szMsg, -1, &rct, 0, fontColor );
	
	m_pD3DXFont->End();
	
	return S_OK;
}




LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
								   LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				// Draw on the window tell the user that the app is loading
				// TODO: change as needed
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}
		
	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}



HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
	SAFE_RELEASE( m_pD3DXFont );

	m_SpW.Release();
	
	return S_OK;
}



HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
	DestroyWindow(m_hTool);
	
	return S_OK;
}



HRESULT CMyD3DApplication::FinalCleanup()
{
	return S_OK;
}








BOOL CALLBACK DialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM	wparHi;
	WPARAM	wparLo;
	
	wparHi = HIWORD(wParam);
	wparLo = LOWORD(wParam);
	
	switch( uMsg )
	{
	case WM_CLOSE:
		{
			MessageBox(0,0,0,0);
			break;
		}
	}
	
	return(FALSE);
}