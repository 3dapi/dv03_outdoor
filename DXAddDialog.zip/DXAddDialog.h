//-----------------------------------------------------------------------------
// File: DXAddDialog.h
//
// Desc: Header file DXAddDialog sample app
//-----------------------------------------------------------------------------
#pragma once




//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\DirectX AppWizard Apps\\DXAddDialog")

// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    BOOL bRotateUp;
    BOOL bRotateDown;
    BOOL bRotateLeft;
    BOOL bRotateRight;
};




BOOL CALLBACK DialogProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

struct LnSwpWn														// Swap chain window
{
	LPDIRECT3DSWAPCHAIN9	pC;													// Swap chain
	LPDIRECT3DSURFACE9		pB;													//Back buffer surface
	LPDIRECT3DSURFACE9		pS;													//Stencil buffer surface
	HWND					hW;													// Window Handle

	LnSwpWn() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

};


class CMyD3DApplication : public CD3DApplication
{
    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    ID3DXFont*              m_pD3DXFont;            // D3DX font    

	HWND					m_hTool;
	HWND					m_hPnnl;

	LnSwpWn					m_SpW;

protected:
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );
	
    HRESULT RenderText();
	

public:
    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();
    virtual ~CMyD3DApplication();
};

