//-----------------------------------------------------------------------------
// File: DXAddViewport.cpp
//
// Desc: DirectX window application created by the DirectX AppWizard
//-----------------------------------------------------------------------------
#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"
#include "DXAddViewport.h"




CMyD3DApplication* g_pApp  = NULL;
HINSTANCE          g_hInst = NULL;




INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMyD3DApplication d3dApp;

    g_pApp  = &d3dApp;
    g_hInst = hInst;

    InitCommonControls();
    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;

    return d3dApp.Run();
}




CMyD3DApplication::CMyD3DApplication()
{
    m_strWindowTitle            = TEXT( "DXAddViewport" );
    m_d3dEnumeration.AppUsesDepthBuffer   = TRUE;
	m_bStartFullscreen			= false;
	m_bShowCursorWhenFullscreen	= false;

    m_pD3DXFont                 = NULL;
    m_bLoadingApp               = TRUE;

}



CMyD3DApplication::~CMyD3DApplication()
{
}



HRESULT CMyD3DApplication::OneTimeSceneInit()
{
    SendMessage( m_hWnd, WM_PAINT, 0, 0 );

    m_bLoadingApp = FALSE;

    return S_OK;
}





HRESULT CMyD3DApplication::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
                                          D3DFORMAT Format )
{
    UNREFERENCED_PARAMETER( Format );
    UNREFERENCED_PARAMETER( dwBehavior );
    UNREFERENCED_PARAMETER( pCaps );
    
    BOOL bCapsAcceptable;

    // TODO: Perform checks to see if these display caps are acceptable.
    bCapsAcceptable = TRUE;

    if( bCapsAcceptable )         
        return S_OK;
    else
        return E_FAIL;
}




HRESULT CMyD3DApplication::InitDeviceObjects()
{
    // TODO: create device objects

    return S_OK;
}




HRESULT CMyD3DApplication::RestoreDeviceObjects()
{
    // Create a D3D font using D3DX
    LOGFONT hFont = { 20, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE,
                              ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
                              ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" };

    if( FAILED( D3DXCreateFontIndirect( m_pd3dDevice, &hFont, &m_pD3DXFont ) ) )
        return -1;


	m_VP[0].X	= 0;
	m_VP[0].Y	= 0;
	m_VP[0].Width = 298;
	m_VP[0].Height = m_d3dpp.BackBufferHeight;
	m_VP[0].MinZ = 0;
	m_VP[0].MaxZ = 1;
	
	m_VP[1].X	= 300;
	m_VP[1].Y	= 0;
	m_VP[1].Width = m_d3dpp.BackBufferWidth;
	m_VP[1].Height = 320-2;
	m_VP[1].MinZ = 0;
	m_VP[1].MaxZ = 1;

	m_VP[2].X	= 300;
	m_VP[2].Y	= 320;
	m_VP[2].Width = m_d3dpp.BackBufferWidth;
	m_VP[2].Height = m_d3dpp.BackBufferHeight;
	m_VP[2].MinZ = 0;
	m_VP[2].MaxZ = 1;

	m_VP[3].X	= 0;
	m_VP[3].Y	= 0;
	m_VP[3].Width = m_d3dpp.BackBufferWidth;
	m_VP[3].Height = m_d3dpp.BackBufferHeight;
	m_VP[3].MinZ = 0;
	m_VP[3].MaxZ = 1;


    return S_OK;
}




HRESULT CMyD3DApplication::FrameMove()
{
    return S_OK;
}




HRESULT CMyD3DApplication::Render()
{
	D3DCOLOR fontColor    = D3DCOLOR_ARGB(255,255,255,0);
	TCHAR szMsg[MAX_PATH] = TEXT("");
	RECT rct;
	ZeroMemory( &rct, sizeof(rct) );

	// Clear the viewport
	m_pd3dDevice->SetViewport(&(m_VP[3]));
	m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xAAAAAAAA, 1.0f, 0L );

	// Begin the scene
    if( FAILED( m_pd3dDevice->BeginScene() ) )
		return -1;

	{
		m_pd3dDevice->SetViewport(&(m_VP[0]));
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00006677, 1.0f, 0L );

		m_pD3DXFont->Begin();
		rct.left	= m_VP[0].X + 2;
		rct.right	= m_d3dsdBackBuffer.Width - 20;
		rct.top		= m_VP[0].Y + 2;
		rct.bottom	= rct.top + 20;

		sprintf(szMsg,"%s %s", m_strDeviceStats, m_strFrameStats);
		
		m_pD3DXFont->DrawText( szMsg, -1, &rct, 0, fontColor );

		m_pD3DXFont->End();
	}


	{
		m_pd3dDevice->SetViewport(&(m_VP[1]));
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00006699, 1.0f, 0L );
		
		m_pD3DXFont->Begin();
		rct.left	= m_VP[1].X + 2;
		rct.right	= m_d3dsdBackBuffer.Width - 20;
		rct.top		= m_VP[1].Y + 2;
		rct.bottom	= rct.top + 20;

		sprintf(szMsg,"%s %s", m_strDeviceStats, m_strFrameStats);
		
		m_pD3DXFont->DrawText( szMsg, -1, &rct, 0, fontColor );

		m_pD3DXFont->End();
	}

	{
		m_pd3dDevice->SetViewport(&(m_VP[2]));
		m_pd3dDevice->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00004466, 1.0f, 0L );

		m_pD3DXFont->Begin();
		rct.left	= m_VP[2].X + 2;
		rct.right	= m_d3dsdBackBuffer.Width - 20;
		rct.top		= m_VP[2].Y + 2;
		rct.bottom	= rct.top + 20;

		sprintf(szMsg,"%s %s", m_strDeviceStats, m_strFrameStats);
		
		m_pD3DXFont->DrawText( szMsg, -1, &rct, 0, fontColor );

		m_pD3DXFont->End();
	}

	// End the scene.
	m_pd3dDevice->EndScene();


    return S_OK;
}




HRESULT CMyD3DApplication::RenderText()
{
    

    return S_OK;
}



LRESULT CMyD3DApplication::MsgProc( HWND hWnd, UINT msg, WPARAM wParam,
                                    LPARAM lParam )
{
    switch( msg )
    {
        case WM_PAINT:
        {
            if( m_bLoadingApp )
            {
                // Draw on the window tell the user that the app is loading
                // TODO: change as needed
                HDC hDC = GetDC( hWnd );
                TCHAR strMsg[MAX_PATH];
                wsprintf( strMsg, TEXT("Loading... Please wait") );
                RECT rct;
                GetClientRect( hWnd, &rct );
                DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
                ReleaseDC( hWnd, hDC );
            }
            break;
        }

    }

    return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}




HRESULT CMyD3DApplication::InvalidateDeviceObjects()
{
    SAFE_RELEASE( m_pD3DXFont );

    return S_OK;
}



HRESULT CMyD3DApplication::DeleteDeviceObjects()
{
    return S_OK;
}


HRESULT CMyD3DApplication::FinalCleanup()
{
    return S_OK;
}




