// Interface for the CMcInput class.
// Keyboard and Mouse class.
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_

class CMcInput
{
protected:
	LPDIRECTINPUT8			m_pDInput;
	LPDIRECTINPUTDEVICE8	m_pDiKey;
	LPDIRECTINPUTDEVICE8	m_pDiMs;

	BYTE					KeyCur[256];
	BYTE					KeyOld[256];
	VEC3					vcMsCur;
	VEC3					vcMsOld;
	VEC3					vcDelta;
	DIMOUSESTATE			MsStCur;
	DIMOUSESTATE			MsStOld;

public:
	CMcInput();
	~CMcInput();

	INT		Init();
	INT		FrameMove();

	bool	GetKey(BYTE cKey);
	bool	KeyState(BYTE cKey);

	VEC3	GetMousePos();
	VEC2	GetMousePos2();
	VEC3	GetMouseDelta();
	bool	GetMouseSt(INT nM);
	bool	ButtonDn(INT nM);
	bool	ButtonPrss(INT nM);
	bool	ButtonUp(INT nM);
	bool	ButtonSt(INT nM);
	
protected:
	INT		InitDInput();
	INT		UpdateDInput();
};

#endif