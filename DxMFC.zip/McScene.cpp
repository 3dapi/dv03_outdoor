// McScene.cpp: implementation of the CMcScene class.
//
//////////////////////////////////////////////////////////////////////


#include "StdAfx.h"


CMcScene::CMcScene()
{
	m_pTxUi			= NULL;
}

CMcScene::~CMcScene()
{
	Destroy();	
}



INT		CMcScene::Init()
{
	//	Load Ui texture
	if( FAILED( D3DXCreateTextureFromFileEx(
			GDEVICE, "Texture/UI_Design.png"
			, D3DX_DEFAULT, D3DX_DEFAULT, D3DX_DEFAULT, 0
			, D3DFMT_UNKNOWN, D3DPOOL_MANAGED
			, 0x0000001, 0x0000001, 0x00FFFFFF
			, NULL, 0, &m_pTxUi)) )
		{
			m_pTxUi = NULL;
			return -1;
		}


	return 0;
}


void CMcScene::Destroy()
{
	SAFE_RELEASE(	m_pTxUi		);
}

INT CMcScene::FrameMove()
{
	return 0;
}

void	CMcScene::Render()
{
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,FALSE);
	GDEVICE->SetRenderState(D3DRS_ZENABLE, FALSE);
	
	GSPRITE->Begin(D3DXSPRITE_ALPHABLEND);
	RECT	rt1 = {0,0,1024, 256};
	GSPRITE->Draw(m_pTxUi, &rt1, NULL, &VEC3(0, 768-256, 0.F), D3DXCOLOR(1,1,1,1));

	
	GSPRITE->End();

	GDEVICE->SetRenderState(D3DRS_ZENABLE, TRUE);
}
