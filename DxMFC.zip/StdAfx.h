#ifndef STDAFX_H_INCLUDED_
#define STDAFX_H_INCLUDED_

#pragma once
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "comctl32.lib")

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;

#define STRICT
#define STRICT
#define	WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <windows.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <D3DX9.h>
#include <DXErr9.h>
#include <tchar.h>
#include "DXUtil.h"


#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;

#include <windows.h>
#include <windowsx.h>
#include <basetsd.h>
#include <commctrl.h>
#include <commdlg.h>

#include <math.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>


#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <dinput.h>

#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"
#include "resource.h"
#include "D3DApp.h"


#define GFORM			g_AppFormView
#define GMAIN			g_pApp
#define GHINST			g_hInst
#define GHWND			g_AppFormView->GetHwnd()
#define GHDC			g_AppFormView->GetHDC()
#define GDEVICE			g_AppFormView->GetDevice()
#define GSPRITE			g_AppFormView->GetSprite()
#define GSURFACE		g_AppFormView->GetBackSurface()


#define GCAMERA			g_pApp->m_pCam
#define GINPUT			g_pApp->m_pInput


#define GCAMERA			g_pApp->m_pCam
#define GINPUT			g_pApp->m_pInput



#include "_McType.h"
#include "McVtxFmt.h"
#include "McUtil.h"
#include "McMath.h"

#include "McGrid.h"

#include "McInput.h"
#include "McCam.h"





#include "McScene.h"

#include "Main.h"

#include "McScene.h"

#include "Main.h"
#include "DxMFC.h"

extern CMain*			g_pApp;
extern HINSTANCE       g_hInst;
extern CAppForm*       g_AppFormView;

#endif
