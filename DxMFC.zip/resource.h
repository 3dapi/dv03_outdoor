//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by DxMFC.rc
//
#define IDR_MAINFRAME          101
#define IDD_FORMVIEW           102
#define IDI_MAIN_ICON          101 // Application icon
#define IDR_MAIN_ACCEL         113 // Keyboard accelerator
#define IDR_MENU               141 // Application menu
#define IDR_POPUP              142 // Popup menu
#define IDD_SELECTDEVICE       144 // "Change Device" dialog box

#define IDC_DEVICE_COMBO                1000 
#define IDC_ADAPTER_COMBO               1002 
#define IDC_ADAPTERFORMAT_COMBO         1003
#define IDC_RESOLUTION_COMBO            1004
#define IDC_MULTISAMPLE_COMBO           1005 
#define IDC_REFRESHRATE_COMBO           1006
#define IDC_BACKBUFFERFORMAT_COMBO      1007
#define IDC_DEPTHSTENCILBUFFERFORMAT_COMBO 1008
#define IDC_VERTEXPROCESSING_COMBO      1009
#define IDC_PRESENTINTERVAL_COMBO       1010
#define IDC_MULTISAMPLE_QUALITY_COMBO   1011
#define IDC_WINDOW                      1016 
#define IDC_FULLSCREEN                  1018 

#define IDC_RENDERVIEW                  2002
#define IDC_VIEWFULLSCREEN              2003
#define IDC_CHANGEDEVICE                2004
#define IDM_CHANGEDEVICE                40002 
#define IDM_TOGGLEFULLSCREEN            40003 
#define IDM_EXIT                        40006 

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                1
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         40020
#define _APS_NEXT_CONTROL_VALUE         2005
#define _APS_NEXT_SYMED_VALUE           300
#endif
#endif
