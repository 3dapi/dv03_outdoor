#if !defined(AFX_APPFORM_H__8EFD45BE_5723_4C13_96CC_F3E272C50621__INCLUDED_)
#define AFX_APPFORM_H__8EFD45BE_5723_4C13_96CC_F3E272C50621__INCLUDED_



/////////////////////////////////////////////////////////////////////////////
// CAppForm form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CMain;

class CAppForm : public CFormView, public CD3DApplication
{
protected:
    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
	CMain*					m_pMain;

public:
    HWND    m_hwndRenderWindow;
    HWND    m_hwndRenderFullScreen;
    HWND    m_hWndTopLevelParent;

    virtual HRESULT ConfirmDevice( D3DCAPS9*,DWORD,D3DFORMAT );

    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT FinalCleanup();

	virtual HRESULT InitDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();

    virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();

    virtual HRESULT FrameMove();
    virtual HRESULT Render();
        
    virtual HRESULT AdjustWindowForChange();
    VOID    ReadSettings();
    VOID    WriteSettings();

    VOID    UpdateUIForDeviceCapabilites();

protected:
	CAppForm();           // protected constructor used by dynamic creation
	virtual  ~CAppForm();
	
	DECLARE_DYNCREATE(CAppForm)


public:
    BOOL IsReady()
	{
		return m_bActive;
	}

    TCHAR* PstrFrameStats() { return m_strFrameStats; }
    VOID RenderScene() { Render3DEnvironment(); }
    HRESULT CheckForLostFullscreen();

// Form Data
public:
	//{{AFX_DATA(CAppForm)
	enum { IDD = IDD_APP };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAppForm)
	virtual void OnInitialUpdate();
	
	protected:
	virtual LRESULT WindowProc(UINT message, WPARAM wParam, LPARAM lParam);
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

public:
	// Generated message map functions
	//{{AFX_MSG(CAppForm)
    afx_msg void OnChangeDevice();
	afx_msg void OnToggleFullScreen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

public:
//	HINSTANCE				GetInst()			{	return m_hInst;				}
	HWND					GetHwnd()
	{
		if(m_bWindowed)
			return m_hWndTopLevelParent;

		return m_hwndRenderFullScreen;
	}

//	HDC						GetHDC()			{	return m_hDC;				}

	void	SetCursorPosition(POINT* MsPos)
	{
		if(m_bWindowed)
			::ScreenToClient(m_hwndRenderWindow, MsPos);

		else
			::ScreenToClient(m_hwndRenderFullScreen, MsPos);
	}
	
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_APPFORM_H__8EFD45BE_5723_4C13_96CC_F3E272C50621__INCLUDED_)
