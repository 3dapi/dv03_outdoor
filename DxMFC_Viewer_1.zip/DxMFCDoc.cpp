// DxMFCDoc.cpp : implementation of the CDxMFCDoc class
//

#include "stdafx.h"
#include "DxMFC.h"

#include "DxMFCDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDxMFCDoc

IMPLEMENT_DYNCREATE(CDxMFCDoc, CDocument)

BEGIN_MESSAGE_MAP(CDxMFCDoc, CDocument)
	//{{AFX_MSG_MAP(CDxMFCDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDxMFCDoc construction/destruction

CDxMFCDoc::CDxMFCDoc()
{
	// TODO: add one-time construction code here
	int c;
	c=10;

}

CDxMFCDoc::~CDxMFCDoc()
{
}

BOOL CDxMFCDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CDxMFCDoc serialization

void CDxMFCDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CDxMFCDoc diagnostics

#ifdef _DEBUG
void CDxMFCDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDxMFCDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDxMFCDoc commands
