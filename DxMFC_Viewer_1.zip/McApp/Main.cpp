

#include "../StdAfx.h"

CMain*	g_pApp = NULL;

CMain::CMain()
:	m_pDXFt		(0)
,	m_pInput	(0)
,	m_pCam		(0)
,	m_pGrid		(0)
,	m_pScene	(0)
{
	g_pApp = this;
}


HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pCam		, CMcCam	);
	SAFE_NEWINIT(	m_pGrid		, CMcGrid	);

	SAFE_NEWINIT(	m_pScene	, CMcScene	);

	
	D3DXFONT_DESC hFont =
	{
		14, 0, FW_BOLD, 1, 0
		,	HANGUL_CHARSET, OUT_DEFAULT_PRECIS
		,	ANTIALIASED_QUALITY, FF_DONTCARE, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &hFont, &m_pDXFt) ) )
		return -1;


	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pDXFt );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pScene	);


	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pDXFt)
		m_pDXFt->OnResetDevice();	
	
	SAFE_NEWINIT(	m_pInput	, CMcInput	);
	SAFE_RESTORE(	m_pCam	);

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pDXFt)
		m_pDXFt->OnLostDevice();

	SAFE_DELETE(	m_pInput	);

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);
	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pScene	);


	sprintf( m_sMsg, "%s %s", GFORM->GetDeviceState(), GFORM->GetFrameState());

	return S_OK;
}


HRESULT CMain::Render()
{
	GCAMERA->SetTransForm();
	
	GDEVICE->Clear( 0L, NULL, GFORM->GetClearrMode(), 0x00006699, 1.0f, 0L );
		
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
	SAFE_RENDER(	m_pGrid		);
	SAFE_RENDER(	m_pScene	);
	
	
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);

	RECT	rc2;
	::GetClientRect(GHWND, &rc2);

	McRc	rc(2, 10, rc2.right-rc2.left, 30);

	m_pDXFt->DrawText(NULL, m_sMsg, -1, &rc.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));

	
	rc = McRc(2, 40, rc2.right-rc2.left, 60);
	VEC2	vcMouse = GINPUT->GetMousePos2();
	sprintf(m_sMsg, "%.f %.f", vcMouse.x, vcMouse.y);
	m_pDXFt->DrawText(NULL, m_sMsg, -1, &rc.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));

	
	GDEVICE->EndScene();
	
	return S_OK;
}