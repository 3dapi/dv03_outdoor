// Interface for the Math class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCMATH_H_
#define _MCMATH_H_

struct VECi2
{
	union	{	struct	{	INT x, z;	};	INT m[2];	};
	
	VECi2()									{	x = z = 0;								}
	VECi2(const INT *_m )					{	if(!_m){x=z=0;}else{x=_m[0];z=_m[2];}	}
	VECi2(const VECi2& rhs )						{	x = rhs.x;		z = rhs.z;				}
	VECi2( INT _x,INT _z)					{	x = _x;			z = _z;					}
	VECi2( VEC2 p)							{	x = INT(p.x);	z = INT(p.y);			}

	operator INT*()							{	return (INT *) &x;						}
	operator const INT*() const				{	return (const INT *) &x;				}
	
	// assignment operators
	VECi2& operator+=(const VECi2& v)		{	x += v.x;	z += v.z;	return *this;	}
	VECi2& operator-=(const VECi2& v)		{	x -= v.x;	z -= v.z;	return *this;	}
	VECi2& operator*=(INT f )				{	x *= f;		z *= f;		return *this;	}
	VECi2& operator/=(INT f )				{	x /= f;		z /= f;		return *this;	}
	
	// unary operators
	VECi2 operator+() const					{	return *this;							}
	VECi2 operator-() const					{	return VECi2(-x, -z);					}
	
	// binary operators
	VECi2 operator+(const VECi2& v)const	{	return VECi2(x + v.x, z + v.z);			}
	VECi2 operator-(const VECi2& v)const	{	return VECi2(x - v.x, z - v.z);			}
	VECi2 operator*(INT f) const			{	return VECi2(x*f, z*f);					}
	VECi2 operator/(INT f) const			{	return VECi2(x/f, z/f);					}

	friend VECi2 operator*(INT f,const VECi2& v)
											{	return VECi2(f * v.x, f * v.z);			}

	bool operator==(const VECi2& v) const	{	return x == v.x && z == v.z;			}
	bool operator!=(const VECi2& v) const	{	return x != v.x || z != v.z;			}

};



typedef	vector<VECi2>		lsVECi2;
typedef	lsVECi2::iterator	itVECi2;


struct VECi3
{
	union{struct{INT x, y, z;};	INT m[3];};
	
	VECi3()									{	x =				y =			  z = 0;		}
	VECi3(const INT *_m )					{	if(!_m){x=y=z=0;}else{x=_m[0];y=_m[1];z=_m[2];}	}
	VECi3(const VECi3& rhs )						{	x = rhs.x;		y= rhs.y;	  z = rhs.z;	}
	VECi3( INT _x,INT _y, INT _z)			{	x = _x;			y = _y;		  z = _z;		}
	VECi3(VEC3 p)							{	x = INT(p.x);	y = INT(p.y); z = INT(p.z);	}
	VECi3(FLOAT _x, FLOAT _y, FLOAT _z)		{	x = INT(_x);	y = INT(_y);  z = INT(_z);	}

	operator INT*()							{	return (INT *) &x;							}
	operator const INT*() const				{	return (const INT *) &x;					}
	
	VECi3& operator+=(const VECi3& v)		{	x += v.x; y += v.y;	z += v.z; return *this;	}
	VECi3& operator-=(const VECi3& v)		{	x -= v.x; y -= v.y;	z -= v.z; return *this;	}
	VECi3& operator*=(INT f )				{	x *= f;	 y *= f;	z *= f;	  return *this;	}
	VECi3& operator/=(INT f )				{	x /= f;	 y /= f;	z /= f;	  return *this;	}
	
	VECi3 operator+() const					{	return *this;								}
	VECi3 operator-() const					{	return VECi3(-x,-y, -z);					}
	
	VECi3 operator+(const VECi3& v)const	{	return VECi3(x + v.x, y + v.y, z + v.z);	}
	VECi3 operator-(const VECi3& v)const	{	return VECi3(x - v.x, y - v.y, z - v.z);	}
	VECi3 operator*(INT f) const			{	return VECi3(x*f, y*f, z*f);				}
	VECi3 operator/(INT f) const			{	return VECi3(x/f, y/f, z/f);				}

	friend VECi3 operator*(INT f,const VECi3& v)
											{	return VECi3(f * v.x, f * v.y, f * v.z);	}

	bool operator==(const VECi3& v) const	{	return x == v.x && y == v.y && z == v.z;	}
	bool operator!=(const VECi3& v) const	{	return x != v.x || y != v.y || z != v.z;	}

};


typedef	vector<VECi3>		lsVECi3;
typedef	lsVECi3::iterator	itVECi3;


struct VECi4
{
	union	{	struct	{	INT x, y, z, w;	};	INT m[4];	};
	
	VECi4()									{	x=y=z=w=0;									}
	VECi4(const INT *_m )	{	if(!_m){x=y=z=w=0;}else{x=_m[0];y=_m[1];z=_m[2];w=_m[3];}	}
	VECi4(const VECi4& r )						{	x=r.x; y=r.y; z=r.z; w= r.w;				}
	VECi4(INT X,INT Y,INT Z,INT W)			{	x=X; y=Y; z=Z; w=W;							}
	VECi4(VEC4 p)							{	x=INT(p.x);y=INT(p.y);z=INT(p.z);w=INT(p.w);}

	operator INT*()								{	return (INT *) &x;							}
	operator const INT*() const					{	return (const INT *) &x;					}
	
	// assignment operators
	VECi4& operator+=(const VECi4& v)		{	x+=v.x;y+=v.y;z+=v.z;w+=v.w;return *this;	}
	VECi4& operator-=(const VECi4& v)		{	x-=v.x;y-=v.y;z-=v.z;w-=v.w;return *this;	}
	VECi4& operator*=(INT f )				{	x*=f; y*=f;	z*=f; w*=f;		return *this;	}
	VECi4& operator/=(INT f )				{	x/=f; y/=f;	z/=f; w/=f;		return *this;	}
	
	// unary operators
	VECi4 operator+() const					{	return *this;								}
	VECi4 operator-() const					{	return VECi4(-x,-y,-z,-w);				}
	
	// binary operators
	VECi4 operator+(const VECi4& v)const	{	return VECi4(x+v.x,y+v.y,z+v.z,w+v.w);	}
	VECi4 operator-(const VECi4& v)const	{	return VECi4(x-v.x,y-v.y,z-v.z,w-v.w);	}
	VECi4 operator*(INT f) const				{	return VECi4(x*f,y*f,z*f, w*f);			}
	VECi4 operator/(INT f) const				{	return VECi4(x/f, y/f, z/f, w/f);		}

	friend VECi4 operator*(INT f,const VECi4& v)
												{	return VECi4(f*v.x,f*v.y,f*v.z,f*v.w);	}

	bool operator==(const VECi4& v) const	{	return x==v.x&&y==v.y&&z==v.z&&w==v.w;		}
	bool operator!=(const VECi4& v) const	{	return x!=v.x||y!=v.y||z!=v.z||w!=v.w;		}

};


typedef	vector<VECi4>		lsVECi4;
typedef	lsVECi4::iterator	itVECi4;


struct McRc
{
	union	{	struct	{	float x0, y0, x1, y1;	};	float m[4];		};
	
	McRc()									{	x0 = y0 = x1 = y1 = 0.f;										}
	McRc(const FLOAT *_m )					{	x0 = _m[0];	y0 = _m[1];	x1 = _m[2];	y1 = _m[3];					}
	McRc(const McRc& _rt )						{	x0 = _rt.x0; y0 = _rt.y0; x1 = _rt.x1;	y1 = _rt.y1;			}

	McRc( FLOAT fx0,FLOAT fy0,FLOAT fx1,FLOAT fy1)
											{	x0 = fx0;	y0 = fy0;	x1 = fx1;	y1 = fy1;					}

	McRc( VEC2 p0, VEC2 p1)					{	x0 = p0.x;	y0 = p0.y;	x1 = p1.x;	y1 = p1.y;					}

	VEC2   Get00()	 const					{	return VEC2(x0, y0);											}
	VEC2   Get10()	 const					{	return VEC2(x1, y0);											}
	VEC2   Get01()	 const					{	return VEC2(x0, y1);											}
	VEC2   Get11()	 const					{	return VEC2(x1, y1);											}

	RECT   GetRECT(){	RECT r;	r.left=long(x0); r.right=long(x1); r.top=long(y0);	r.bottom=long(y1);	return r;	}

	FLOAT	GetWidth()						{	return (x1 - x0);												}
	FLOAT	GetHeight()						{	return (y1 - y0);												}
	
	// casting
	operator FLOAT*()						{	return (FLOAT *) &x0;											}
	operator const FLOAT*() const			{	return (const FLOAT *) &x0;										}
	
	// assignment operators
	McRc& operator+=(const McRc& v)			{	x0 += v.x0;	y0 += v.y0;	x1 += v.x1;	y1 += v.y1;	return *this;	}
	McRc& operator-=(const McRc& v)			{	x0 -= v.x0;	y0 -= v.y0;	x1 -= v.x1;	y1 -= v.y1;	return *this;	}
	McRc& operator*=(FLOAT f )				{	x0 *= f;	y0 *= f;	x1 *= f;	y1 *= f;	return *this;	}
	McRc& operator/=(FLOAT f )				{	FLOAT fInv = 1.0f / f;	x0 *= fInv;	y0 *= fInv;	x1 *= fInv;	y1 *= fInv;		return *this;	}
	
	// unary operators
	McRc operator+() const					{	return *this;													}
	McRc operator-() const					{	return McRc(-x0, -y0, -x1, -y1);								}
	
	// binary operators
	McRc operator+(const McRc& v)const	{	return McRc(x0 + v.x0, y0 + v.y0, x1 + v.x1, y1 + v.y1);		}
	McRc operator-(const McRc& v)const	{	return McRc(x0 - v.x0, y0 - v.y0, x1 - v.x1, y1 - v.y1);		}
	McRc operator*(FLOAT f) const			{	return McRc(x0 * f, y0 * f, x1 * f, y1 * f);				}
	McRc operator/(FLOAT f) const			{	FLOAT fInv = 1.0f / f;	return McRc(x0 * fInv, y0 * fInv, x1 * fInv, y1 * fInv);		}

	friend McRc operator*(FLOAT f,const McRc& v)
												{	return McRc(f * v.x0, f * v.y0, f * v.x1, f * v.y1);			}

	bool operator==(const McRc& v) const		{	return x0 == v.x0 && y0 == v.y0 && x1 == v.x1 && y1 == v.y1;	}
	bool operator!=(const McRc& v) const		{	return x0 != v.x0 || y0 != v.y0 || x1 != v.x1 || y0 != v.y1;	}
};

typedef	vector<McRc>		lsMcRc;
typedef	lsMcRc::iterator	itMcRc;

#endif