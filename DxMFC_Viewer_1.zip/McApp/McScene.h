// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:
	PDTX	m_pTxUi;
	PDTX	m_pTxCursor;

public:
	CMcScene();
	~CMcScene();
	
	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif
