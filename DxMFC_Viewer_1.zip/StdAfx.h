#ifndef AFX_STDAFX_H__DEE58E81_88D7_487B_97CB_246B1E15A501__INCLUDED_
#define AFX_STDAFX_H__DEE58E81_88D7_487B_97CB_246B1E15A501__INCLUDED_


#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "dinput8.lib")
#pragma comment(lib, "dxerr9.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "d3d9.lib")
#pragma comment(lib, "d3dxof.lib")
#pragma comment(lib, "dxguid.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "comctl32.lib")


//#define STRICT
//#define	WIN32_LEAN_AND_MEAN
#define DIRECTINPUT_VERSION 0x0800

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;

#include <windows.h>
#include <windowsx.h>
#include <basetsd.h>
#include <commctrl.h>
#include <commdlg.h>

#include <math.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>


#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <dinput.h>

#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnumeration.h"
#include "D3DSettings.h"

#include "D3DApp.h"

#include "resource.h"

#include "DxMFC.h"
#include "DxMFCDoc.h"

#include "WrkLeft.h"
#include "AppForm.h"






#define GFORM			g_AppFormView
#define GMAIN			g_pApp
#define GHINST			g_hInst
#define GHWND			g_AppFormView->GetHwnd()
#define GHDC			g_AppFormView->GetHDC()
#define GDEVICE			g_AppFormView->GetDevice()
#define GSPRITE			g_AppFormView->GetSprite()
#define GSURFACE		g_AppFormView->GetBackSurface()


#define GCAMERA			g_pApp->m_pCam
#define GINPUT			g_pApp->m_pInput


#define GCAMERA			g_pApp->m_pCam
#define GINPUT			g_pApp->m_pInput



#include "McApp/_McType.h"
#include "McApp/McVtxFmt.h"
#include "McApp/McUtil.h"
#include "McApp/McMath.h"

#include "McApp/McGrid.h"

#include "McApp/McInput.h"
#include "McApp/McCam.h"





#include "McApp/McScene.h"
#include "McApp/Main.h"




#include "DxMFCView.h"
#include "MainFrm.h"
#include "AppForm.h"

extern CDxMFCApp	theApp;
extern HINSTANCE	g_hInst;
extern CAppForm*	g_AppFormView;
extern CMain*		g_pApp;

#endif
