#if !defined(AFX_WRKLEFT_H__62168D91_455C_45AD_8993_E2DC090E61D2__INCLUDED_)
#define AFX_WRKLEFT_H__62168D91_455C_45AD_8993_E2DC090E61D2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WrkLeft.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWrkLeft form view

#ifndef __AFXEXT_H__
#include <afxext.h>
#endif

class CWrkLeft : public CFormView
{
protected:
	CWrkLeft();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CWrkLeft)

// Form Data
public:
	//{{AFX_DATA(CWrkLeft)
	enum { IDD = IDD_LEFT };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWrkLeft)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CWrkLeft();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
	//{{AFX_MSG(CWrkLeft)
	afx_msg void OnViewfullscreen();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WRKLEFT_H__62168D91_455C_45AD_8993_E2DC090E61D2__INCLUDED_)
