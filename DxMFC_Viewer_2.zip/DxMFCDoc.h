// DxMFCDoc.h : interface of the CDxMFCDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_DXMFCDOC_H__4DBB591D_043D_4675_985D_83D5AE6AD0F8__INCLUDED_)
#define AFX_DXMFCDOC_H__4DBB591D_043D_4675_985D_83D5AE6AD0F8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CDxMFCDoc : public CDocument
{
protected: // create from serialization only
	CDxMFCDoc();
	DECLARE_DYNCREATE(CDxMFCDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDxMFCDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CDxMFCDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CDxMFCDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DXMFCDOC_H__4DBB591D_043D_4675_985D_83D5AE6AD0F8__INCLUDED_)
