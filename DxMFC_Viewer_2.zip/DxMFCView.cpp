// DxMFCView.cpp : implementation of the CDxMFCView class
//

#include "stdafx.h"
#include "DxMFC.h"

#include "DxMFCDoc.h"
#include "DxMFCView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView

IMPLEMENT_DYNCREATE(CDxMFCView, CView)

BEGIN_MESSAGE_MAP(CDxMFCView, CView)
	//{{AFX_MSG_MAP(CDxMFCView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView construction/destruction

CDxMFCView::CDxMFCView()
{
	// TODO: add construction code here

}

CDxMFCView::~CDxMFCView()
{
}

BOOL CDxMFCView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView drawing

void CDxMFCView::OnDraw(CDC* pDC)
{
	CDxMFCDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView printing

BOOL CDxMFCView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CDxMFCView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CDxMFCView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView diagnostics

#ifdef _DEBUG
void CDxMFCView::AssertValid() const
{
	CView::AssertValid();
}

void CDxMFCView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDxMFCDoc* CDxMFCView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDxMFCDoc)));
	return (CDxMFCDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDxMFCView message handlers
