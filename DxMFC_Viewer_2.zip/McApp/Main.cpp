

#include "../StdAfx.h"

CMain*	g_pApp = NULL;

CMain::CMain()
:	m_pDXFt		(0)
,	m_pInput	(0)
,	m_pCam		(0)
,	m_pGrid		(0)
,	m_pScene	(0)
{
	g_pApp = this;
}


HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pCam		, CMcCam	);
	SAFE_NEWINIT(	m_pGrid		, CMcGrid	);

	SAFE_NEWINIT(	m_pScene	, CMcScene	);

	
	D3DXFONT_DESC m_hFont =
	{	 16, 0, FW_BOLD, 1, 0
		, ANSI_CHARSET
		, OUT_DEFAULT_PRECIS
		, ANTIALIASED_QUALITY
		, FF_DONTCARE, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(GDEVICE, &m_hFont, &m_pDXFt ) ) )
		return -1;

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE( m_pDXFt );

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pScene	);


	return S_OK;
}



HRESULT CMain::Restore()
{
	if(m_pDXFt)
		m_pDXFt->OnResetDevice();	
	
	SAFE_NEWINIT(	m_pInput	, CMcInput	);
	SAFE_RESTORE(	m_pCam	);



	CMainFrame*	pMainFrame = (CMainFrame*)AfxGetMainWnd();
	CWrkMini*	pWrkMini = (CWrkMini*)(pMainFrame->GetChildForm(1, 0));

	m_hPnnl = NULL;

	if(pWrkMini)
	{
		m_hPnnl = pWrkMini->GetDlgItem(IDC_PANNEL)->GetSafeHwnd();
	}


	if(m_hPnnl && GFORM->IsWindow())
	{
		m_SpW.hW = m_hPnnl;
		
		D3DPRESENT_PARAMETERS	par;
		memset(&par, 0, sizeof(D3DPRESENT_PARAMETERS));
		
		par.SwapEffect = D3DSWAPEFFECT_DISCARD;
		par.Windowed = TRUE;
		par.BackBufferHeight= 0;
		par.BackBufferWidth = 0;
		par.hDeviceWindow = m_SpW.hW;
		
		if( FAILED(GDEVICE->CreateAdditionalSwapChain(&par, &m_SpW.pC)) )
			return -1;		// Create addtional swap chain failed
		
		if( FAILED(m_SpW.pC->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &m_SpW.pB)) )
			return -1;		// Get back buffer Failed
		
		if ( FAILED(GDEVICE->CreateDepthStencilSurface(par.BackBufferWidth
			, par.BackBufferHeight
			, GFORM->GetDepthF()
			, D3DMULTISAMPLE_NONE, 0, 0, &m_SpW.pS, NULL)))
			return -1;
	}

	return S_OK;
}


HRESULT CMain::Invalidate()
{
	if(m_pDXFt)
		m_pDXFt->OnLostDevice();

	SAFE_DELETE(	m_pInput	);

	m_SpW.Release();

	return S_OK;
}




HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);
	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pScene	);


	sprintf( m_sMsg, "%s %s", GFORM->GetDeviceState(), GFORM->GetFrameState());

	return S_OK;
}


HRESULT CMain::Render()
{
	if( m_hPnnl && GFORM->IsWindow() )
	{
		LPDIRECT3DSURFACE9		pTOrg=NULL;
		LPDIRECT3DSURFACE9		pSOrg=NULL;
		
		GDEVICE->GetRenderTarget(0, &pTOrg);
		GDEVICE->GetDepthStencilSurface(&pSOrg);
		
		GDEVICE->SetRenderTarget(0, m_SpW.pB);
		GDEVICE->SetDepthStencilSurface(m_SpW.pS);
		
		
		HRESULT hr;
		hr =GDEVICE->Clear( 0L, NULL, GFORM->GetClearrMode(),0x00005588, 1.0f, 0L );
		
		GDEVICE->BeginScene();

		SAFE_RENDER(	m_pGrid		);
		SAFE_RENDER(	m_pScene	);
		
		GDEVICE->EndScene();
		
		m_SpW.pC->Present(0, 0, 0, 0, 0);
		
		GDEVICE->SetRenderTarget(0, pTOrg);
		GDEVICE->SetDepthStencilSurface(pSOrg);
		
		
		if(pTOrg)
			pTOrg->Release();
		
		if(pSOrg)
			pSOrg->Release();
	}
	
	GCAMERA->SetTransForm();
	
	GDEVICE->Clear( 0L, NULL, GFORM->GetClearrMode(), 0x00006699, 1.0f, 0L );
		
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
	SAFE_RENDER(	m_pGrid		);
	SAFE_RENDER(	m_pScene	);
	
	
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);

	RECT	rc2;
	::GetClientRect(GHWND, &rc2);

	McRc	rc(2, 10, rc2.right-rc2.left, 30);

	m_pDXFt->DrawText(NULL, m_sMsg, -1, &rc.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));

	
	rc = McRc(2, 40, rc2.right-rc2.left, 60);
	VEC2	vcMouse = GINPUT->GetMousePos2();
	sprintf(m_sMsg, "%.f %.f", vcMouse.x, vcMouse.y);
	m_pDXFt->DrawText(NULL, m_sMsg, -1, &rc.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));

	
	GDEVICE->EndScene();
	
	return S_OK;
}