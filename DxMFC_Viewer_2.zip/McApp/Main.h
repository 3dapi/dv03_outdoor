#ifndef _MAIN_H_
#define _MAIN_H_

struct LnSwpWn														// Swap chain window
{
	LPDIRECT3DSWAPCHAIN9	pC;													// Swap chain
	LPDIRECT3DSURFACE9		pB;													//Back buffer surface
	LPDIRECT3DSURFACE9		pS;													//Stencil buffer surface
	HWND					hW;													// Window Handle

	LnSwpWn() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

};


class CMain
{
public:
	ID3DXFont*	m_pDXFt;														// D3DX font
	TCHAR		m_sMsg[512];

	CMcInput*	m_pInput;
	CMcCam*		m_pCam;
	CMcGrid*	m_pGrid;
	

	CMcScene*	m_pScene;

	HWND		m_hPnnl;
	LnSwpWn		m_SpW;


public:
	virtual HRESULT Init();
	virtual HRESULT Destroy();
	
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	
	
public:
	CMain();
};



#endif