// Interface for the CMcCam class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCAM_H_
#define _MCCAM_H_

class CMcCam
{
protected:
	FLOAT		m_fFv;															// Field of View
    FLOAT		m_fAs;															// Aspect Ratio
    FLOAT		m_fNr;															// Near
    FLOAT		m_fFr;															// Far

	VEC3		m_vcEye;														// Camera position
	VEC3		m_vcLook;														// Look vector
	VEC3		m_vcUp;															// up vector

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	D3DXMATRIX	m_mtViw;														// View Matrix
	D3DXMATRIX	m_mtPrj;														// Projection Matrix

	D3DXMATRIX	m_mtViwI;														// View Matrix Inverse
	D3DXMATRIX	m_mtBill;														// BillBoard Matrix
	D3DXMATRIX	m_mtVwPj;														// m_mtViw * m_mtPrj;
	
	D3DXPLANE	m_Frsm[6];														// Near, Far, Left, Right, Up, Down

	VEC3		m_vcX;
	VEC3		m_vcY;
	VEC3		m_vcZ;

	VEC3		m_vcScnPos;
	VEC3		m_vcRayDir;
	
public:
	CMcCam();
	~CMcCam();

	// General Camera
	INT		Init();
	INT		FrameMove();
	INT		Restore();
	
	D3DXMATRIX	GetMatrixViw()		{	return m_mtViw;		}
	D3DXMATRIX	GetMatrixViwI()		{	return m_mtViwI;	}
	D3DXMATRIX	GetMatrixBll()		{	return m_mtBill;	}
	D3DXMATRIX	GetMatrixPrj()		{	return m_mtPrj;		}
	D3DXMATRIX	GetMatrixViwPrj()	{	return m_mtVwPj;	}

	VEC3	GetCamPos()			{	return m_vcEye;		}
	VEC3	GetCamLook()		{	return m_vcLook;	}
	VEC3	GetCamUp()			{	return m_vcUp;		}

	FLOAT	GetNear()			{	return m_fNr;		}
    FLOAT	GetFar()			{	return m_fFr;		}

	VEC3	Get3DDir(POINT* pt=NULL);
	VEC3	GetX()				{	return m_vcX;		}
	VEC3	GetY()				{	return m_vcY;		}
	VEC3	GetZ()				{	return m_vcZ;		}

	void	SetTransForm();


	// Individual Camera
	void	SetMatrixViw(D3DXMATRIX mtViw){	m_mtViw = mtViw;	}
	void	SetMatrixPrj(D3DXMATRIX mtPrj){	m_mtPrj = mtPrj;	}
	INT		Update();

protected:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	void	MoveX(FLOAT	fSpeed);
	void	MoveZ(FLOAT	fSpeed);
};

#endif