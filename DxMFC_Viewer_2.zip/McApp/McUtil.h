// Interface for the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCUTIL_H_
#define _MCUTIL_H_

#define ONE_RADtoDEG	57.2957795130823208767981548f
#define ONE_DEGtoRAD	0.01745329251994329576923690f

#ifndef D3DX_PI
	#define PI				D3DX_PI
#else
	#define PI				3.14159265358979323846264338f
#endif

#define DEG90toRAD		1.57079632679489661923132163f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)


template<class T> D3DXINLINE
bool McUtil_IsAllocated(T* &t)
{
	return (&t && !IsBadReadPtr(t, sizeof(T)) );
}

#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }


#define _SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
																			\
		if(!(p))															\
		{																	\
			return;															\
		}																	\
																			\
		if(FAILED((p)->Init()))												\
		{																	\
			delete p;														\
			p = NULL;														\
			return;															\
		}																	\
	}																		\
}


#define SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
																			\
		if(!(p))															\
		{																	\
			return -1;														\
		}																	\
																			\
		if(FAILED((p)->Init()))												\
		{																	\
			delete p;														\
			p = NULL;														\
			return -1;														\
		}																	\
	}																		\
}


#define SAFE_RESTORE(p)														\
{																			\
	if(p)																	\
	{																		\
		if(FAILED((p)->Restore()))											\
			return -1;														\
	}																		\
}



#define SAFE_FRMOV(p)														\
{																			\
	if(p)																	\
	{																		\
		if(FAILED(	(p)->FrameMove()))										\
			return -1;														\
	}																		\
}


#define SAFE_UPDATE(p)	{ if(p) {if(FAILED( (p)->Update())) return -1; } }

#define SAFE_DESTROY(p)			{	if(p)	(p)->Destroy();			}
#define SAFE_INVALID(p)			{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)			{	if(p)	(p)->Render();			}
#define SAFE_RENDERS(p)			{	if(p)	(p)->RenderS();			}

#define SAFE_ONFRMMOV(p)		{	if(p)	(p)->OnFrmMov();		}
#define SAFE_ONRENDER(p)		{	if(p)	(p)->OnRender();		}


#define	SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}

#define FLOATP(p)			(float*)&(p)

#define SAFE_DELETE_OBJECT(p)	{	if(p){	DeleteObject(p); (p)=NULL;	}	}


#define SAFE_DELETE_OBJECT_ARRAY(p, iSIZE)									\
{																			\
	int i_IDX_OBJ_=0;														\
																			\
	for(i_IDX_OBJ_=0; i_IDX_OBJ_ < (iSIZE) ; ++i_IDX_OBJ_)					\
	{																		\
		if(p[i_IDX_OBJ_])													\
		{																	\
			DeleteObject(p[i_IDX_OBJ_]);									\
			p[i_IDX_OBJ_] = NULL;											\
		}																	\
	}																		\
}


// Vector delete
#define SAFE_DEL_LST(p)														\
{																			\
	if(!p.empty())															\
	{																		\
		int iSizeList = p.size();											\
		for(int indexList=0; indexList<iSizeList; ++indexList)				\
			SAFE_DELETE(p[indexList]);										\
		p.clear();															\
	}																		\
}


void	McUtil_ErrMsgBox(TCHAR *format,...);
void	McUtil_GetLastError(HWND hWnd);
INT		McUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color=0xffffffff, D3DXIMAGE_INFO *pSrcInfo=NULL, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), D3DFORMAT d3dFormat = D3DFMT_A8R8G8B8);
void	McUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr);
void	McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');

void	McUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	McUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx);
void	McUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	McUtil_IBLock(PDIB& pIB, INT nSize, void* pIdx);


bool	McUtil_LineCross2D(VEC2 * p);
INT		McUtil_3Dto2D(VEC3 & Out, const VEC3 & In);
bool	McUtil_PositionMouse3D(VEC3 & vec3dOut);
INT		McUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	McUtil_SetWindowTitle(const char *format, ...);
void	McUtil_TextOut(float x, float y, const char *format, ...);
void	McUtil_TextOut(VEC2 p, const char *format, ...);
void	McUtil_OutputDebug(const char *Format, ...);
TCHAR*	McUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR *sTitle="Choose Folder");
TCHAR*	McUtil_DWtoStr(DWORD dwA);
char*	McUtil_Forming(const char *fmt, ...);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val);

#define PFF(s, d, l, d1) McUtil_PluckFirstField((s), (d), (l), (d1))

inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }
inline DWORD F2DW( FLOAT f )	{ return *((DWORD*)&f); }

#endif