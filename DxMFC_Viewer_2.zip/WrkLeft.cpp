// WrkLeft.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWrkLeft

IMPLEMENT_DYNCREATE(CWrkLeft, CFormView)

CWrkLeft::CWrkLeft()
	: CFormView(CWrkLeft::IDD)
{
	//{{AFX_DATA_INIT(CWrkLeft)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWrkLeft::~CWrkLeft()
{
}

void CWrkLeft::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWrkLeft)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWrkLeft, CFormView)
	//{{AFX_MSG_MAP(CWrkLeft)
	ON_BN_CLICKED(IDC_VIEWFULLSCREEN, OnViewfullscreen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWrkLeft diagnostics

#ifdef _DEBUG
void CWrkLeft::AssertValid() const
{
	CFormView::AssertValid();
}

void CWrkLeft::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWrkLeft message handlers

void CWrkLeft::OnViewfullscreen() 
{
	// TODO: Add your control notification handler code here
	GFORM->OnToggleFullScreen();	
}
