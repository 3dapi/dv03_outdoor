// WrkMini.cpp : implementation file
//

#include "stdafx.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CWrkMini

IMPLEMENT_DYNCREATE(CWrkMini, CFormView)

CWrkMini::CWrkMini()
	: CFormView(CWrkMini::IDD)
{
	//{{AFX_DATA_INIT(CWrkMini)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}

CWrkMini::~CWrkMini()
{
}

void CWrkMini::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWrkMini)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWrkMini, CFormView)
	//{{AFX_MSG_MAP(CWrkMini)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CWrkMini diagnostics

#ifdef _DEBUG
void CWrkMini::AssertValid() const
{
	CFormView::AssertValid();
}

void CWrkMini::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CWrkMini message handlers
