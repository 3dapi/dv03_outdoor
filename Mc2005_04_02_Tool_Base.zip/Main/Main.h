// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	EGmPhase			m_ePhCur	;											// Current Phase
	EGmPhase			m_ePhOld	;											// Current Phase
	TCHAR				m_sMsg[512]	;
	LPD3DXFONT			m_pD3DXFont	;
	CMcInput*			m_pInput	;											// Keyboard Mouse
	
public:
	CGmWrk1*			m_pGmWrk1	;											// Work 1
	CGmWrk2*			m_pGmWrk2	;											// Work 2

	HIMAGELIST			m_ilWork	;											// Image List for Tab and List control
	CWndWrk				m_Wrk		;

	McSwpWn				m_SwpWn		;											// Swap Chain Window
	DVWP				m_Vp		;											// View port

public:
	CMain();
	virtual HRESULT		Init();
	virtual HRESULT		Restore();
	virtual HRESULT		Invalidate();
	virtual HRESULT		Destroy();
	virtual HRESULT		Render();
	virtual HRESULT		FrameMove();
	LRESULT				MsgProc(HWND, UINT, WPARAM, LPARAM);

public:
	INT	 (CMain::*OnFrm	[GP_WIN])();											// Game phase frame move function pointer
	void (CMain::*OnRnd	[GP_WIN])();											// Game phase rendering function pointer
	void (CMain::*OnRns	[GP_WIN])();											// Game phase rendering backbuffer DC function pointer

	INT  OnFrmWrk1();
	void OnRndWrk1();
	void OnRnsWrk1();
	INT  OnFrmWrk2();
	void OnRndWrk2();
	void OnRnsWrk2();
};

#endif