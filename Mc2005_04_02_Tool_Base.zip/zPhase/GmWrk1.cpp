// Implementation of the CGmWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CGmWrk1::CGmWrk1()
{
	m_pLine		= 0;
	m_pDxL		= 0;
}


CLASS_CLEAN_ALL(CGmWrk1);


INT CGmWrk1::Init()
{
	D3DXCreateLine(GDEVICE, &m_pDxL);
	m_pDxL->SetWidth(1.f);
	return 1;
}

void CGmWrk1::Destroy()
{
	SAFE_RELEASE(	m_pDxL	);
}

INT CGmWrk1::Restore()
{
	INT i=0, idx=0;
		
	m_pDxL->OnResetDevice();
	
	m_rtWnd[0]	= McWnRc(	0,	  0,	GMAIN->m_d3dpp.BackBufferWidth,	320-2);
	m_rtWnd[1]	= McWnRc(	0,	320,	GMAIN->m_d3dpp.BackBufferWidth,	GMAIN->m_d3dpp.BackBufferHeight-320);

	m_fW  = 20;
	m_icX = INT(GMAIN->m_d3dpp.BackBufferWidth * 2/m_fW);
	m_icY = INT(GMAIN->m_d3dpp.BackBufferHeight* 2/m_fW);


	McUtil_Calloc(m_pLine, m_icX * 4 + m_icY * 4);

	for(i=0; i<m_icX; ++i)
	{
		idx = i;

		m_pLine[idx*4+0] = VEC2( (i+0) * 2 * m_fW,							   0);
		m_pLine[idx*4+1] = VEC2( (i+0) * 2 * m_fW, GMAIN->m_d3dpp.BackBufferHeight);
		m_pLine[idx*4+2] = VEC2( (i+1) * 2 * m_fW, GMAIN->m_d3dpp.BackBufferHeight);
		m_pLine[idx*4+3] = VEC2( (i+1) * 2 * m_fW,							   0);
	}

	for(i= 0; i<m_icY; ++i)
	{
		idx = m_icX + i;

		m_pLine[idx*4+0] = VEC2(							  0, (i+0) * 2 * m_fW);
		m_pLine[idx*4+1] = VEC2( GMAIN->m_d3dpp.BackBufferWidth, (i+0) * 2 * m_fW);
		m_pLine[idx*4+2] = VEC2( GMAIN->m_d3dpp.BackBufferWidth, (i+1) * 2 * m_fW);
		m_pLine[idx*4+3] = VEC2(							  0, (i+1) * 2 * m_fW);
	}

	
	return 1;
}

void CGmWrk1::Invalidate()
{
	m_pDxL->OnLostDevice();
	SAFE_FREE(	m_pLine	);
}

INT CGmWrk1::FrameMove()
{
	static CMcSkip Skip;

	if(GINPUT->ButtonDn(0) )
	{
		Skip.SetStart();
		return 1;
	}

	Skip.FrameMove();

	if(!Skip.IsEnd())
		return 1;

	return 1;
}


void CGmWrk1::Render()
{
	{
		GDEVICE->SetViewport(&(m_rtWnd[0].vp));
		GDEVICE->Clear( 0, 0, GMAIN->m_dwClr, 0x00006699, 1.0f, 0L );
		

		m_pDxL->Draw(m_pLine		, m_icX, 0x44000000);
		m_pDxL->Draw(m_pLine+m_icX*4, m_icY, 0x44000000);

		RECT rt={5,10, 1024,30};
		GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
	}

	{
		GDEVICE->SetViewport(&(m_rtWnd[1].vp));
		GDEVICE->Clear( 0, 0, GMAIN->m_dwClr, 0x00004466, 1.0f, 0L );
		

		m_pDxL->Draw(m_pLine		, m_icX, 0x44000000);
		m_pDxL->Draw(m_pLine+m_icX*4, m_icY, 0x44000000);

		RECT rt={5,10, 1024,30};
		rt.top +=320;
		rt.bottom+=320;
		GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
	}
}

void CGmWrk1::RenderS()
{
}
