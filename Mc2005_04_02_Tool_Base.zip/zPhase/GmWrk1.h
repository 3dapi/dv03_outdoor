// Interface for the CGmWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GMWRK1_H_
#define _GMWRK1_H_

class CGmWrk1
{
protected:
	VEC2*				m_pLine	;
	FLOAT				m_fW	;
	INT					m_icX	;
	INT					m_icY	;
	LPD3DXLINE			m_pDxL	;

	McWnRc				m_rtWnd[2];

	// for Image and Texture
	PDTX				m_pTx	;
	DIMG*				m_Img	;
	DWORD				m_dC	;

public:
	CGmWrk1();
	virtual ~CGmWrk1();

	INT		Init();
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
	void	RenderS();
};

#endif