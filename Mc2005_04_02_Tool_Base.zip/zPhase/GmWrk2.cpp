// Implementation of the CGmWrk2 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CGmWrk2::CGmWrk2()
{
}

CLASS_DESTROY(CGmWrk2);


INT CGmWrk2::Init()
{
	D3DXCreateLine(GDEVICE, &m_pDxL);
	m_pDxL->SetWidth(1.f);
	
	return 1;
}


void CGmWrk2::Destroy()
{
	SAFE_RELEASE(	m_pDxL	);
}


INT CGmWrk2::Restore()
{
	INT i=0, idx=0;
		
	m_pDxL->OnResetDevice();
	
	m_fW  = 20;
	m_icX = INT(GMAIN->m_d3dpp.BackBufferWidth * 2/m_fW);
	m_icY = INT(GMAIN->m_d3dpp.BackBufferHeight* 2/m_fW);


	McUtil_Calloc(m_pLine, m_icX * 4 + m_icY * 4);

	for(i=0; i<m_icX; ++i)
	{
		idx = i;

		m_pLine[idx*4+0] = VEC2( (i+0) * 2 * m_fW,							   0);
		m_pLine[idx*4+1] = VEC2( (i+0) * 2 * m_fW, GMAIN->m_d3dpp.BackBufferHeight);
		m_pLine[idx*4+2] = VEC2( (i+1) * 2 * m_fW, GMAIN->m_d3dpp.BackBufferHeight);
		m_pLine[idx*4+3] = VEC2( (i+1) * 2 * m_fW,							   0);
	}

	for(i= 0; i<m_icY; ++i)
	{
		idx = m_icX + i;

		m_pLine[idx*4+0] = VEC2(							  0, (i+0) * 2 * m_fW);
		m_pLine[idx*4+1] = VEC2( GMAIN->m_d3dpp.BackBufferWidth, (i+0) * 2 * m_fW);
		m_pLine[idx*4+2] = VEC2( GMAIN->m_d3dpp.BackBufferWidth, (i+1) * 2 * m_fW);
		m_pLine[idx*4+3] = VEC2(							  0, (i+1) * 2 * m_fW);
	}
	
	return 1;
}


void CGmWrk2::Invalidate()
{
	m_pDxL->OnLostDevice();
	SAFE_FREE(	m_pLine	);
}


INT CGmWrk2::FrameMove()
{
	return 1;
}

void CGmWrk2::Render()
{
	GDEVICE->Clear( 0, 0, GMAIN->m_dwClr, 0x00004499, 1.0f, 0L );
	m_pDxL->Draw(m_pLine		, m_icX, 0x44000000);
	m_pDxL->Draw(m_pLine+m_icX*4, m_icY, 0x44000000);


	RECT rt={5,10, 1024,30};
	GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
}


void CGmWrk2::RenderS()
{
}
