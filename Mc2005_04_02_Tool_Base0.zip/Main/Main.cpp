// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	m_ePhCur		= GP_WRK1;
	m_ePhOld		= GP_WRK2;

	m_pD3DXFont		= NULL;
	m_pInput		= NULL;	
}


HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pInput	,	CMcInput	);

	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;

	m_Wrk.Create(m_hWnd);
	SetFocus(GHWND);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);

	SAFE_DESTROY(	&m_Wrk		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	SAFE_RESTORE(	&m_Wrk		);

	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	SAFE_INVALID(	&m_Wrk		);

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	SAFE_FRMOV(	m_pInput	);													// Update Input
	
	
	m_ePhOld = m_ePhCur;

	SAFE_FRMOV(&m_Wrk	);
	
	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 1;
	
	if(!GDEVICE)
		return -1;

	m_Wrk.Render();


	GDEVICE->Clear( 0L, 0, m_dwClr, 0x00006699, 1.0f, 0L );
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;

	RECT rc ={0,5, 800, 30};

	m_pD3DXFont->DrawText(NULL, m_sMsg, -1, &rc, 0, D3DXCOLOR(1,1,0,1));
	GDEVICE->EndScene();
	

	return S_OK;
}
