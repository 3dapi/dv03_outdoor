// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	EGmPhase			m_ePhCur	;											// Current Phase
	EGmPhase			m_ePhOld	;											// Current Phase
	TCHAR				m_sMsg[512]	;
	LPD3DXFONT			m_pD3DXFont	;
	CMcInput*			m_pInput	;											// Keyboard Mouse
	
public:
	CWndWrk				m_Wrk		;

public:
	CMain();
	virtual HRESULT		Init();
	virtual HRESULT		Restore();
	virtual HRESULT		Invalidate();
	virtual HRESULT		Destroy();
	virtual HRESULT		Render();
	virtual HRESULT		FrameMove();
	LRESULT				MsgProc(HWND, UINT, WPARAM, LPARAM);
};

#endif