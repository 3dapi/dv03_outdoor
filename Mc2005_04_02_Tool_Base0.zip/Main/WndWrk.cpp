// Implementation of the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


//CLSS_DLG_DEFINE(CWndWrk, MsgPrc);

static CWndWrk*	g_pWndDialogCWndWrk;

INT_PTR CWndWrk :: CWndWrkWndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP)
{
	return (g_pWndDialogCWndWrk)-> MsgPrc (hW, uM, wP, lP);
}

CWndWrk :: CWndWrk ()
{
	g_pWndDialogCWndWrk = this;
}


CWndWrk:: ~ CWndWrk ()
{
}


INT CWndWrk::Create(HWND hWnd)
{
	m_hWnd		= 0;
	m_hwTab		= 0;
	m_nTabCur	=0;
	m_nTabOld	=-1;

	RECT rt1;
	RECT rt2;

	INT iWd;
	INT iHg;
	INT iX;
	INT iY;


	m_hWnd = CreateDialog(GHINST, MAKEINTRESOURCE(IDD_WRK), hWnd, CLSS_DLG_WNDPROC(CWndWrk));
	
	GetWindowRect(GHWND, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWd = rt2.right - rt2.left;
	iHg=  rt2.bottom- rt2.top;

	iX = rt1.left - iWd;
	iY = rt1.top;
	
	MoveWindow(m_hWnd, iX, iY, iWd, iHg, TRUE);
	GetWindowRect(m_hWnd, &rt2);

	ShowWindow(m_hWnd, SW_SHOW);
	
	return 1;
}


void CWndWrk::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}



INT	CWndWrk::Restore()
{
	return 1;
}


void CWndWrk::Invalidate()
{
}


INT CWndWrk::FrameMove()
{
	return 1;
}



void CWndWrk::Render()
{
}


LRESULT CWndWrk::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_NOTIFY:
		{
			break;
		}// case

	}// switch

	return(FALSE);
}