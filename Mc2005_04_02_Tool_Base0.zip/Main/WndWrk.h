// Interface for the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK_H_
#define _WNDWRK_H_


class CWndWrk
{
public:
	HWND			m_hWnd		;

	HWND			m_hwTab		;												// Tab control handle

	INT				m_nTabCur	;
	INT				m_nTabOld	;

public:
//	CLSS_DLG_DECLEAR( CWndWrk );

	CWndWrk ();
	virtual ~CWndWrk ();
	static INT_PTR	CWndWrkWndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP);

	INT		Create(HWND hWnd);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
	
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
};

#endif