// Implementation of the CGmWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CGmWrk1::CGmWrk1()
{
}


CLASS_CLEAN_ALL(CGmWrk1);


INT CGmWrk1::Init()
{
	return 1;
}

void CGmWrk1::Destroy()
{
}

INT CGmWrk1::Restore()
{
	return 1;
}

void CGmWrk1::Invalidate()
{
}

INT CGmWrk1::FrameMove()
{
	return 1;
}


void CGmWrk1::Render()
{
	GDEVICE->Clear( 0, 0, GMAIN->m_dwClr, 0x00006699, 1.0f, 0L );

	SAFE_RENDER(	GCAM	);


	RECT rt={5,10, 1024,30};
	GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
}

void CGmWrk1::RenderS()
{
}
