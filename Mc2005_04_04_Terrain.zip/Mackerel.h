// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


class CMain : public CD3DApplication
{
public:
	ID3DXFont*			m_pD3DXFont	;											// D3DX font
	CMcInput*			m_pInput	;
	CMcCamera*			m_pCam		;

	CMcField*			m_pField	;
	
public:
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT Init();
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	virtual HRESULT Destroy();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	virtual HRESULT FinalCleanup();
	virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );
	
	HRESULT RenderText();
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMain();
	virtual ~CMain();
};