#include "_StdAfx.h"

//-----------------------------------------------------------------------------
// Global access to the app (needed for the global WndProc())
//-----------------------------------------------------------------------------

CMain* g_pApp  = NULL;


//-----------------------------------------------------------------------------
// Name: WinMain()
// Desc: Entry point to the program. Initializes everything, and goes into a
//       message-processing loop. Idle time is used to render the scene.
//-----------------------------------------------------------------------------
INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain d3dApp;

	//(E) 2004-12-20 Editor: AFEW
	g_pApp  = &d3dApp;
	d3dApp.m_hInst = hInst;
	
	InitCommonControls();
	if( FAILED( d3dApp.Create( hInst ) ) )
		return 0;
	
	return d3dApp.Run();
}



//-----------------------------------------------------------------------------
// Name: ConfirmDevice()
// Desc: Called during device initialization, this code checks the display device
//       for some minimum set of capabilities
//-----------------------------------------------------------------------------
HRESULT CMain::ConfirmDevice( D3DCAPS9* pCaps, DWORD dwBehavior,
										 D3DFORMAT Format )
{
	UNREFERENCED_PARAMETER( Format );
	UNREFERENCED_PARAMETER( dwBehavior );
	UNREFERENCED_PARAMETER( pCaps );
	
	BOOL bCapsAcceptable;
	
	// TODO: Perform checks to see if these display caps are acceptable.
	bCapsAcceptable = TRUE;
	
	if( bCapsAcceptable )         
		return S_OK;
	else
		return E_FAIL;
}




//-----------------------------------------------------------------------------
// Name: FinalCleanup()
// Desc: Paired with OneTimeSceneInit()
//       Called before the app exits, this function gives the app the chance
//       to cleanup after itself.
//-----------------------------------------------------------------------------
HRESULT CMain::FinalCleanup()
{
	// TODO: Perform any final cleanup needed
	return S_OK;
}

