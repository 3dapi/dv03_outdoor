// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }


CMcField::CMcField()
{
	m_pVtx	= NULL;
	m_pIdx	= NULL;
	m_pTx0	= NULL;
	m_iNvx	= 0;
	m_iNix	= 0;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
	m_fAl = 45;
	m_iW = 32;
	m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	
	//	Load texture
	McUtil_TextureLoad("Texture/detail2.jpg", m_pTx0, 0x00000000);
	
	MapLoad();	

	memset(m_Lgt, 0, sizeof(m_Lgt) );

	m_Lgt[0].Type = D3DLIGHT_DIRECTIONAL;
	m_Lgt[1].Type = D3DLIGHT_DIRECTIONAL;
	m_Lgt[2].Type = D3DLIGHT_DIRECTIONAL;
	m_Lgt[3].Type = D3DLIGHT_DIRECTIONAL;

	m_Lgt[0].Diffuse = D3DXCOLOR( .6F, .6F, .6F, 1.F);
	m_Lgt[1].Diffuse = D3DXCOLOR( .25F, .0F, 0.F, 0.F);
	m_Lgt[1].Direction = VEC3( -cosf(D3DXToRadian(45)), -sinf(D3DXToRadian(45)), 0);
	m_Lgt[2].Diffuse = D3DXCOLOR( 0.F, .25F, .0F, 1.F);
	m_Lgt[2].Direction = VEC3( -cosf(D3DXToRadian(135)), -sinf(D3DXToRadian(135)), 0);
	m_Lgt[3].Diffuse = D3DXCOLOR( 0.F, .0F, .25F, 1.F);
	m_Lgt[3].Direction = VEC3( 0, -sinf(D3DXToRadian(45)), -cosf(D3DXToRadian(45)));
	

	D3DUtil_InitMaterial( m_mtl, 1.0f, .50f, 1.0f );
	
	return 1;
}


void CMcField::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pIdx	);
	
	SAFE_RELEASE(	m_pTx0	);
}


INT	CMcField::FrameMove()
{
	if( GINPUT->KeyState(DIK_LEFT))
	{
		++m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}
	
	if( GINPUT->KeyState(DIK_RIGHT))
	{
		--m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}
	
	return 1;
}

void CMcField::Render()
{
	
	m_Lgt[0].Direction = m_vcLgt;
			
	GDEVICE->SetLight( 0, &m_Lgt[0] );	GDEVICE->LightEnable( 0, TRUE );
	GDEVICE->SetLight( 1, &m_Lgt[1] );	GDEVICE->LightEnable( 1, TRUE );
	GDEVICE->SetLight( 2, &m_Lgt[2] );	GDEVICE->LightEnable( 2, TRUE );
	GDEVICE->SetLight( 3, &m_Lgt[3] );	GDEVICE->LightEnable( 3, TRUE );
	
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  TRUE);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	GDEVICE->SetRenderState( D3DRS_AMBIENT,        0x00F0F0F );
	
	GDEVICE->SetMaterial( &m_mtl );
	


	DWORD dFog = D3DXCOLOR(.5f, .3f, .5f, 1.0f);

	dFog = 0xFF336699;
	float fStart = 200.0f;
	float fEnd   = 5000.0f;

	GDEVICE->SetRenderState(D3DRS_FOGENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
	GDEVICE->SetRenderState(D3DRS_FOGCOLOR, dFog);
	GDEVICE->SetRenderState(D3DRS_FOGSTART, FtoDW(fStart));
	GDEVICE->SetRenderState(D3DRS_FOGEND,   FtoDW(fEnd));

	D3DXMATRIX	mtWorld;
	D3DXMatrixIdentity(&mtWorld);
	
	GDEVICE->SetTransform(D3DTS_WORLD, &mtWorld);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );

	GDEVICE->SetTexture(0, m_pTx0);
	GDEVICE->SetFVF(m_dFVF);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNvx, m_iNix, m_pIdx, D3DFMT_INDEX16, m_pVtx, m_iVxS);
	
	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);
	D3DXMatrixIdentity(&mtWorld);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtWorld);
}




void CMcField::NormalSet()
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	
	for(INT z=0; z<m_iN; ++z)
	{
		for(INT x=0; x<m_iN; ++x)
		{
			m_pVtx[m_iN*z + x].n = -NormalVec(z, x);
		}
	}
}


VEC3 CMcField::NormalVec(int z, int x)
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	INT		i;

	INT		index = m_iN*z + x;
	INT		iVtx[10];

	iVtx[9] = index;
	iVtx[0] = iVtx[9];
	iVtx[1] = iVtx[9];
	iVtx[2] = iVtx[9];
	iVtx[3] = iVtx[9];
	iVtx[4] = iVtx[9];
	iVtx[5] = iVtx[9];
	iVtx[6] = iVtx[9];
	iVtx[7] = iVtx[9];
	iVtx[8] = iVtx[9];
	
	if(0==z && 0==x)
	{
		iVtx[0] = iVtx[9] + 1;
		iVtx[1] = iVtx[0] + m_iN;
		iVtx[2] = iVtx[9] + m_iN;
	}

	else if(0==z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] + m_iN;
		iVtx[1] = iVtx[0] - 1;
		iVtx[2] = iVtx[9] - 1;
	}

	else if(0==z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] - 1;			
		}
		else
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iN;
			iVtx[2] = iVtx[9] + m_iN;
			iVtx[3] = iVtx[2] - 1;
			iVtx[4] = iVtx[9] - 1;
		}
	}
	
	else if( (m_iN-1) == z && 0==x)
	{
		iVtx[0] = iVtx[9] - m_iN;
		iVtx[1] = iVtx[0] + 1;
		iVtx[2] = iVtx[9] + 1;
	}

	else if( (m_iN-1) == z && (m_iN-1) == x)
	{
		iVtx[0] = iVtx[9] - 1;
		iVtx[1] = iVtx[0] - m_iN;
		iVtx[2] = iVtx[9] - m_iN;

	}

	else if((m_iN-1) == z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
		}
		else
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[0] - m_iN;
			iVtx[2] = iVtx[9] - m_iN;
			iVtx[3] = iVtx[2] + 1;
			iVtx[4] = iVtx[9] + 1;
		}
	}

	else if(0 == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[9] + 1;
			iVtx[2] = iVtx[9] + m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] - m_iN;
			iVtx[1] = iVtx[0] + 1;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[2] + m_iN;
			iVtx[4] = iVtx[9] + m_iN;
		}
	}

	else if((m_iN-1) == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[9] - 1;
			iVtx[2] = iVtx[9] - m_iN;
		}
		else
		{
			iVtx[0] = iVtx[9] + m_iN;
			iVtx[1] = iVtx[0] - 1;
			iVtx[2] = iVtx[9] - 1;
			iVtx[3] = iVtx[2] - m_iN;
			iVtx[4] = iVtx[9] - m_iN;
		}
	}
	

	else
	{
		if(index%2)																// Ȧ ��
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iN;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[9] + m_iN;
			iVtx[4] = iVtx[0];
		}
		else																	// ¦ ��
		{
			iVtx[6] = index +m_iN	-1;		iVtx[5] = iVtx[6] + 1;	iVtx[4] = iVtx[5] + 1;
			iVtx[7] = index			-1;		iVtx[9] = iVtx[7] + 1;	iVtx[3] = iVtx[9] + 1;
			iVtx[0] = index -m_iN	-1;		iVtx[1] = iVtx[0] + 1;	iVtx[2] = iVtx[1] + 1;
			iVtx[8] = iVtx[0];
		}
	}

	for(i=0; i<8; ++i)
	{
		a = m_pVtx[iVtx[i+0] ].p - m_pVtx[iVtx[9] ].p;
		b = m_pVtx[iVtx[i+1] ].p - m_pVtx[iVtx[9] ].p;
		D3DXVec3Cross(&nT, &a, &b);
		D3DXVec3Normalize(&nT, &nT);
		n +=nT;
	}

	
	D3DXVec3Normalize(&n, &n);
	
	return n;
}



void CMcField::MapSave()
{
	INT x, z;
	TCHAR sFile[] = "Map/Height.raw";
	FILE* fp;
	
	fp = fopen(sFile, "rb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Height file load failed");
		return;
	}
	
	long end;
	
	fseek(fp, 0L, SEEK_SET);	fseek (fp, 0L, SEEK_END);	end	   = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	
	BYTE*	pHi = new BYTE[end];
	fread(pHi, sizeof(BYTE), end, fp);
	fclose(fp);
	
	m_dFVF = VtxNDUV1::FVF;
	m_iVxS = sizeof(VtxNDUV1);
	m_iNvx = end;
	m_iN = int(sqrtf( FLOAT(m_iNvx)));
	m_pVtx = new VtxNDUV1[m_iNvx];
	
	for(z=0; z<m_iN; ++z)
	{
		for(x=0; x<m_iN; ++x)
		{
			FLOAT fH = pHi[ (m_iN-1-z) * m_iN + x];
			DWORD c;
		
			if( (fH) < 1.f )
				c = D3DCOLOR_XRGB(255, 249, 157);
			else if( (fH) < 35.0f )
				c = D3DCOLOR_XRGB(124, 197, 118);
			else if( (fH) < 75.5f )
				c = D3DCOLOR_XRGB(  0, 166,  81);
			else if( (fH) < 100.0f )
				c = D3DCOLOR_XRGB( 25, 123,  48);
			else if( (fH) < 140.5f )
				c = D3DCOLOR_XRGB(115, 100,  87);
			else
				c = D3DCOLOR_XRGB(255, 255, 255);
			
			m_pVtx[z * m_iN + x].p = VEC3(FLOAT(x * m_iW), fH*4.5f, FLOAT(z * m_iW));
			m_pVtx[z * m_iN + x].d = c;
			m_pVtx[z * m_iN + x].u0 = x /2.f;
			m_pVtx[z * m_iN + x].v0 = z /2.f;
		}
	}

	SAFE_DELETE_ARRAY(	pHi	);

	NormalSet();

	
	INT iN = m_iN-1;
	
	m_iNix = 8 * (m_iN-1)/2 * (m_iN-1)/2;
	
	m_pIdx = new VtxIdx[m_iNix];
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iN*z + m_iN+1 + 2*x;
			
			f[6] = index +m_iN-1;	f[5] = index + m_iN;	f[4] = index +m_iN+1;
			f[7] = index      -1;	f[8] = index	   ;	f[3] = index      +1;
			f[0] = index -m_iN-1;	f[1] = index - m_iN;	f[2] = index -m_iN+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pIdx[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}


	fp = fopen("Map/McMap.mpb", "wb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Save Map Failed");
		return;
	}
	
	fwrite(&m_iNvx, sizeof(m_iNvx),1 , fp);										// ���� �����͸� �����.
	fwrite(&m_iNix, sizeof(m_iNix),1 , fp);
	fwrite(&m_iVxS, sizeof(m_iVxS),1 , fp);
	fwrite(&m_dFVF, sizeof(m_dFVF),1 , fp);
	
	fwrite(m_pVtx, sizeof(VtxNDUV1), m_iNvx, fp);
	fwrite(m_pIdx, sizeof(VtxIdx), m_iNix, fp);

	fclose(fp);

	SAFE_DELETE_ARRAY(	m_pVtx	);
	SAFE_DELETE_ARRAY(	m_pIdx	);
}



void CMcField::MapLoad()
{
	FILE* fp;
	
	fp = fopen("Map/McMap.mpb", "rb");
	
	if(!fp)
	{
		MapSave();
	}

	fp = fopen("Map/McMap.mpb", "rb");
	

	fread(&m_iNvx, sizeof(m_iNvx),1 , fp);
	fread(&m_iNix, sizeof(m_iNix),1 , fp);
	fread(&m_iVxS, sizeof(m_iVxS),1 , fp);
	fread(&m_dFVF, sizeof(m_dFVF),1 , fp);
	
	m_pVtx = new VtxNDUV1[m_iNvx];
	m_pIdx = new VtxIdx[m_iNix];
	
	fread(m_pVtx, sizeof(VtxNDUV1), m_iNvx, fp);
	fread(m_pIdx, sizeof(VtxIdx), m_iNix, fp);

	fclose(fp);

	remove("Map/McMap.mpb");

	m_iN = int(sqrtf( FLOAT(m_iNvx)));
}
