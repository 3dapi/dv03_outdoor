// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

struct McMdl2D																	// Camera Dependent
{
	MATA	mtW;
};

struct McMdl3D																	// Camera Independent
{
	MATA	mtW;
};

class CMcField
{
protected:
	INT				m_nId;														// Index
	CHAR			m_sN[64];													// Name
	VEC3			m_vcP;														// Position


	INT				m_iNl;														// Lighting Num
	DLGT*			m_pLg;

	DMTL			m_Mtl;														// Material

	DWORD			m_dFc;														// Fog Color
	FLOAT			m_fFb;														// Fog Begin
	FLOAT			m_fFe;														// Fog End

	DWORD			m_dAb;														// Ambient color

	INT				m_iNx;														// Number of tile for Width
	INT				m_iWx;														// Width of tile for x;

	INT				m_iNi;														// Index Number
	VtxIdx*			m_pIx;

	INT				m_iNv;														// Vertex Number
	VtxNDUV1*		m_pVx;
	FLOAT			m_fUV;														// UV Width

	INT				m_iVs;														// Vertex Size
	DWORD			m_dFVF;


	INT				m_iNt;														// Texture Num
	CHAR			(*m_sNt)[128];													// 0 ��° �ؽ�ó �̸�
	PDTX*			m_pTx;

	INT				m_iNd2;														// Mc2D Model Number
	McMdl2D*		m_pMd2;

	INT				m_iNd3;														// Mc3D Model Number
	McMdl3D*		m_pMd3;
	


protected:
	MATA			m_mtW;
	FLOAT			m_fAl;
	VEC3			m_vcLgt;
	
	
public:
	CMcField();
	~CMcField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();
	
protected:
	void	NormalSet();
	VEC3	NormalVec(int z, int x);

	void	MapLoad();
	void	MapSave();
};

#endif