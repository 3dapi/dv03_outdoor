// Interface for Mc vertex formats.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCVTXFMT_H_
#define _MCVTXFMT_H_

struct VtxIdx														// Index structure
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	VtxIdx()						: a(0),b(1),c(2){}
	VtxIdx(WORD A,WORD B,WORD C)	: a(A),b(B),c(C){}
	VtxIdx(WORD* R)					: a(R[0]),b(R[1]),c(R[2]){}

	operator WORD* ()				{	return (WORD *) &a;					}
	operator CONST WORD* () const	{	return (CONST WORD *) &a;			}
};


struct VtxNDUV1														// Normal + Diffuse + Texture1
{
	VEC3	p;
	VEC3	n;
	DWORD	d;
	FLOAT	u0,v0;

	VtxNDUV1(){}
	VtxNDUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT nX,FLOAT nY,FLOAT nZ
		, FLOAT U,FLOAT V
		,DWORD D=0xFFFFFFFF):p(X,Y,Z),n(nX,nY,nZ),u0(U),v0(V),d(D){}

	enum { FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1) };
};


struct VtxD															// Diffuse
{
	VEC3	p;
	DWORD	d;
	
	VtxD()											: p(0,0,0),d(0XFFFFFFFF){}
	VtxD(VEC3 P, DWORD D=0xFFFFFFFF)				: p(P),d(D){}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0xFFFFFFFF): p(X,Y,Z),d(D){}

	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE) };
};


struct VtxDUV1														// Diffuse + Texture 1
{
	VEC3	p;
	DWORD	d;
	FLOAT	u0, v0;
	
	VtxDUV1()					: p(0,0,0),u0(0),v0(0),d(0xFFFFFFFF){}
	VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z,FLOAT U,FLOAT V
		, DWORD D=0xFFFFFFFF)		: p(X,Y,Z),u0(U),v0(V),d(D){}
	
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) };
};

#endif