// Interface for the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK1_H_
#define _WNDWRK1_H_

class CWndWrk1
{
public:
	HWND			m_hWnd		;
	McSwpWn			m_SwpWn		;												// Swap Chain Window
	
public:
	CLSS_DLG_DECLEAR( CWndWrk1 );

	INT		Create(HWND hWnd);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	LRESULT	MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif