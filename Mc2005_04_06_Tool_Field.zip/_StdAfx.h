// All Header files.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_

#define STRICT
#define WIN32_LEAN_AND_MEAN														// Exclude rarely-used stuff from Windows headers
#define _WIN32_WINNT			0x0400
#define DIRECTINPUT_VERSION		0x0800

#pragma once

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)


// Static Library
#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)
#pragma comment(lib, "dinput8.lib"		)										// for Direct Input
#pragma comment(lib, "Version.lib"		)										// DX version Check

// STL
#include <vector>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;



#include <winsock2.h>															//For net work...
#include <windows.h>
#include <windowsx.h>
#include <assert.h>
#include <comdef.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <atlbase.h>
#include <malloc.h>
#include <math.h>
#include <mmsystem.h>
#include <process.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>

#include <tchar.h>

#include <D3D9.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <dxfile.h>
#include <d3dx9mesh.h>
#include <dinput.h>
#include <rmxfguid.h>

#include "_D3D/D3DUtil.h"
#include "_D3D/DXUtil.h"
#include "_D3D/D3DEnum.h"
#include "_D3D/D3DSettings.h"
#include "_D3D/resource.h"
#include "_D3D/D3DApp.h"


////////////////////////////////////////////////////////////////////////////////
// Global pointer Macro..

#define GMAIN				g_pApp
#define GHINST				g_pApp->m_hInst
#define GHWND				g_pApp->m_hWnd
#define GHDC				g_pApp->m_hDC

#define GDEVICE				g_pApp->m_pd3dDevice
#define GSPRITE				g_pApp->m_pd3dSprite
#define GBACKSF				g_pApp->m_pBackBuffer
#define GINPUT				g_pApp->m_pInput
#define GCAM				g_pApp->m_pCam

#define GMOUSEPOS			GINPUT->GetMousePos()
#define GET_KEY(key)		if(GINPUT->GetKey(key))
#define KEY_STATE(key)		if(GINPUT->KeyState(key))


////////////////////////////////////////////////////////////////////////////////
//

// common
#include "Common/McType.h"														// Base type
#include "Common/McCommon.h"													// Common data
#include "Common/McMath.h"														// Math
#include "Common/McVtxFmt.h"													// vertex format
#include "Common/McInput.h"														// Keyboard and Mouse class
#include "Common/McCam.h"														// Camera

// Util
#include "Util/McUtil.h"


// Field
#include "Field/McField.h"



// Main class
#include "Main/WndWrk1.h"
#include "Main/WndWrk2.h"
#include "Main/WndWrk.h"

// Game Phase
#include "zPhase/GmWrk1.h"														// Work1
#include "zPhase/GmWrk2.h"														// Work2

#include "Main/Main.h"															// Main class

// Extern
extern	CMain*			g_pApp	;												// Main application

extern	McExcInf		g_Inf	;												// Game Info
extern	MEMORYSTATUS	g_MmSt	;												// for Memory state

#if EXC_MTX_ON
	extern	HANDLE		g_hMtx	;
#endif

#endif