// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcField::CMcField()
{
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
//	MapLoad();

	return 1;
}


void CMcField::Destroy()
{
	m_Msh.Destroy();
}


INT	CMcField::FrameMove()
{
	return 1;
}

void CMcField::Render()
{
	if(!m_Msh.m_pVx)
		return;

	m_Msh.Render();
}



INT CMcField::MapSave()
{
	FILE* fp;

	fp = fopen("Map/McMap.mpb", "wb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Save Map Failed");
		return -1;
	}
	
	m_Inf.FileWrite(fp);
	m_Msh.FileWrite(fp);
	m_Obj.FileWrite(fp);	

	fclose(fp);

	SAFE_DELETE_ARRAY(	m_Msh.m_pVx	);
	SAFE_DELETE_ARRAY(	m_Msh.m_pIx	);

	return 1;
}



void CMcField::CreateMesh(INT iNx, INT iWx, FLOAT fUV)
{
	m_Msh.CreateMesh(iNx+1, iWx+1, fUV);
}







INT CMcField::MapLoad()
{
	FILE* fp;
	
	fp = fopen("Map/McMap.mpb", "rb");
	
	if(!fp)
	{
		m_Msh.Init();

		if(FAILED(MapSave()))
			return -1;
		
		Destroy();
	}

	
	fp = fopen("Map/McMap.mpb", "rb");
	
	m_Inf.FileRead(fp);	
	m_Msh.FileRead(fp);
	m_Obj.FileRead(fp);

	fclose(fp);

//	remove("Map/McMap.mpb");	

	return 1;
}


