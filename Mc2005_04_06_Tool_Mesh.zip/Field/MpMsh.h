// Interface for the CMpMsh class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPMSH_H_
#define _MPMSH_H_


class CMpMsh																	// Mesh
{
public:
	MATA		m_mtW;															// World Matrix

	INT			m_iNl;															// Lighting Num
	DLGT*		m_pLg;

	DMTL		m_Mtl;															// Material

	DWORD		m_dFc;															// Fog Color
	FLOAT		m_fFb;															// Fog Begin
	FLOAT		m_fFe;															// Fog End

	DWORD		m_dAb;															// Ambient color

	INT			m_iNx;															// Number of tile for Width
	INT			m_iWx;															// Width of tile for x;

	INT			m_iNi;															// Index Number
	VtxIdx*		m_pIx;

	INT			m_iNv;															// Vertex Number
	VtxNDUV1*	m_pVx;
	FLOAT		m_fUV;															// UV Width

	INT			m_iVs;															// Vertex Size
	DWORD		m_dFVF;


	INT			m_iNt;															// Texture Num
	CHAR		(*m_sNt)[128];													// 0 ��° �ؽ�ó �̸�
	PDTX*		m_pTx;

public:
	CMpMsh();
	virtual ~CMpMsh();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();


	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);

	
	void	VertexSet();
	void	NormalSet();
	void	IndexSet();
	void	MaterialSet();

	VEC3	NormalVec(int z, int x);
	INT		FileRead(FILE* fp);
	INT		FileWrite(FILE* fp);
};

#endif