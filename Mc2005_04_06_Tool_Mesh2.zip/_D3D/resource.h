//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Blame.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDD_DLG_CONNECT                 146
#define IDB_WRK                         147
#define IDD_VIW                         148
#define IDD_WRK                         149
#define IDD_WRK1                        150
#define IDD_WRK2                        151
#define IDD_CREATE                      154
#define IDC_DEVICE_CMB                  1000
#define IDC_ADAPTER_CMB                 1002
#define IDC_ADAPTERFORMAT_CMB           1003
#define IDC_RESOLUTION_CMB              1004
#define IDC_MULTISAMPLE_CMB             1005
#define IDC_REFRESHRATE_CMB             1006
#define IDC_BACKBUFFERFORMAT_CMB        1007
#define IDC_DEPTHSTENCILFORMAT_CMB      1008
#define IDC_VERTEXPROCESSING_CMB        1009
#define IDC_PRESENTINTERVAL_CMB         1010
#define IDC_MULTISAMPLE_QUALITY_CMB     1011
#define IDC_WINDOW                      1016
#define IDC_FULLSCREEN                  1018
#define IDC_TXT_ADDRESS                 1019
#define IDC_TXT_PORT                    1020
#define IDC_VIW_TX_M                    1023
#define IDC_VIW_TX_S                    1024
#define IDC_VIW_PANEL                   1025
#define IDC_WRK_TAB                     1032
#define IDC_WRK1_PANNEL                 1042
#define IDC_WRK1_RC                     1043
#define IDC_WRK1_TREE                   1047
#define IDC_WRK2_PANNEL                 1059
#define IDC_WRK2_TREE                   1066
#define IDC_NAME                        1110
#define IDC_TILE_NUM_X                  1111
#define IDC_TILE_WIDTH                  1112
#define IDC_TILE_UV                     1113
#define IDC_CRT_OK                      1114
#define IDC_CRT_CANCEL                  1115
#define IDC_WRK1_CREATE_LOCAL           1116
#define IDC_WRK1_LOCAL_LOAD             1117
#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_EXIT                        40006
#define IDM_BACK                        40014
#define IDM_RETURN                      40015
#define IDM_RETURN_CTRL                 40016
#define IDM_TAB                         40017
#define IDM_TAB_BACK                    40018
#define IDM_RETURN_SHIFT                40020
#define IDM_ESC                         40021
#define ID_MENUITEM40022                40022
#define IDM_SOLID                       40023
#define IDM_LGT                         40024
#define ID_VIEW_FIELD                   40025
#define IDM_FOG                         40026
#define IDM_NEW                         40027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1117
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
