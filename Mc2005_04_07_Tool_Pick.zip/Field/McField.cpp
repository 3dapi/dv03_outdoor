// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcField::CMcField()
{
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
//	MapLoad();

	return 1;
}


void CMcField::Destroy()
{
	m_Msh.Destroy();
}


INT	CMcField::FrameMove()
{
	if(!m_Msh.m_pVx)
		return 1;


	if(GINPUT->ButtonPrss(0))
	{
		m_vVtx.clear();

		VEC3 pck;

		for(INT i=0; i<m_Msh.m_iNi; ++i)
		{
			WORD	a, b, c;

			a = m_Msh.m_pIx[i].a;
			b = m_Msh.m_pIx[i].b;
			c = m_Msh.m_pIx[i].c;

			VEC3 pPck;
			VEC3 p0 = m_Msh.m_pVx[a].p;
			VEC3 p1 = m_Msh.m_pVx[b].p;
			VEC3 p2 = m_Msh.m_pVx[c].p;

			if(SUCCEEDED(GetPickPos(pPck, p0, p1, p2)))
			{
				m_vVtx.push_back(p0);
				m_vVtx.push_back(p1);
				m_vVtx.push_back(p2);
			}
		}

	}

	return 1;
}

void CMcField::Render()
{
	if(!m_Msh.m_pVx)
		return;

	m_Msh.Render();


	GDEVICE->SetRenderState( D3DRS_LIGHTING,	FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,	FALSE);
	GDEVICE->SetRenderState( D3DRS_FILLMODE,	D3DFILL_SOLID);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(Vtx::FVF);


	for(int i=0; i<m_vVtx.size(); ++i)
	{
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_vVtx[i*3], sizeof(Vtx));
	}
}



INT CMcField::MapSave()
{
	FILE* fp;

	fp = fopen("Map/McMap.mpb", "wb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Save Map Failed");
		return -1;
	}
	
	m_Inf.FileWrite(fp);
	m_Msh.FileWrite(fp);
	m_Obj.FileWrite(fp);	

	fclose(fp);

	SAFE_DELETE_ARRAY(	m_Msh.m_pVx	);
	SAFE_DELETE_ARRAY(	m_Msh.m_pIx	);

	return 1;
}



void CMcField::CreateMesh(INT iNx, INT iWx, FLOAT fUV)
{
	m_Msh.CreateMesh(iNx+1, iWx+1, fUV);
}







INT CMcField::MapLoad()
{
	FILE* fp;
	
	fp = fopen("Map/McMap.mpb", "rb");
	
	if(!fp)
	{
		m_Msh.Init();

		if(FAILED(MapSave()))
			return -1;
		
		Destroy();
	}

	
	fp = fopen("Map/McMap.mpb", "rb");
	
	m_Inf.FileRead(fp);	
	m_Msh.FileRead(fp);
	m_Obj.FileRead(fp);

	fclose(fp);

//	remove("Map/McMap.mpb");	

	return 1;
}


INT	CMcField::GetPickPos(VEC3& pPck, VEC3& p0, VEC3& p1, VEC3& p2)
{
	VEC3	vcCamPos= GCAM->GetCamPos();
	VEC3	vcRayDir = GCAM->Get3DDir();

	FLOAT	U, V, D;

//	// 1 ----- 3
//	// | .     |
//	// |   .   |
//	// |     . |
//	// 0 ----- 2
//
//	VEC3	p0;
//	VEC3	p1;
//	VEC3	p2;

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		pPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;
	}

	return -1;
}