// Implementation of the CWndCreate class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndCreate, MsgPrc);


INT CWndCreate::Create(HWND hWnd)
{
	m_iNx	= 0;
	m_iWx	= 0;
	m_fUV	= 2.f;

	m_hWPrn= hWnd;
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_CREATE), m_hWPrn, CLSS_DLG_WNDPROC(CWndCreate));

	RECT rt1;
	RECT rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(m_hWPrn, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left + 350;
	iY = rt1.top  + 350;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);

	SetDlgItemText(m_hWnd, IDC_NAME, "Town 1");
	SetDlgItemInt(m_hWnd, IDC_TILE_NUM_X, 16, 0);
	SetDlgItemInt(m_hWnd, IDC_TILE_WIDTH, 128, 0);
	SetDlgItemInt(m_hWnd, IDC_TILE_UV, 2, 0);
	
	return 1;
}

void CWndCreate::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}


void CWndCreate::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}

LRESULT CWndCreate::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_CRT_OK:
				{
					GetDlgItemText(m_hWnd, IDC_NAME, m_sN, sizeof(m_sN));
					m_iNx = GetDlgItemInt(m_hWnd, IDC_TILE_NUM_X, 0, 0);
					m_iWx = GetDlgItemInt(m_hWnd, IDC_TILE_WIDTH, 0, 0);
					m_fUV = GetDlgItemFlt(m_hWnd, IDC_TILE_UV);

					GMAIN->m_pGmWrk1->m_pField->CreateMesh(m_iNx, m_iWx, m_fUV);
					SendMessage(hWnd, WM_CLOSE, 0, 0);

					break;
				}

				case IDC_CRT_CANCEL:
				{
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}
			}

			break;
		}

		case WM_CLOSE:
		{
			DestroyWindow( hWnd );
			m_hWnd	= NULL;
			break;
		}
	}

	return(FALSE);
}