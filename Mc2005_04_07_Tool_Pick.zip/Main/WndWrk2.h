// Interface for the CWndWrk2 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK2_H_
#define _WNDWRK2_H_

class CWndWrk2
{
public:
	HWND			m_hWnd		;
	McSwpWn			m_SwpWn		;												// Swap Chain Window

public:
	CLSS_DLG_DECLEAR( CWndWrk2 );

	INT		Create(HWND hWnd);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
	
	LRESULT	MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
};

#endif