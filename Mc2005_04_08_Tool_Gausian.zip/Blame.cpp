// Program start.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CMain*			g_pApp	= 0	;
McExcInf		g_Inf		;
MEMORYSTATUS	g_MmSt		;


INT	McUtil_ReadBaseInfo();

#if EXC_MTX_ON
	HANDLE		g_hMtx		= NULL;
#endif


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
    CMain	d3dApp;

	GlobalMemoryStatus(&g_MmSt);
	
#if EXC_MTX_ON
	g_hMtx = OpenMutex(SYNCHRONIZE, FALSE, EXC_MTX);							// ������ ���α׷��� ����ǰ� �ִ��� Ȯ��

	if(g_hMtx)
		return -1;
#endif
	
	McUtil_SetCurrentDirectory();
	McUtil_ReadBaseInfo();


	d3dApp.m_hInst = hInst;
    g_pApp  = &d3dApp;

    InitCommonControls();

    if( FAILED( d3dApp.Create( hInst ) ) )
        return 0;
	
#if EXC_MTX_ON
		g_hMtx = CreateMutex(NULL, TRUE, EXC_MTX);
#endif
	
    d3dApp.Run();
	
#if EXC_MTX_ON
	if(g_hMtx)
	{
		CloseHandle(g_hMtx);
		g_hMtx	= NULL;
	}
#endif

	return 1;
}


INT	McUtil_ReadBaseInfo()
{
	TCHAR	sExe1[512];

	sprintf(g_Inf.sVersion, McUtil_DWtoStr(MC_FL_VER));
	strcpy(sExe1, GetCommandLine());

	GetCurrentDirectory(sizeof(g_Inf.sExcPath), g_Inf.sExcPath);

	return 1;
}












LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				TCHAR strMsg[MAX_PATH];
				wsprintf( strMsg, TEXT("Loading... Please wait") );
				RECT rct;
				GetClientRect( hWnd, &rct );
				DrawText( hDC, strMsg, -1, &rct, DT_CENTER|DT_VCENTER|DT_SINGLELINE );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_MOVE:
		{
			if(FALSE == m_bLoadingApp)
			{
				RECT rt1;
				RECT rt2;
				INT iWidth;
				INT iHeight;
				INT iX;
				INT iY;
				
				GetWindowRect(GHWND, &rt1);
				GetWindowRect(m_Wrk.m_hWnd, &rt2);
					
				iWidth = rt2.right - rt2.left;
				iHeight=  rt2.bottom- rt2.top;

				iX = rt1.left - iWidth;
				iY = rt1.top;// + iHeight;
				
				MoveWindow(m_Wrk.m_hWnd, iX, iY, iWidth, iHeight, TRUE);


			}

			break;
		}// case WM_MOVE
			

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDM_TOGGLEFULLSCREEN:
				{
					if(m_bWindowed)
					{
						ShowWindow(m_Wrk.m_hWnd, SW_HIDE);
					}
					else
					{
						ShowWindow(m_Wrk.m_hWnd, SW_SHOW);
					}


					break;
				}

				case IDM_FOG:
				{
					m_bFog ^=1;

					if(m_bFog)
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_SOLID:
				{
					if( D3DFILL_SOLID == m_bFill)
						m_bFill = D3DFILL_WIREFRAME;

					else
						m_bFill = D3DFILL_SOLID;

					if( D3DFILL_SOLID == m_bFill)
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LGT:
				{
					m_bLgt ^=1;

					if(m_bLgt)
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}
			}

			break;

		}// case WM_COMMAND

	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}