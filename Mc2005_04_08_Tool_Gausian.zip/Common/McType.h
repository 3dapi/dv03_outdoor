// Typedef for the Mc types.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCTYPE_H_
#define _MCTYPE_H_

// Window
typedef WNDPROC									LPWNDPROC;						// for Window Message
typedef DLGPROC									LPDLGPROC;						// for Dialog Message


// Vector
typedef D3DXVECTOR2								VEC2;
typedef	D3DXVECTOR3								VEC3;
typedef D3DXVECTOR4								VEC4;
typedef D3DXMATRIX								MATA;
typedef D3DXQUATERNION							QUAT;
typedef D3DXCOLOR								DCLR;

typedef	LPDIRECT3D9								PD3D;
typedef LPDIRECT3DDEVICE9						PDEV;
typedef	LPD3DXSPRITE							PDSP;

typedef D3DVIEWPORT9							DVWP;

typedef LPDIRECT3DTEXTURE9						PDTX;
typedef	D3DXIMAGE_INFO							DIMG;
typedef LPDIRECT3DCUBETEXTURE9					PDCB;
typedef LPDIRECT3DVOLUMETEXTURE9				PDVT;
typedef ID3DXRenderToEnvMap*					PDRE;

typedef LPDIRECT3DSURFACE9						PDSF;
typedef LPD3DXRENDERTOSURFACE					PDRS;
typedef	LPDIRECT3DSWAPCHAIN9					PDSW;							//	Swap chain

typedef LPDIRECT3DVERTEXBUFFER9					PDVB;
typedef LPDIRECT3DSTATEBLOCK9					PDBL;
typedef LPDIRECT3DINDEXBUFFER9					PDIB;

//typedef LPDIRECTSOUND3DBUFFER					PDSD;
//typedef LPDIRECTSOUND3DLISTENER					PDSL;

typedef LPDIRECT3DVERTEXSHADER9					PDVS;
typedef LPDIRECT3DVERTEXDECLARATION9			PDVD;
typedef LPDIRECT3DPIXELSHADER9					PDPS;

typedef	LPD3DXEFFECT							PDEF;

//typedef CD3DMesh								DMSH;							// X-file
typedef LPD3DXBUFFER							PDBF;
typedef LPD3DXMESH								PDMS;							// Mesh
typedef	LPD3DXFONT								PDFT;							// Dx font

typedef D3DVERTEXELEMENT9						DVTE;
typedef D3DLIGHT9								DLGT;
typedef D3DMATERIAL9							DMTL;

typedef vector<VEC2>							lsVC2;
typedef lsVC2::iterator							itVC2;

typedef vector<VEC3>							lsVC3;
typedef lsVC3::iterator							itVC3;

typedef vector<VEC4>							lsVC4;
typedef lsVC4::iterator							itVC4;

// about STL
typedef vector<INT>								lsINT;
typedef lsINT::iterator							itINT;

typedef vector<FLOAT>							lsFLT;
typedef lsFLT::iterator							itFLT;

typedef vector<WORD>							lsWD;
typedef lsWD::iterator							itWD;

typedef vector<DWORD>							lsDWD;
typedef lsDWD::iterator							itDWD;

typedef vector<RECT>							lsRc;
typedef lsRc::iterator							itRc;

typedef list<HANDLE>							lsHANDLE;
typedef lsHANDLE::iterator						itHANDLE;

#endif