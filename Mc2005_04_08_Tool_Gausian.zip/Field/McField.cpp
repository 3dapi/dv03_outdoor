// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcField::CMcField()
{
	m_bClick = false;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
//	MapLoad();

	return 1;
}


void CMcField::Destroy()
{
	m_Msh.Destroy();
}


INT	CMcField::FrameMove()
{
	if(!m_Msh.m_pVx)
		return 1;


	if(GINPUT->ButtonDn(0))
	{
		m_vVtx.clear();

		VEC3 pck;

		for(INT i=0; i<m_Msh.m_iNi; ++i)
		{
			WORD	a, b, c;

			a = m_Msh.m_pIx[i].a;
			b = m_Msh.m_pIx[i].b;
			c = m_Msh.m_pIx[i].c;

			VEC3 p0 = m_Msh.m_pVx[a].p;
			VEC3 p1 = m_Msh.m_pVx[b].p;
			VEC3 p2 = m_Msh.m_pVx[c].p;

			if(SUCCEEDED(GetPickPos(m_vcPck, p0, p1, p2)))
			{
				m_vVtx.push_back(p0);
				m_vVtx.push_back(p1);
				m_vVtx.push_back(p2);

				m_bClick = true;
			}
		}

	}

	if(GINPUT->ButtonUp(0))
	{
		m_bClick = false;
	}

	if(m_bClick)
	{
		FLOAT	fDH	= GMAIN->m_Wrk.m_Wrk1.m_fDH;
		INT		iRng= GMAIN->m_Wrk.m_Wrk1.m_iRng;
		FLOAT	fH;

		INT		nIdxZ = INT(m_vcPck.z/ m_Msh.m_iWx);
		INT		nIdxX = INT(m_vcPck.x/ m_Msh.m_iWx);

		int		nIdxBgnZ = nIdxZ-iRng;
		int		nIdxBgnX = nIdxX-iRng;

		int		nIdxEndZ = nIdxZ+iRng;
		int		nIdxEndX = nIdxX+iRng;

		if(nIdxBgnZ<0)
			nIdxBgnZ = 0;

		if(nIdxBgnX<0)
			nIdxBgnX = 0;

		if(nIdxEndZ>=m_Msh.m_iNx)
			nIdxEndZ = m_Msh.m_iNx;

		if(nIdxEndX>=m_Msh.m_iNx)
			nIdxEndX = m_Msh.m_iNx;


		for(int z= nIdxBgnZ; z<nIdxEndZ; ++z)
		{
			for(int x= nIdxBgnX; x<nIdxEndX; ++x)
			{
				int idx = z * m_Msh.m_iNx + x;

				FLOAT xSq = ( z-m_vcPck.z/m_Msh.m_iWx) * (z-m_vcPck.z/m_Msh.m_iWx) + ( x-m_vcPck.x/m_Msh.m_iWx) * (x-m_vcPck.x/m_Msh.m_iWx);
				xSq /=iRng;
				fH = fDH * expf( -xSq);

				m_Msh.m_pVx[idx].p.y += fH;

			}
		}


		m_Msh.NormalSet();
		m_Msh.VertexSet();
	}

	


	return 1;
}

void CMcField::Render()
{
	if(!m_Msh.m_pVx)
		return;

	m_Msh.Render();


	GDEVICE->SetRenderState( D3DRS_LIGHTING,	FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,	FALSE);
	GDEVICE->SetRenderState( D3DRS_FILLMODE,	D3DFILL_SOLID);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(Vtx::FVF);


//	for(int i=0; i<m_vVtx.size(); ++i)
//	{
//		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_vVtx[i*3], sizeof(Vtx));
//	}
}



INT CMcField::MapSave()
{
	FILE* fp;

	fp = fopen("Map/McMap.mpb", "wb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Save Map Failed");
		return -1;
	}
	
	m_Inf.FileWrite(fp);
	m_Msh.FileWrite(fp);
	m_Obj.FileWrite(fp);	

	fclose(fp);

	SAFE_DELETE_ARRAY(	m_Msh.m_pVx	);
	SAFE_DELETE_ARRAY(	m_Msh.m_pIx	);

	return 1;
}



void CMcField::CreateMesh(INT iNx, INT iWx, FLOAT fUV)
{
	m_Msh.CreateMesh(iNx+1, iWx+1, fUV);
}







INT CMcField::MapLoad()
{
	FILE* fp;
	
	fp = fopen("Map/McMap.mpb", "rb");
	
	if(!fp)
	{
		m_Msh.Init();

		if(FAILED(MapSave()))
			return -1;
		
		Destroy();
	}

	
	fp = fopen("Map/McMap.mpb", "rb");
	
	m_Inf.FileRead(fp);	
	m_Msh.FileRead(fp);
	m_Obj.FileRead(fp);

	fclose(fp);

//	remove("Map/McMap.mpb");	

	return 1;
}


INT	CMcField::GetPickPos(VEC3& vcPck, VEC3& p0, VEC3& p1, VEC3& p2)
{
	VEC3	vcCamPos= GCAM->GetCamPos();
	VEC3	vcRayDir = GCAM->Get3DDir();

	FLOAT	U, V, D;

//	// 1 ----- 3
//	// | .     |
//	// |   .   |
//	// |     . |
//	// 0 ----- 2
//
//	VEC3	p0;
//	VEC3	p1;
//	VEC3	p2;

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		vcPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;
	}

	return -1;
}