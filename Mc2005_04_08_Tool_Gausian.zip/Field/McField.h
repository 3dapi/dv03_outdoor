// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_


typedef vector<VEC3>		lsVtx;

class CMcField
{
protected:
	CMpInf		m_Inf;
	CMpMsh		m_Msh;
	CMpObj		m_Obj;

	lsVtx		m_vVtx;
	bool		m_bClick;
	VEC3		m_vcPck;
	
public:
	CMcField();
	~CMcField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);
	INT		GetPickPos(VEC3& pPck, VEC3& p0, VEC3& p1, VEC3& p2);
	
protected:
	INT		MapLoad();
	INT		MapSave();
};

#endif