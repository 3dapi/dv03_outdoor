// Interface for the CMpObj class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPOBJ_H_
#define _MPOBJ_H_

struct Mdl2D																	// Camera Dependent
{
	MATA	mtW;
};

struct Mdl3D																	// Camera Independent
{
	MATA	mtW;
};


class CMpObj																	// object
{
public:
	INT			m_iNd2;															// Mc2D Model Number
	Mdl2D*		m_pMd2;

	INT			m_iNd3;															// Mc3D Model Number
	Mdl3D*		m_pMd3;

public:
	CMpObj();
	virtual ~CMpObj();

	INT		FileRead(FILE* fp);
	INT		FileWrite(FILE* fp);
};

#endif