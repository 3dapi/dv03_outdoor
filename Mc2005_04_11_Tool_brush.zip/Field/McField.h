// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

typedef struct tagMcPkT															// Picking Triangle
{
	VEC3	vcPk;																// Get Position
	VEC3	p0;																	// Triangle
	VEC3	p1;																	// Triangle
	VEC3	p2;																	// Triangle
	FLOAT	fD;																	// Distance From Camera

	tagMcPkT(){}
	tagMcPkT(VEC3& vcP, VEC3& P0, VEC3& P1, VEC3& P2, FLOAT& _fD)
		: vcPk(vcP), p0(P0), p1(P1), p2(P2), fD(_fD){}

}McPkT;


typedef vector<McPkT>		lsMcPkT;
typedef lsMcPkT::iterator	itMcPkT;


class CMcField
{
protected:
	CMpInf		m_Inf;
	CMpMsh		m_Msh;
	CMpObj		m_Obj;

	lsMcPkT		m_vPk;
	bool		m_bClick;
	VEC3		m_vcPck;
	
public:
	CMcField();
	~CMcField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);
	INT		GetPickPos(VEC3& pPck, VEC3& p0, VEC3& p1, VEC3& p2, FLOAT& fD, bool bUseCull=true);
	
protected:
	INT		MapLoad();
	INT		MapSave();
};

#endif