// Implementation of the CMpObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMpObj::CMpObj()
{
	m_iNd2	= 0;																// Mc2D Model Number
	m_pMd2	= 0;
	
	m_iNd3	= 0;																// Mc3D Model Number
	m_pMd3	= 0;
}

CMpObj::~CMpObj()
{
	m_iNd2	= 0;
	m_pMd2	= 0;
	SAFE_DELETE_ARRAY(	m_pMd2	);
	SAFE_DELETE_ARRAY(	m_pMd3	);
}


INT CMpObj::FileRead(FILE* fp)
{
	fread(&m_iNd2, sizeof(m_iNd2),	1, fp);
	fread(&m_iNd3, sizeof(m_iNd3),	1, fp);

	if(m_iNd2)
	{
		m_pMd2	= new Mdl2D[m_iNd2];
		fread(m_pMd2,	sizeof(Mdl2D),	m_iNd2, fp);
	}

	if(m_iNd3)
	{
		m_pMd3	= new Mdl3D[m_iNd3];
		fread(m_pMd3,	sizeof(Mdl3D),	m_iNd3, fp);
	}

	return 1;
}

INT CMpObj::FileWrite(FILE* fp)
{
	fwrite(&m_iNd2, sizeof(m_iNd2),		1, fp);
	fwrite(&m_iNd3, sizeof(m_iNd3),		1, fp);

	if(m_iNd2)
		fwrite(m_pMd2,	sizeof(Mdl2D),	m_iNd2, fp);

	if(m_iNd3)
		fwrite(m_pMd3,	sizeof(Mdl3D),	m_iNd3, fp);

	return 1;
}