// Interface for the CWndTool class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDTOOL_H_
#define _WNDTOOL_H_


#define TOOL_BTN_MAX		20

class CWndTool
{
public:
	HWND			m_hWnd		;
	HWND			m_hWPrn		;

	HWND			m_hCol		;

	HBITMAP			m_bmBtn[TOOL_BTN_MAX]	;
	bool			m_bTool[TOOL_BTN_MAX]	;
	DWORD			m_dC		;												// color

public:
	CLSS_DLG_DECLEAR( CWndTool );

	INT		Create(HWND hWnd);
	void	Destroy();


	void	ShowWindow(int _ishw = SW_SHOW);

	LRESULT	MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

	void	SetPickColor(DWORD	dC, bool IsBGR=false);
	FLOAT	GetDirection();
	bool	IsFlat()	{	return m_bTool[2];								}
	bool	IsHeight()	{	return (m_bTool[0]||m_bTool[1]||m_bTool[2]);	}
	bool	UseBrush()	{	return m_bTool[ 3];								}
};

#endif