// Implementation of the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndWrk, MsgPrc);


INT CWndWrk::Create(HWND hWnd)
{
	m_hWnd		= 0;
	m_hwTab		= 0;
	m_nTabCur	=0;
	m_nTabOld	=-1;

	RECT rt1;
	RECT rt2;

	INT iWd;
	INT iHg;
	INT iX;
	INT iY;

	TCITEM tie;

	m_gWrk	= ImageList_LoadImage(GHINST, MAKEINTRESOURCE(IDB_WRK), 16, 1, RGB(255,255,255),IMAGE_BITMAP,0);
	
	m_hWnd = CreateDialog(GHINST, MAKEINTRESOURCE(IDD_WRK), hWnd, CLSS_DLG_WNDPROC(CWndWrk));
	
	m_Tool.Create(m_hWnd);
	m_Wrk1.Create(m_hWnd);
	m_Wrk2.Create(m_hWnd);

	GetWindowRect(GHWND, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWd = rt2.right - rt2.left;
	iHg=  rt2.bottom- rt2.top;

	iX = rt1.left - iWd;
	iY = rt1.top;
	
	MoveWindow(m_hWnd, iX, iY, iWd, iHg, TRUE);
	GetWindowRect(m_hWnd, &rt2);

	m_hwTab = GetDlgItem(m_hWnd, IDC_WRK_TAB);
	MoveWindow(m_hwTab, 0, 0, iWd-5, iHg-25, TRUE);





	TabCtrl_SetImageList(m_hwTab, m_gWrk);

	
	tie.mask=TCIF_TEXT | TCIF_IMAGE;
	tie.pszText="Res";
	tie.iImage=0;
	TabCtrl_InsertItem(m_hwTab,0,&tie);
	tie.pszText="Win";
	tie.iImage=1;
	TabCtrl_InsertItem(m_hwTab,1,&tie);
	

	// �ڽ� ������ ���̱�..

	GetWindowRect(m_hwTab, &rt1);
	iX = 5;
	iY = 5;

	iWd = rt1.right - rt1.left - iX * 2;
	iHg = rt1.bottom - rt1.top - 40 - iY * 2;

	MoveWindow(m_Wrk1.m_hWnd, iX, iY, iWd, iHg, TRUE);
	
	ShowWindow(m_Wrk1.m_hWnd, SW_SHOW);
	ShowWindow(m_Wrk2.m_hWnd, SW_HIDE);
	ShowWindow(m_hWnd, SW_SHOW);
	
	return 1;
}


void CWndWrk::Destroy()
{
	SAFE_DESTROY(&m_Tool);
	SAFE_DESTROY(&m_Wrk1);
	SAFE_DESTROY(&m_Wrk2);

	SAFE_DESTROY_WINDOW(m_hWnd);
}



INT	CWndWrk::Restore()
{
	SAFE_RESTORE(&m_Wrk1);
	SAFE_RESTORE(&m_Wrk2);

	return 1;
}


void CWndWrk::Invalidate()
{
	SAFE_INVALID(&m_Wrk1);
	SAFE_INVALID(&m_Wrk2);
}


INT CWndWrk::FrameMove()
{
	SAFE_FRMOV(&m_Wrk1);
	SAFE_FRMOV(&m_Wrk2);

	return 1;
}



void CWndWrk::Render()
{
	SAFE_RENDER(&m_Wrk1);
	SAFE_RENDER(&m_Wrk2);
}


LRESULT CWndWrk::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	RECT rt1;
	INT iWd;
	INT iHg;
	INT iX;
	INT iY;
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_NOTIFY:
		{
			switch (((LPNMHDR)lParam)->code)
			{
				case TCN_SELCHANGE:
				{
					m_nTabCur=TabCtrl_GetCurSel(m_hwTab);

					GetWindowRect(m_hwTab, &rt1);
					iX = 5;
					iY = 5;

					iWd = rt1.right - rt1.left - iX * 2;
					iHg = rt1.bottom - rt1.top - 40 - iY * 2;

					if (m_Wrk1.m_hWnd)
					{
						ShowWindow(m_Wrk1.m_hWnd, SW_HIDE);
						ShowWindow(m_Wrk2.m_hWnd, SW_HIDE);
					}
					
					if (m_nTabCur==0)
					{
						ShowWindow(m_Wrk1.m_hWnd, SW_SHOW);
						MoveWindow(m_Wrk1.m_hWnd, iX, iY, iWd, iHg, TRUE);
						InvalidateRect(m_Wrk1.m_hWnd, NULL, TRUE);

						GMAIN->m_ePhCur = GP_WRK1;
					}

					
					else if(m_nTabCur ==1)
					{
						ShowWindow(m_Wrk2.m_hWnd, SW_SHOW);
						MoveWindow(m_Wrk2.m_hWnd, iX, iY, iWd, iHg, TRUE);
						InvalidateRect(m_Wrk2.m_hWnd, NULL, TRUE);

						GMAIN->m_ePhCur = GP_WRK2;
					}
					
					break;
				}// case

			}// switch

			break;
			
		}// case

	}// switch

	return(FALSE);
}