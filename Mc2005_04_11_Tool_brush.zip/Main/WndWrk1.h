// Interface for the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK1_H_
#define _WNDWRK1_H_

class CWndWrk1
{
public:
	HWND			m_hWnd		;
	TlSwpWn			m_SwpWn		;												// Swap Chain Window

	CWndCreate		m_WndCreate	;
	INT				m_iRng		;
	FLOAT			m_fDH		;
	INT				m_bAc		;												//
	
public:
	CLSS_DLG_DECLEAR( CWndWrk1 );

	INT		Create(HWND hWnd);
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
};

#endif