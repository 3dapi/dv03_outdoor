// Implementation of the CWndWrk2 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndWrk2, MsgPrc);


INT CWndWrk2::Create(HWND hWnd)
{
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_WRK2), hWnd, CLSS_DLG_WNDPROC(CWndWrk2));

	return 1;
}


void CWndWrk2::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}


INT	CWndWrk2::Restore()
{
	HRESULT hr;

	if(!GMAIN->m_bWindowed)
		return 1;

	m_SwpWn.hW = (HWND)GetDlgItem(m_hWnd, IDC_WRK2_PANNEL);

	D3DPRESENT_PARAMETERS	par;
	memset(&par, 0, sizeof(D3DPRESENT_PARAMETERS));
	
	par.SwapEffect = D3DSWAPEFFECT_DISCARD;
	par.Windowed = TRUE;
	
	RECT rt;
	GetWindowRect(m_SwpWn.hW, &rt);

	par.BackBufferWidth= 0;
	par.BackBufferHeight= 0;
	par.hDeviceWindow = m_SwpWn.hW;

	hr = GDEVICE->CreateAdditionalSwapChain(&par, &m_SwpWn.pC) ;

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Create addtional swap chain failed");
		return hr;
	}

	hr = m_SwpWn.pC->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Get back buffer Failed");
		return hr;
	}


	D3DFORMAT format = GMAIN->m_d3dSettings.DepthStencilBufferFormat();
	hr = GDEVICE->CreateDepthStencilSurface(par.BackBufferWidth, par.BackBufferHeight, format, D3DMULTISAMPLE_NONE, 0, 0, &m_SwpWn.pS, NULL);

	if ( FAILED(hr))
	{
		MessageBox(NULL, "Failed", "Failed", MB_OK);
		return -1;
	}
	
	return 1;
}


void CWndWrk2::Invalidate()
{
	m_SwpWn.Release();
}


INT CWndWrk2::FrameMove()
{
	return 1;
}



void CWndWrk2::Render()
{
	if(GP_WRK2 != GMAIN->m_ePhCur)
		return;

	if(!GMAIN->m_bWindowed)
		return;

	GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
	GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	
	GDEVICE->Clear( 0L, 0, GMAIN->m_dwClr,  0x00446699, 1.0f, 0L );

	RECT rt={5,10, 1024,30};
	GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFFFF);

	m_SwpWn.pC->Present(0, 0, 0, 0, 0);
}



LRESULT CWndWrk2::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_NOTIFY:
		{	
			break;
		}
	}

	return(FALSE);
}