// Interface for the CWndCreate class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _WNDCREATE_H_
#define _WNDCREATE_H_

class CWndCreate
{
public:
	HWND			m_hWnd		;
	HWND			m_hWPrn		;

public:
	CHAR			m_sN[64];													// Name

	INT				m_iNx;														// Number of tile for Width
	INT				m_iWx;														// Width of tile for x;
	FLOAT			m_fUV;

public:
	CLSS_DLG_DECLEAR( CWndCreate );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	void	ShowWindow(int _ishw = SW_SHOW);
};

#endif