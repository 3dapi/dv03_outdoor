// Implementation of Mc Utility functions.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(0, s, "Err", MB_OK | MB_ICONERROR);
}



void McUtil_GetLastErr()
{
	LPVOID lpMsgBuf;

	FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM | 
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				GetLastError(),
				0,
				(LPTSTR) &lpMsgBuf,
				0,
				NULL 
	);

	MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
	LocalFree( lpMsgBuf );
}



char*	McUtil_GetSmallTime()
{
	static char tm_str[128 + 1];
	SYSTEMTIME st;

	GetLocalTime(&st);
	strcpy(tm_str,	McUtil_Forming("%04d-%02d-%02d	%02d:%02d:%02d.%03d",
		(INT)st.wYear, (INT)st.wMonth, (INT)st.wDay,
		(INT)st.wHour, (INT)st.wMinute, (INT)st.wSecond, (INT)st.wMilliseconds));

	return(tm_str);
} /* getSmallTime */


void McUtil_FormatLog(TCHAR *format,...)
{
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log.txt", "a+");
	fprintf(fp, "%s\t%s\n", McUtil_GetSmallTime(), szDbgBuf);
	fclose(fp);
}


void McUtil_FormatLog2(TCHAR *format,...)
{
//	if (!g_BaseInfo.File_Log) return;
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log_2.txt", "a+");
	fprintf(fp, "%s\t%s\n", McUtil_GetSmallTime(), szDbgBuf);
	fclose(fp);
}


// Texture Load
INT		McUtil_TextureLoad(TCHAR* sFile, PDTX& pTexture, DWORD dColor
						   , D3DXIMAGE_INFO* pSrcInf
						   , DWORD Filter, DWORD MipFilter, D3DFORMAT d3Fmt)
{
	HRESULT hr;
	if ( FAILED(hr = D3DXCreateTextureFromFileEx(
		GDEVICE
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3Fmt
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, dColor
		, pSrcInf
		, NULL
		, &pTexture
		)) )
	{
		pTexture = 0;
		return hr;
	}
	
	return 1;
}



void McUtil_ReadFileLine(FILE *fp, TCHAR *str)
{
	static TCHAR sTmp[512];
	
	INT nSize;
	INT nBgn, nEnd;
	INT i;

	memset(sTmp,0, sizeof(sTmp));
	fgets(sTmp, 512, fp);

	nSize = strlen(sTmp);
	
	for(i=0; i<nSize; ++i)
	{
		if('\t' == sTmp[i])
			sTmp[i] =' ';
		
		if('\n' == sTmp[i] || '\r' == sTmp[i])
		{
			sTmp[i] = 0;
		}
	}
	
	nBgn=0;
	nEnd= strlen(sTmp);

	if(0 == nEnd)
	{
		str[0] =0;
		return;
	}
	
	for(i=0; i<=nEnd; ++i)
	{
		if(' ' != sTmp[i])
		{
			nBgn =i;
			break;
		}
	}
	
	strncpy(str, sTmp + nBgn, nEnd-nBgn);
	str[nEnd-nBgn] = 0;
}


void McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC)
{
	INT iB;
	INT iE;
	INT	i;

	// Search forward
	
	INT	iLen= strlen(strIn);

	for(i=0;i<iLen; ++i)
	{
		if(iC == strIn[i])
		{
			iB = i;
			break;
		}
	}

	for(i=iLen-1;i>=0; --i)
	{
		if(iC == strIn[i])
		{
			iE = i;
			break;
		}
	}

	if(iB == (iE-1))															// ���۰� �����̿� ���ڰ� ����.
	{
		strOut[0]=0;
		return;
	}

	strncpy(strOut, strIn+iB+1, iE-iB-1);
}


void McUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateVertexBuffer(nSize,
		0,
		fvf,
		usage,
		&pVB, NULL );
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pVtx)
		return;

	McUtil_VBLock(pVB, nSize, pVtx);
}


void McUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx)
{
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy( p, pVtx, nSize);
	pVB->Unlock();
}


void McUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx, D3DFORMAT fmt, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateIndexBuffer( nSize, 0, fmt, usage, &pIB, NULL);
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Index buffer create failed");
		return ;
	}
	
	if(!pIdx)
		return;

	McUtil_IBLock(pIB, nSize, pIdx);
}


void McUtil_IBLock(PDIB & pIB, INT nSize, void* pIdx)
{
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy(p, pIdx, nSize);
	pIB->Unlock();
}



bool McUtil_LineCross2D(VEC2 * p)
{
	VEC2 L1 = p[1] - p[0];
	VEC2 L2 = p[3] - p[2];
	VEC2 L3 = p[2] - p[0];
	
	
	FLOAT fAlpha = L2.x * L1.y - L2.y * L1.x;
	
	if(0.f == fAlpha)
		return false;
	
	FLOAT fBeta = fAlpha;
	
	fAlpha = (L2.x * L3.y - L2.y * L3.x)/fAlpha;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	fBeta = (L2.x * L3.y - L1.y * L3.x)/fBeta;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	return true;
}

INT McUtil_3Dto2D(VEC3& Out, const VEC3& In)
{
	MATA		mtV;																// View matrix
	MATA		mtP;																// Projection matrix
	MATA		mtVP;																// view matrix * projection matrix
	VEC3	vcPc;																// Camera pos
	VEC3	vcZ;																// Normal vector
	FLOAT	fNear=1.f;
	FLOAT	beta;
	VEC3	vcB;
	FLOAT	fW;
	FLOAT	fH;

//	mtV		= GCAMERA->GetViewMatrix();
//	mtP		= GCAMERA->GetProjMatrix();
//	vcPc	= GCAMERA->GetRayOrg();
//	vcZ		= GCAMERA->GetAxisZ();
	
	beta	= D3DXVec3Dot(&vcZ, &(In - vcPc));
	
	if(beta<=fNear)
		return 0;			// �������� ��� �ڿ� ����.

	beta = fNear/beta;
	vcB = beta * (In - vcPc) -fNear * vcZ;

	D3DXMatrixMultiply(&mtVP, &mtV, &mtP);
	
	Out.x	= vcB.x * mtVP._11 + vcB.y * mtVP._21 + vcB.z * mtVP._31;			// ���� Model view Matrix�� �����Ѵ�.
	Out.y	= vcB.x * mtVP._12 + vcB.y * mtVP._22 + vcB.z * mtVP._32;
	Out.z	= vcB.x * mtVP._13 + vcB.y * mtVP._23 + vcB.z * mtVP._33;

	RECT rt;

	GetWindowRect(GHWND, &rt);
	fW		= rt.right - rt.left;
	fH		= rt.bottom - rt.top;
	
	Out.x	=  fW * (Out.x +1.f) * 0.5f;
	Out.y	= -fH * (Out.y -1.f) * 0.5f;

	return 1;
}





bool McUtil_PositionMouse3D(VEC3& vec3dOut)
{
	MATA matView;
	MATA matProj;
	MATA matViewProj;
	MATA matViewInv;
	
	MATA matViewProjInv;
	
	GDEVICE->GetTransform(D3DTS_VIEW, &matView);
	GDEVICE->GetTransform(D3DTS_PROJECTION,&matProj);
	
	D3DXMatrixIdentity(&matViewProj);
	
	matViewProj = matView * matProj;
	D3DXMatrixInverse(&matViewProjInv, NULL, &matViewProj);
	
	POINT	pt;
	RECT	rt;
	
	::GetCursorPos(&pt);
	::GetWindowRect(GHWND, &rt);
	
	VEC3 vecBefore( 2.f * pt.x /FLOAT(rt.right-rt.left) -1,
		-2.f * pt.y /FLOAT(rt.bottom - rt.top) +1,
		0);
	
	VEC3 vecP(0,0,0);
	
	
	// ���� Model view Matrix�� �����Ѵ�.
	
	vecP.x = vecBefore.x * matViewProjInv._11 + vecBefore.y * matViewProjInv._21 + vecBefore.z * matViewProjInv._31;
	vecP.y = vecBefore.x * matViewProjInv._12 + vecBefore.y * matViewProjInv._22 + vecBefore.z * matViewProjInv._32;
	vecP.z = vecBefore.x * matViewProjInv._13 + vecBefore.y * matViewProjInv._23 + vecBefore.z * matViewProjInv._33;
	
	//camera position
	D3DXMatrixInverse(&matViewInv, NULL, &matView);
	VEC3 vecCamPos(matViewInv._41, matViewInv._42, matViewInv._43);
	
	//Normalvector
	VEC3 vecZ( matView._13, matView._23, matView._33);
	
	FLOAT beta =(vecZ.y + vecP.y);
	
	if (0.f == beta)
		return false;
	
	beta =  -vecCamPos.y/beta;
	
	vec3dOut = beta * (vecZ + vecP) + vecCamPos;
	
	return true;
}



INT	McUtil_GetPickPos3D(VEC3& vcPck, VEC3& p0, VEC3& p1, VEC3& p2, FLOAT& D, bool bUseCull)
{
	VEC3	vcCamPos= GCAM->GetCamPos();
	VEC3	vcRayDir = GCAM->Get3DDir();

	FLOAT	U, V;

	if(bUseCull)
	{
		VEC3 vcN;
		D3DXVec3Cross(&vcN, &(p1-p0), &(p2-p0));

		if( D3DXVec3Dot(&vcN, &vcRayDir)>0)
			return -1;
	}

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		vcPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;
	}

	return -1;
}




INT McUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color)
{	
	HDC hDC;
	LPDIRECT3DSURFACE9 Surface;
	
	if(FAILED(GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &Surface)))
		return -1;
	
	Surface->GetDC(&hDC);
	
	if(NULL != hDC)
	{
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, _color);
		TextOut(hDC, X, Y, Text, strlen(Text));

		Surface->ReleaseDC(hDC);
	}
	
	Surface->Release(); //�����Ѵ�.
	
	
	return 1;
}


void McUtil_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(GHWND, s);
}



void McUtil_TextOut(float x, float y, DWORD color, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	SetBkMode(GHDC, TRANSPARENT);
	SetTextColor(GHDC, color);
	TextOut(GHDC, INT(x), INT(y), s, strlen(s));
}




void McUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}



TCHAR*	McUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR* sTitle)
{
	BROWSEINFO		bi;
	static TCHAR	sPathName[1024];
	static TCHAR	sPathFull[1024];
	LPITEMIDLIST	pidl = NULL;
	LPITEMIDLIST	pidlFolder= NULL;
	LPMALLOC		pMalloc = NULL;

	memset(sPathName, 0, sizeof(sPathName));
	memset(sPathFull, 0, sizeof(sPathFull));
	memset(&bi, 0, sizeof(BROWSEINFO));

	bi.hwndOwner = hWnd;
	bi.lpszTitle = sTitle;
	bi.ulFlags = BIF_STATUSTEXT |BIF_EDITBOX   ;
	bi.ulFlags = BIF_EDITBOX   ;

	GetCurrentDirectory(1024, sPathFull);

	LPSHELLFOLDER pShellFolder = NULL;
	OLECHAR wszPath[MAX_PATH] = {0};
	ULONG nCharsParsed = 0;
	
	// Get an IShellFolder interface pointer
	::SHGetDesktopFolder(&pShellFolder);
	
	// Convert the path name to Unicode
	::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sPathFull, -1, wszPath, MAX_PATH);
	
	// Call ParseDisplayName() to do the job
	pShellFolder->ParseDisplayName(NULL, NULL, wszPath, &nCharsParsed, &pidl, NULL);

	bi.pidlRoot = pidl;


	pidlFolder = SHBrowseForFolder(&bi);

	if(pidlFolder == NULL)
	{
		sPath[0] =0;
		sPathFull[0];
		return sPathFull;														//����� ���
	}

	SHGetPathFromIDList(pidlFolder, sPathName);

	strcpy(sPath, sPathName);
	strcpy(sPathFull, sPathName);

	SHGetMalloc(&pMalloc);
	pMalloc->Free(pidl);
	pMalloc->Free(pidlFolder);
	pMalloc->Release();

	return sPathFull;
}


TCHAR*	McUtil_DWtoStr(DWORD dwA)
{
	static char		s[32];
	static char*	pDst;

	memset(s, 0, sizeof(s));
	pDst=0;
	sprintf(s, "00000000%X", dwA);
	pDst = s + strlen(s) - 8;

	return pDst;
}



DWORD	McUtil_GetFileVersion()
{
	//			
	return 0x00000101;
}


void SetDlgItemFlt(HWND hWnd, UINT id, float z, INT decimal)
{
	char s[128];
	char f[64];
	
	sprintf(f,"%%.%df", decimal);
	memset(s, 0, sizeof(s));
	sprintf(s, f, z);
	SetDlgItemText(hWnd,id,s);
}

FLOAT GetDlgItemFlt(HWND hWnd, UINT id)
{
	char s[256];
	memset(s, 0, sizeof(s));

	GetDlgItemText(hWnd, id, s, sizeof(s));
	return atof(s);
}

void SetDlgItemHex(HWND hWnd, UINT id, INT val)
{
	char	buf[64] = "0x";
	char	s[32];
	char*	pDst;
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", val);
	pDst = s + strlen(s) - 8;

	strcat(buf, pDst);
	SetDlgItemText(hWnd,id,buf);
}


char*	McUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 512
#define FORMING_RECALL_TOTAL 100
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)
	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static INT index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);
	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL) index_formingbuf = 0;
	strp = formingbuf + index_formingbuf;
	strcpy(strp, formingfmt);
	index_formingbuf += strlen(formingfmt) + 1;
	return(strp);
}

DWORD McUtil_VectorToRGB(VEC3* NormalVector)
{
	DWORD dwR = (DWORD)(100.f * NormalVector->x + 155.f);
	DWORD dwG = (DWORD)(100.f * NormalVector->y + 155.f);
	DWORD dwB = (DWORD)(100.f * NormalVector->z + 155.f);
	
	return (DWORD)(0xff000000 + (dwR << 16) + (dwG << 8) + dwB);
}


void	McUtil_ScreenCapture()
{
	SYSTEMTIME st;
	TCHAR	sFile[512]="\0";
	TCHAR	sFile2[512]="\0";

	GetLocalTime(&st);
	GetCurrentDirectory(sizeof(sFile2), sFile2);

	sprintf(sFile, "%s/%04d_%02d_%02d_%02d_%02d_%02d.bmp", sFile2,
		(int)st.wYear, (int)st.wMonth, (int)st.wDay,
		(int)st.wHour, (int)st.wMinute, (int)st.wSecond);

	D3DXSaveSurfaceToFile( sFile, D3DXIFF_BMP, GBACKSF, NULL, NULL);
}



void McUtil_SetCurrentDirectory()
{
	TCHAR	sExe1[512];
	TCHAR	sExe2[512];

	memset(sExe1, 0, sizeof(sExe1));
	memset(sExe2, 0, sizeof(sExe2));

	strcpy(sExe1, GetCommandLine());

	INT	iLen = strlen(sExe1);

	int k=0;

	for(INT i=0; i<iLen; ++i)
	{
		if('"' == sExe1[i])
		{
			++k;
			continue;
		}

		if(2==k)
			break;

		sExe2[i-k] = sExe1[i];
		if('\\' == sExe2[i-k])
			sExe2[i-k] ='/';
	}

	char*pdest;
	
	pdest = strrchr(sExe2, '/');

	int result;
	result = pdest - sExe2;

	sExe2[result] =0;

	BOOL hr = SetCurrentDirectory(sExe2);
}


DWORD McUtil_GetUsedMemory()
{
	MEMORYSTATUS	MmSt;
	GlobalMemoryStatus(&MmSt);
	return ((g_MmSt.dwAvailPhys - MmSt.dwAvailPhys)/1024);								// KByte
}


void McUtil_SetWorldIdentity()
{
	static MATA	mtW(	1,0,0,0
					,	0,1,0,0
					,	0,0,1,0
					,	0,0,0,1);

	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);
}

FLOAT	McUtil_GetLinearWg(FLOAT f1,FLOAT f2,FLOAT f)
{
		return ( (f-f1) / (f2-f1) );
}



void McUtil_GetDefaultWebBrowser()
{
	// HKEY_CLASSES_ROOT\http\shell\open\command
	DWORD	dwType, cbData;
	HKEY	hKey; 
	long	lRet;
	char*	sStr;
	
	
	if ((lRet = RegOpenKeyEx(HKEY_CLASSES_ROOT, "http\\shell\\open\\command", 0, KEY_READ | KEY_QUERY_VALUE , &hKey)) == ERROR_SUCCESS)
	{
		cbData = 512;
		sStr = (char*)malloc(cbData * sizeof(char));
		memset(sStr, 0, sizeof(char)*cbData);

		if ((lRet = RegQueryValueEx(hKey, "",  0, &dwType, (BYTE*)sStr, &cbData)) == ERROR_SUCCESS)
		{
			
			int iLen = strlen(sStr);
			
			for(int i=0; i<iLen; ++i)
			{
				if('"' == *(sStr +i))
				{
					for(int j=i; j<iLen; ++j)
						*(sStr +j) = *(sStr +j+1);
					
					iLen = strlen(sStr);
				}
			}
			
			char *pdest = strstr(sStr, ".exe");
			
			int r;
			
			r= pdest - sStr+4;
			
			sStr[r+0] = ' ';
			sStr[r+1] = 0;

			
			WinExec((LPCSTR)sStr, SW_SHOWNORMAL);            
		}

		free(sStr);
		RegCloseKey(hKey);
	}
}



void McUtil_LogFile(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL)
		return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)
		return;
	
	MessageBox(0, s, "Err", MB_OK | MB_ICONERROR);
}





void	McUtil_Rectangle(INT x0, INT y0, INT x1, INT y1, DWORD color)
{
	HPEN	hPen = CreatePen(PS_SOLID, 1, color);
	SelectObject(GHDC, hPen);
	
	MoveToEx(GHDC, x0, y0, 0);	LineTo(GHDC, x1, y0);
	MoveToEx(GHDC, x1, y0, 0);	LineTo(GHDC, x1, y1);
	MoveToEx(GHDC, x1, y1, 0);	LineTo(GHDC, x0, y1);
	MoveToEx(GHDC, x0, y1, 0);	LineTo(GHDC, x0, y0);

	DeleteObject(hPen);
}


void McUtil_StrList(lsStr& vStr, char* sIn, char* sSpes)
{
	static char sp[]   = " ,\t/\'\"\\\n";
	char *token = NULL;

	if(!strlen(sIn))
		return;

	if(!sSpes)
		sSpes = sp;

	token = strtok( sIn, sSpes );

	if(!token || !strlen(token))
		return;

	vStr.push_back(token);

	while( token != NULL )
	{
		token = strtok( NULL, sSpes );

		if(token && strlen(token))
			vStr.push_back(token);
	}
}


long	McUtil_GetFileSize(FILE* &fp)
{
	long lCur = ftell(fp);
	long lSize =0;
	long lB =0, lE =0;

	fseek(fp, 0, SEEK_SET);		lB = ftell(fp);
	fseek(fp, 0, SEEK_END);		lE = ftell(fp);

	lSize = lE-lB;

	fseek(fp, lCur, SEEK_CUR);

	return lSize;
}

// ARGB <--> BGR
BYTE* McUtil_GetColorARGB(DWORD& _argb)
{
	static BYTE argb[4];
	BYTE* pClr = (BYTE*)&_argb;

	argb[0] = pClr[3];
	argb[1] = pClr[2];
	argb[2] = pClr[1];
	argb[3] = pClr[0];

	return argb;
}

// ARGB <--> BGR
BYTE* McUtil_GetColorBGR(DWORD& bgr)
{
	static BYTE argb[4];

	BYTE* pClr = (BYTE*)&bgr;

	argb[0] = 0x0;
	argb[1] = pClr[0];
	argb[2] = pClr[1];
	argb[3] = pClr[2];
	return argb;
}