//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Blame.rc
//
#define IDI_MAIN_ICON                   101
#define IDR_MAIN_ACCEL                  113
#define IDR_MENU                        141
#define IDR_POPUP                       142
#define IDD_SELECTDEVICE                144
#define IDD_DLG_CONNECT                 146
#define IDD_VIW                         147
#define IDD_WRK                         148
#define IDD_WRK1                        149
#define IDD_WRK2                        150
#define IDD_CREATE                      151
#define IDD_TOOL                        152
#define IDD_MTRL                        153
#define IDB_WRK                         160
#define IDB_ICN01                       161
#define IDB_ICN02                       162
#define IDB_ICN03                       163
#define IDB_ICN04                       164
#define IDB_ICN21                       165
#define IDB_ICN22                       166
#define IDB_ICN23                       167
#define IDB_ICN24                       168
#define IDB_ICN25                       169
#define IDB_ICN26                       170
#define IDB_ICN27                       171
#define IDB_ICN28                       172
#define IDB_ICN29                       173
#define IDB_ICN30                       174
#define IDB_ICN31                       175
#define IDB_ICN32                       176
#define IDB_ICN33                       177
#define IDB_ICN34                       178
#define IDB_ICN35                       179
#define IDB_ICN36                       180
#define IDC_VIW_TX_M                    1020
#define IDC_VIW_TX_S                    1021
#define IDC_VIW_PANEL                   1022
#define IDC_WRK_TAB                     1023
#define IDC_WRK1_PANNEL                 1031
#define IDC_WRK1_RC                     1032
#define IDC_WRK1_TREE                   1033
#define IDC_WRK1_CREATE_LOCAL           1034
#define IDC_WRK1_LOCAL_LOAD             1035
#define IDC_WRK1_RNG                    1036
#define IDC_WRK1_DH                     1037
#define IDC_WRK1_RNG_SET                1038
#define IDC_WRK1_DIF                    1039
#define IDC_WRK1_DH_SET                 1040
#define IDC_WRK1_AC                     1041
#define IDC_WRK2_PANNEL                 1051
#define IDC_WRK2_TREE                   1052

#define IDC_CRT_NAME                    1070
#define IDC_CRT_NUM_X                   1071
#define IDC_CRT_WIDTH                   1072
#define IDC_CRT_UV                      1073
#define IDC_CRT_OK                      1074
#define IDC_CRT_CANCEL                  1075

#define IDC_TOOL_BT01                   1081
#define IDC_TOOL_BT02                   1082
#define IDC_TOOL_BT03                   1083
#define IDC_TOOL_BT04                   1084
#define IDC_TOOL_BT05                   1085
#define IDC_TOOL_BT06                   1086
#define IDC_TOOL_BT07                   1087
#define IDC_TOOL_BT08                   1088
#define IDC_TOOL_BT09                   1089
#define IDC_TOOL_BT10                   1090
#define IDC_TOOL_BT11                   1091
#define IDC_TOOL_BT12                   1092
#define IDC_TOOL_BT13                   1093
#define IDC_TOOL_BT14                   1094
#define IDC_TOOL_COL                    1095

#define IDC_MTL_AL_C                    1101
#define IDC_MTL_AL_R                    1102
#define IDC_MTL_AL_G                    1103
#define IDC_MTL_AL_B                    1104
#define IDC_MTL_DF_C                    1105
#define IDC_MTL_DF_R                    1106
#define IDC_MTL_DF_G                    1107
#define IDC_MTL_DF_B                    1108
#define IDC_MTL_AM_C                    1109
#define IDC_MTL_AM_R                    1110
#define IDC_MTL_AM_G                    1111
#define IDC_MTL_AM_B                    1112
#define IDC_MTL_SP_C                    1113
#define IDC_MTL_SP_R                    1114
#define IDC_MTL_SP_G                    1115
#define IDC_MTL_SP_B                    1116
#define IDC_MTL_EM_C                    1117
#define IDC_MTL_EM_R                    1118
#define IDC_MTL_EM_G                    1119
#define IDC_MTL_EM_B                    1120
#define IDC_MTL_POW                     1121
#define IDC_MTL_OK                      1122
#define IDC_MTL_CANCEL                  1123

#define IDM_CHANGEDEVICE                40002
#define IDM_TOGGLEFULLSCREEN            40003
#define IDM_EXIT                        40006
#define IDM_BACK                        40014
#define IDM_RETURN                      40015
#define IDM_RETURN_CTRL                 40016
#define IDM_TAB                         40017
#define IDM_TAB_BACK                    40018
#define IDM_RETURN_SHIFT                40020
#define IDM_ESC                         40021
#define ID_MENUITEM40022                40022
#define IDM_SOLID                       40023
#define IDM_LGT                         40024
#define ID_VIEW_FIELD                   40025
#define IDM_FOG                         40026
#define IDM_NEW                         40027

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        183
#define _APS_NEXT_COMMAND_VALUE         40028
#define _APS_NEXT_CONTROL_VALUE         1135
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
