// Interface for the CGmWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GMWRK1_H_
#define _GMWRK1_H_

class CGmWrk1
{
public:
	CMcField*			m_pField	;

public:
	CGmWrk1();
	virtual ~CGmWrk1();

	INT		Init();
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
	void	RenderS();
};

#endif