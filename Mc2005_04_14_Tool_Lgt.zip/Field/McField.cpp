// Implementation of the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcField::CMcField()
{
	m_bClick = false;
}

CMcField::~CMcField()
{
	Destroy();
}


INT CMcField::Init()
{
//	MapLoad();

	return 1;
}


void CMcField::Destroy()
{
	m_Msh.Destroy();
}


INT	CMcField::FrameMove()
{
	if(!m_Msh.m_pVx)
		return 1;


	if(GINPUT->ButtonDn(0))
	{
		m_vPk.clear();

		VEC3 pck;

		for(INT i=0; i<m_Msh.m_iNi; ++i)
		{
			WORD	a, b, c;

			a = m_Msh.m_pIx[i].a;
			b = m_Msh.m_pIx[i].b;
			c = m_Msh.m_pIx[i].c;

			VEC3	vcPk;
			VEC3	p0 = m_Msh.m_pVx[a].p;
			VEC3	p1 = m_Msh.m_pVx[b].p;
			VEC3	p2 = m_Msh.m_pVx[c].p;
			FLOAT	fD;

			if(SUCCEEDED(McUtil_GetPickPos3D(vcPk, p0, p1, p2, fD)))
			{
				m_vPk.push_back(TlPkT(vcPk, p0, p1, p2, fD));
			}
		}


		if(!m_vPk.empty())
		{
			sort(m_vPk.begin(), m_vPk.end(), CLnSrtL<TlPkT >());
			m_vcPck = m_vPk[0].vcPk;
			m_bClick = true;
		}
	}



	if(GINPUT->ButtonUp(0))
	{
		m_vPk.clear();
		m_bClick = false;
	}


	if(m_bClick && GMAIN->m_Wrk.m_Tool.UseSpoid())
	{
		INT		nIdxZ = INT(m_vcPck.z/ m_Msh.m_iWx);
		INT		nIdxX = INT(m_vcPck.x/ m_Msh.m_iWx);

		DWORD color = m_Msh.m_pVx[nIdxZ * m_Msh.m_iNx + nIdxX].d;

		GMAIN->m_Wrk.m_Tool.SetPickColor(color, false);
	}

	if(m_bClick && GMAIN->m_Wrk.m_Tool.IsHeight())
	{
		INT		iFlat= GMAIN->m_Wrk.m_Tool.IsFlat();
		FLOAT	fDH	= fabsf(GMAIN->m_Wrk.m_Wrk1.m_fDH) * GMAIN->m_Wrk.m_Tool.GetDirection();
		INT		iRng= GMAIN->m_Wrk.m_Wrk1.m_iRng;
		INT		bAc	= GMAIN->m_Wrk.m_Wrk1.m_bAc;
		FLOAT	fH	= iFlat * fabsf(GMAIN->m_Wrk.m_Wrk1.m_fDH);

		INT		nIdxZ = INT(m_vcPck.z/ m_Msh.m_iWx);
		INT		nIdxX = INT(m_vcPck.x/ m_Msh.m_iWx);

		int		nIdxBgnZ = nIdxZ-iRng;
		int		nIdxBgnX = nIdxX-iRng;

		int		nIdxEndZ = nIdxZ+iRng;
		int		nIdxEndX = nIdxX+iRng;

		if(nIdxBgnZ<0)
			nIdxBgnZ = 0;

		if(nIdxBgnX<0)
			nIdxBgnX = 0;

		if(nIdxEndZ>=m_Msh.m_iNx)
			nIdxEndZ = m_Msh.m_iNx;

		if(nIdxEndX>=m_Msh.m_iNx)
			nIdxEndX = m_Msh.m_iNx;

		
		fH += m_Msh.m_pVx[nIdxZ * m_Msh.m_iNx + nIdxX].p.y;

		for(int z= nIdxBgnZ; z<nIdxEndZ; ++z)
		{
			for(int x= nIdxBgnX; x<nIdxEndX; ++x)
			{
				int r = (x-nIdxX) * (x-nIdxX) + (z-nIdxZ) * (z-nIdxZ) - int(0.999f * iRng * iRng);
				
				if(!iFlat && r>0)
					continue;
				
				int idx = z * m_Msh.m_iNx + x;

				if(iFlat)
				{
					m_Msh.m_pVx[idx].p.y = fH;
				}
				else
				{
					FLOAT xSq = ( z-m_vcPck.z/m_Msh.m_iWx) * (z-m_vcPck.z/m_Msh.m_iWx) + ( x-m_vcPck.x/m_Msh.m_iWx) * (x-m_vcPck.x/m_Msh.m_iWx);
					xSq /=iRng;
					fH = fDH * expf( -xSq);
					m_Msh.m_pVx[idx].p.y += fH;
				}
					
				if(bAc)
					m_Msh.SetDiffuse(idx);

			}
		}

		m_Msh.SetNormal();
	}



	if(m_bClick && GMAIN->m_Wrk.m_Tool.UseBrush())
	{
		INT		iRng= GMAIN->m_Wrk.m_Wrk1.m_iRng;
		DWORD	dC	= GMAIN->m_Wrk.m_Tool.m_dC;

		INT		nIdxZ = INT(m_vcPck.z/ m_Msh.m_iWx);
		INT		nIdxX = INT(m_vcPck.x/ m_Msh.m_iWx);

		int		nIdxBgnZ = nIdxZ-iRng;
		int		nIdxBgnX = nIdxX-iRng;

		int		nIdxEndZ = nIdxZ+iRng;
		int		nIdxEndX = nIdxX+iRng;

		if(nIdxBgnZ<0)
			nIdxBgnZ = 0;

		if(nIdxBgnX<0)
			nIdxBgnX = 0;

		if(nIdxEndZ>=m_Msh.m_iNx)
			nIdxEndZ = m_Msh.m_iNx;

		if(nIdxEndX>=m_Msh.m_iNx)
			nIdxEndX = m_Msh.m_iNx;

		
		for(int z= nIdxBgnZ; z<nIdxEndZ; ++z)
		{
			for(int x= nIdxBgnX; x<nIdxEndX; ++x)
			{
				int idx = z * m_Msh.m_iNx + x;

				int r = (x-nIdxX) * (x-nIdxX) + (z-nIdxZ) * (z-nIdxZ) - int(0.999f * iRng * iRng);
				
				if(r>0)
					continue;

				m_Msh.m_pVx[idx].d = dC;
			}
		}

	}


	return 1;
}

void CMcField::Render()
{
	if(!m_Msh.m_pVx)
		return;

	m_Msh.Render();


	GDEVICE->SetRenderState( D3DRS_LIGHTING,	FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,	FALSE);
	GDEVICE->SetRenderState( D3DRS_FILLMODE,	D3DFILL_SOLID);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetFVF(Vtx::FVF);


	if(!m_vPk.empty())
	{
		m_vcPck = m_vPk[0].vcPk;
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, m_vPk[0].p0, sizeof(Vtx));
	}
}



INT CMcField::MapSave()
{
	FILE* fp;

	fp = fopen("Map/McMap.mpb", "wb");
	
	if(!fp)
	{
		McUtil_ErrMsgBox("Save Map Failed");
		return -1;
	}
	
	m_Inf.FileWrite(fp);
	m_Msh.FileWrite(fp);
	m_Obj.FileWrite(fp);	

	fclose(fp);

	SAFE_DELETE_ARRAY(	m_Msh.m_pVx	);
	SAFE_DELETE_ARRAY(	m_Msh.m_pIx	);

	return 1;
}



void CMcField::CreateBlc(INT iNx, INT iWx, FLOAT fUV)
{
	m_Msh.Destroy();
	m_Msh.CreateMesh(iNx+1, iWx+1, fUV);


	DMTL	Mtrl	= GMAIN->m_Wrk.m_Tool.m_WndMtrl.GetMtrl();
	DWORD	dAmLgt	= GMAIN->m_Wrk.m_Tool.m_WndMtrl.GetAmLgt();

	m_Msh.SetMaterial(Mtrl);
	m_Msh.SetAmLgt(dAmLgt);


	INT		iNl	= 3;
	DLGT	Lgt[3];

	memset(Lgt, 0, sizeof(Lgt));

	Lgt[0].Type		= D3DLIGHT_DIRECTIONAL;
	Lgt[0].Diffuse	= D3DXCOLOR( .4F, .4F, .4F, 0.F);
	Lgt[0].Direction= VEC3( -cosf(D3DXToRadian(45)), -sinf(D3DXToRadian(45)), 0);

	Lgt[1].Type		= D3DLIGHT_DIRECTIONAL;
	Lgt[1].Diffuse	= D3DXCOLOR( .4F, .4F, .4F, 0.F);
	Lgt[1].Direction= VEC3( -cosf(D3DXToRadian(135)), -sinf(D3DXToRadian(135)), 0);
	
	Lgt[2].Type		= D3DLIGHT_DIRECTIONAL;
	Lgt[2].Diffuse	= D3DXCOLOR( .4F, .4F, .4F, 0.F);
	Lgt[2].Direction= VEC3( 0, -sinf(D3DXToRadian(45)), -cosf(D3DXToRadian(45)));

	m_Msh.SetLight(Lgt, iNl);


	DWORD	dFc	= 0xFF336699;
	FLOAT	fFb	= 200.0f;
	FLOAT	fFe = 5000.0f;

	m_Msh.SetFog(dFc, fFb, fFe);

	m_Msh.SetTexture();
}



void CMcField::SetMaterial(DMTL& _mtl)
{
	m_Msh.SetMaterial(_mtl);
}


void CMcField::SetAmbientLight(DWORD& _dAmL)
{
	m_Msh.SetAmLgt(_dAmL);
}


void CMcField::SetLight(DLGT* pLgt, INT nCnt)
{
	m_Msh.SetLight(pLgt, nCnt);
}



INT CMcField::MapLoad()
{
	FILE* fp;
	
	fp = fopen("Map/McMap.mpb", "rb");
	
	if(!fp)
	{
		m_Msh.Init();

		if(FAILED(MapSave()))
			return -1;
		
		Destroy();
	}

	
	fp = fopen("Map/McMap.mpb", "rb");
	
	m_Inf.FileRead(fp);	
	m_Msh.FileRead(fp);
	m_Obj.FileRead(fp);

	fclose(fp);


	return 1;
}
