// Implementation of the CMpInf class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMpInf::CMpInf()
{
	m_nId	= -1;															// Index
	memset(m_sN, 0, sizeof(m_sN));											// Name
	m_vcP	= VEC3(0,0,0);													// Position
	D3DXMatrixIdentity(&m_mtW);

	
	m_nId	= 10;
	strcpy(m_sN, "Arcadia Town");
	m_vcP	= VEC3(100,0,100);
	m_mtW._41 = m_vcP.x;
	m_mtW._42 = m_vcP.y;
	m_mtW._43 = m_vcP.z;
}


CMpInf::~CMpInf()
{
	
}


INT CMpInf::FileRead(FILE* fp)
{
	fread(&m_nId,	sizeof(m_nId),	1, fp);
	fread(m_sN,		sizeof(m_sN),	1, fp);
	fread(&m_vcP,	sizeof(m_vcP),	1, fp);

	return 1;
}


INT CMpInf::FileWrite(FILE* fp)
{
	fwrite(&m_nId,	sizeof(m_nId),	1, fp);
	fwrite(m_sN,	sizeof(m_sN),	1, fp);
	fwrite(&m_vcP,	sizeof(m_vcP),	1, fp);

	return 1;
}