// Implementation of the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndWrk1, MsgPrc);


INT CWndWrk1::Init()
{
	return 1;
}


INT CWndWrk1::Create(HWND hWnd)
{
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_WRK1), hWnd, CLSS_DLG_WNDPROC(CWndWrk1));

	m_iRng	= 8;
	m_fDH	= 5.f;
	m_bAc	= 1;

	SetDlgItemInt(m_hWnd, IDC_WRK1_DH,	m_fDH,	1);
	SetDlgItemInt(m_hWnd, IDC_WRK1_RNG, m_iRng,	0);

	SendMessage(GetDlgItem(m_hWnd, IDC_WRK1_AC),BM_SETCHECK,m_bAc,0);

	memset(m_bmBtn, 0, sizeof(m_bmBtn));
	m_bmBtn[0] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN27));
	m_bmBtn[1] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN31));

	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_CREATE, BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[0]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_LOAD,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[1]);
	
	return 1;
}


void CWndWrk1::Destroy()
{
	SAFE_DELETE_OBJECT_ARRAY(m_bmBtn, (sizeof(m_bmBtn)/sizeof(m_bmBtn[0])) );
	SAFE_DESTROY_WINDOW(m_hWnd);
}


INT	CWndWrk1::Restore()
{
	HRESULT hr;

	if(!GMAIN->m_bWindowed)
		return 1;

	m_SwpWn.hW = (HWND)GetDlgItem(m_hWnd, IDC_WRK1_PANNEL);

	D3DPRESENT_PARAMETERS	par;
	memset(&par, 0, sizeof(D3DPRESENT_PARAMETERS));
	
	par.SwapEffect = D3DSWAPEFFECT_DISCARD;
	par.Windowed = TRUE;
	
	RECT rt;
	GetWindowRect(m_SwpWn.hW, &rt);

	par.BackBufferWidth= 0;
	par.BackBufferHeight= 0;
	par.hDeviceWindow = m_SwpWn.hW;

	hr = GDEVICE->CreateAdditionalSwapChain(&par, &m_SwpWn.pC) ;

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Create addtional swap chain failed");
		return hr;
	}

	hr = m_SwpWn.pC->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Get back buffer Failed");
		return hr;
	}


	D3DFORMAT format = GMAIN->m_d3dSettings.DepthStencilBufferFormat();
	hr = GDEVICE->CreateDepthStencilSurface(par.BackBufferWidth, par.BackBufferHeight, format, D3DMULTISAMPLE_NONE, 0, 0, &m_SwpWn.pS, NULL);

	if ( FAILED(hr))
	{
		MessageBox(NULL, "Failed", "Failed", MB_OK);
		return -1;
	}

	return 1;
}


void CWndWrk1::Invalidate()
{
	m_SwpWn.Release();
}


INT CWndWrk1::FrameMove()
{
	return 1;
}



void CWndWrk1::Render()
{
	if(GP_WRK1 != GMAIN->m_ePhCur)
		return;

	if(!GMAIN->m_bWindowed)
		return;

	GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
	GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	
	GDEVICE->Clear( 0L, 0, GMAIN->m_dwClr,  0x00006699, 1.0f, 0L );

	SAFE_RENDER(	GCAM	);

	RECT rt={5,10, 1024,30};
	GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFFFF);

	m_SwpWn.pC->Present(0, 0, 0, 0, 0);
}



LRESULT CWndWrk1::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	static	TVITEMEX	TvResEx;
	static	TVITEMEX	TvResPr;
	static	HTREEITEM	hResPrn;
	static	TCHAR		sResCap[30] = "\0";
	static	TCHAR		sResPrn[30] = "\0";
	static	HWND		hwnd;

	hwnd = (HWND)lParam;

	switch( uMsg )
	{
		case WM_NOTIFY:
		{
			LPNMHDR hdr;
			LPNMTREEVIEW ntv;
			hdr=(LPNMHDR)lParam;
			ntv=(LPNMTREEVIEW)lParam;

			hwnd = GetDlgItem(hWnd, IDC_WRK1_TREE);

			if(hdr->hwndFrom == hwnd)
			{
				switch (hdr->code)
				{
					// ���õ� �׸��� �����ش�.
					case TVN_SELCHANGED:
					{
						TvResEx.mask=TVIF_PARAM | TVIF_TEXT;
						TvResEx.hItem=ntv->itemNew.hItem;
						TvResEx.pszText=sResCap;
						TvResEx.cchTextMax=sizeof(sResCap);
						TreeView_GetItem(hwnd,&TvResEx);

						hResPrn = TreeView_GetParent(hwnd, TvResEx.hItem);

						if(hResPrn)
						{
							TvResPr.mask=TVIF_PARAM | TVIF_TEXT;
							TvResPr.hItem=hResPrn;
							TvResPr.pszText=sResPrn;
							TvResPr.cchTextMax=sizeof(sResPrn);
							TreeView_GetItem(hwnd,&TvResPr);

//							sscanf(sResCap, "%d %d", &nM, &nS);
						}

						else
						{
							sResPrn[0] = '\0';
						}

						break;
					}
				}
			}


			break;
		}


		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_WRK1_LCL_CREATE:
				{
					m_WndCreate.Create(GHWND);
					m_WndCreate.ShowWindow();

					break;
				}

				case IDC_WRK1_RNG:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
							m_iRng = GetDlgItemInt(hWnd, IDC_WRK1_RNG, 0,0);
							break;
					}

					break;
				}


				case IDC_WRK1_DH:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
							m_fDH= GetDlgItemFlt(hWnd, IDC_WRK1_DH);
							break;
					}

					break;
				}


				case IDC_WRK1_AC:
				{
					if (SendMessage(GetDlgItem(hWnd, IDC_WRK1_AC),BM_GETCHECK,0,0)==BST_CHECKED)
						m_bAc = 1;
					else
						m_bAc =0;

					break;
				}

			}

			break;

		}// case WM_COMMAND


		

	}

	return(FALSE);
}