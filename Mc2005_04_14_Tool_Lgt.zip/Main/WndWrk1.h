// Interface for the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK1_H_
#define _WNDWRK1_H_

class CWndWrk1
{
public:
	HWND			m_hWnd		;
	TlSwpWn			m_SwpWn		;												// Swap Chain Window

	CWndCreate		m_WndCreate	;
	INT				m_iRng		;
	FLOAT			m_fDH		;
	INT				m_bAc		;												//

protected:
	HBITMAP			m_bmBtn[20];
	
public:
	CLSS_DLG_DECLEAR( CWndWrk1 );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif