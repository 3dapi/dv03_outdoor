// Mc common data header files.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCCOMMON_H_
#define _MCCOMMON_H_


#define MC_DX_VER	0x00090002													// DirectX version
#define MC_FL_VER	0x00000101													// File version

#define EXC_TITLE	"MC_MAP"
#define EXC_VER		"0.00.01"
#define EXC_MTX		EXC_TITLE"_"EXC_VER
#define EXC_MTX_ON	1

typedef enum tagEGmPhase
{
	GP_WRK1=0,																	// Resource Window
	GP_WRK2,																	// App Window
	GP_WIN,
}EGmPhase;



#endif