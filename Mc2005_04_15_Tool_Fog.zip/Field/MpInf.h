// Interface for the CMpInf class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPINF_H_
#define _MPINF_H_


class CMpInf																	// Information
{
public:
	INT			m_nId;															// Index
	CHAR		m_sN[64];														// Name
	VEC3		m_vcP;															// Position
	MATA		m_mtW;															// World Matrix

public:
	CMpInf();
	virtual ~CMpInf();
	
	INT		FileRead(FILE* fp);
	INT		FileWrite(FILE* fp);
};

#endif
