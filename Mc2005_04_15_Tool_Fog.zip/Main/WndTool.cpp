// WndTool.cpp: implementation of the CWndTool class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndTool, MsgPrc);


INT CWndTool::Init()
{
	m_hWnd	= 0;
	m_hWPrn	= 0;

	m_dC= 0xFF0000FF;

	for(int i=0; i< sizeof(m_crT)/sizeof(m_crT[0]); ++i)
		m_crT[i] = RGB( 128+rand()%128, 128+rand()%128, 128+rand()%128);

	return 1;
}


INT CWndTool::Create(HWND hWnd)
{
	if(m_hWnd)
		return 1;

	m_hWPrn= hWnd;
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_TOOL), m_hWPrn, CLSS_DLG_WNDPROC(CWndTool));
	m_hCol	= GetDlgItem(m_hWnd, IDC_TOOL_COL);

	RECT	rt1;
	RECT	rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(GHWND, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left -0;
	iY = rt1.top  +40;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);

	memset(m_bTool, 0, sizeof(m_bTool));
	memset(m_bmBtn, 0, sizeof(m_bmBtn));

	m_bmBtn[ 0] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN01));
	m_bmBtn[ 1] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN02));
	m_bmBtn[ 2] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN03));
	m_bmBtn[ 3] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN04));
	m_bmBtn[ 4] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN21));
	
	m_bmBtn[ 5] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN22));
	m_bmBtn[ 6] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN23));
	m_bmBtn[ 7] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN24));
	m_bmBtn[ 8] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN25));
	m_bmBtn[ 9] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN26));
	
	m_bmBtn[10] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN27));
	m_bmBtn[11] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN28));
	m_bmBtn[12] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN29));
	m_bmBtn[13] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN30));
	m_bmBtn[14] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN31));
	
	m_bmBtn[15] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN32));
	m_bmBtn[16] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN33));
	m_bmBtn[17] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN34));
	m_bmBtn[18] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN35));
	m_bmBtn[19] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN36));
	m_bmBtn[20] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN37));

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT01,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 0]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT02,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 1]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT03,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 2]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT04,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 3]);

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT05,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 4]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT06,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 5]);

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT07,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[18]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT08,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[19]);
	
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT09,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[20]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT10,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 9]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT11,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[10]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT12,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[11]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT13,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[12]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT14,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 7]);

	BYTE* pClr	= McUtil_GetColorARGB(m_dC);
	BYTE ClrR	= pClr[1];
	BYTE ClrG	= pClr[2];
	BYTE ClrB	= pClr[3];

	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
	SetDlgItemHex(m_hWnd, IDC_TOOL_COL_ALL, 0xFF0000FF, false);



	m_bTool[0] = 1;
	CheckRadioButton(m_hWnd, IDC_TOOL_BT01, IDC_TOOL_BT14, IDC_TOOL_BT14);

	::ShowWindow(m_hWnd, SW_SHOW);

	

	RECT	rc;
	HDC		hdc;
	hdc		= GetDC(m_hCol);

	GetClientRect(m_hCol, &rc);
	HBRUSH hbrsh = CreateSolidBrush(m_dC);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(m_hWnd, hdc);

	return 1;
}

void CWndTool::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}


void CWndTool::Destroy()
{
	SAFE_DELETE_OBJECT_ARRAY(m_bmBtn, sizeof(m_bmBtn)/sizeof(m_bmBtn[0]) );
	SAFE_DESTROY_WINDOW(m_hWnd);
}

LRESULT CWndTool::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	BYTE		ClrR;
	BYTE		ClrG;
	BYTE		ClrB;

	switch( uMsg )
	{
		case WM_PAINT:
		{
			HDC		hdc;
			RECT	rc;
			PAINTSTRUCT ps;
			hdc = BeginPaint(m_hCol, &ps);

			GetClientRect(m_hCol, &rc);

			BYTE bgr[4];
			memset(bgr, 0, sizeof(bgr));
			memcpy(bgr, &m_dC, sizeof(bgr));
			COLORREF	col = RGB(bgr[2],bgr[1], bgr[0]);
			HBRUSH hbrsh = CreateSolidBrush(col);
			FillRect(hdc, &rc, hbrsh);
			DeleteObject(hbrsh);
			EndPaint(m_hCol, &ps);
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_TOOL_BT01:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 0] =1;	break;
				case IDC_TOOL_BT02:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 1] =1;	break;
				case IDC_TOOL_BT03:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 2] =1;	break;
				case IDC_TOOL_BT04:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 3] =1;	break;

				case IDC_TOOL_BT05:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 4] =1;	break;		// Brush
				case IDC_TOOL_BT06:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 5] =1;	break;		// Pick Color

				case IDC_TOOL_BT10:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[ 9] =1;	break;
				case IDC_TOOL_BT11:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[10] =1;	break;
				case IDC_TOOL_BT12:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[11] =1;	break;
				case IDC_TOOL_BT13:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[12] =1;	break;
				case IDC_TOOL_BT14:	memset(m_bTool, 0, sizeof(m_bTool));	m_bTool[13] =1;	break;


				// Material
				case IDC_TOOL_BT07:
				{
					memset(m_bTool, 0, sizeof(m_bTool));
					m_bTool[ 6] =1;

					m_WndMtrl.Create(GHWND);
					m_WndMtrl.ShowWindow();
					break;
				}

				// Lighting
				case IDC_TOOL_BT08:
				{
					memset(m_bTool, 0, sizeof(m_bTool));
					m_bTool[ 7] =1;

					m_WndLght.Create(GHWND);
					m_WndLght.ShowWindow();
					break;
				}


				// Fog
				case IDC_TOOL_BT09:
				{
					memset(m_bTool, 0, sizeof(m_bTool));
					m_bTool[ 8] =1;

					m_WndFog.Create(GHWND);
					m_WndFog.ShowWindow();
					break;
				}


				case IDC_TOOL_COL:
				{
					CHOOSECOLOR COL;
					
					memset(&COL, 0, sizeof(CHOOSECOLOR));
					COL.lStructSize = sizeof(CHOOSECOLOR);
					COL.hwndOwner=hWnd;
					COL.lpCustColors=m_crT;

					if (ChooseColor(&COL))
					{
						HWND hwWrk = GMAIN->m_Wrk.m_Wrk1.m_hWnd;
						SetPickColor(COL.rgbResult, true);
						
						BYTE* pClr	= McUtil_GetColorARGB(m_dC);
						BYTE ClrR	= pClr[1];
						BYTE ClrG	= pClr[2];
						BYTE ClrB	= pClr[3];

						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
						SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC, false);
					}

					break;
				}

				case IDC_TOOL_COL_R:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}

				case IDC_TOOL_COL_G:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}

				case IDC_TOOL_COL_B:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}


				case IDC_TOOL_COL_ALL:
				{
					break;
				}

			}// switch
			
			break;
		}



		case WM_NOTIFY:
		{
			break;
		}// case
	}

	return(FALSE);
}



void CWndTool::SetPickColor(DWORD	dC, bool IsBGR)
{
	COLORREF	col;
	BYTE		bgr[4];

	memset(bgr, 0, sizeof(bgr));
	memcpy(bgr, &dC, sizeof(bgr));

	if(IsBGR)
	{
		m_dC = D3DCOLOR_XRGB(bgr[0],bgr[1], bgr[2]);
		col = dC;
	}
	else
	{
		m_dC = dC;
		col = RGB(bgr[2],bgr[1], bgr[0]);
	}
						
	RECT	rc;
	HDC		hdc = GetDC(m_hCol);
	HBRUSH	hbrsh = CreateSolidBrush(col);

	GetClientRect(m_hCol, &rc);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(m_hWnd, hdc);
}

FLOAT CWndTool::GetDirection()
{
	return (m_bTool[ 0]*1.f - m_bTool[ 1]*1.f);
}



void CWndTool::SetColor(DWORD dc)
{
	m_dC = dc;
	BYTE* pClr	= McUtil_GetColorARGB(m_dC);
	BYTE ClrR	= pClr[1];
	BYTE ClrG	= pClr[2];
	BYTE ClrB	= pClr[3];

	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
}