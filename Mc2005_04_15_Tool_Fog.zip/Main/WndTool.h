// Interface for the CWndTool class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDTOOL_H_
#define _WNDTOOL_H_


#define TL_BTN_MX		37

class CWndTool
{
public:
	HWND		m_hWnd		;
	HWND		m_hWPrn		;

	HWND		m_hCol		;

	HBITMAP		m_bmBtn[TL_BTN_MX]	;
	bool		m_bTool[TL_BTN_MX]	;
	DWORD		m_dC		;													// color
	COLORREF	m_crT[32]	;

public:
	CWndMtrl	m_WndMtrl	;
	CWndLght	m_WndLght	;
	CWndFog		m_WndFog	;
	

public:
	CLSS_DLG_DECLEAR( CWndTool );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
protected:
	void	ShowWindow(int _ishw = SW_SHOW);
	void	SetPickColor(DWORD	dC, bool IsBGR=false);

public:
	FLOAT	GetDirection();
	INT		IsFlat()	{	return (m_bTool[ 2] * 1 - m_bTool[ 3] * 1);					}
	bool	IsHeight()	{	return (m_bTool[0]||m_bTool[1]||m_bTool[2]||m_bTool[3]);	}
	bool	UseBrush()	{	return m_bTool[ 4];											}
	bool	UseSpoid()	{	return m_bTool[ 5];											}

	void	SetColor(DWORD dc);
};

#endif