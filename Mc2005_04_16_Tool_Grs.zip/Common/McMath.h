// Interface for the Math class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNMATH_H_
#define _LNMATH_H_

//2D, or 3D Math
typedef struct tagINT2
{
	union	{	struct	{	INT x, z;	};	INT m[2];	};
	tagINT2():x(0),z(0){}
	tagINT2(INT X,INT Z):x(X),z(Z){}
}INT2;

typedef struct tagVECi2 : public tagINT2
{
	union	{	struct	{	INT x, z;	};	INT m[2];	};
	
	tagVECi2()									{	x = z = 0;								}
	tagVECi2(const INT *_m )					{	if(!_m){x=z=0;}else{x=_m[0];z=_m[2];}	}
	tagVECi2(const tagVECi2& rhs )					{	x = rhs.x;		z = rhs.z;				}
	tagVECi2( INT _x,INT _z)					{	x = _x;			z = _z;					}
	tagVECi2( VEC2 p)							{	x = INT(p.x);	z = INT(p.y);			}

	operator INT*()								{	return (INT *) &x;						}
	operator const INT*() const					{	return (const INT *) &x;				}
	
	// assignment operators
	tagVECi2& operator+=(const tagVECi2& v)		{	x += v.x;	z += v.z;	return *this;	}
	tagVECi2& operator-=(const tagVECi2& v)		{	x -= v.x;	z -= v.z;	return *this;	}
	tagVECi2& operator*=(INT f )				{	x *= f;		z *= f;		return *this;	}
	tagVECi2& operator/=(INT f )				{	x /= f;		z /= f;		return *this;	}
	
	// unary operators
	tagVECi2 operator+() const					{	return *this;							}
	tagVECi2 operator-() const					{	return tagVECi2(-x, -z);				}
	
	// binary operators
	tagVECi2 operator+(const tagVECi2& v)const	{	return tagVECi2(x + v.x, z + v.z);		}
	tagVECi2 operator-(const tagVECi2& v)const	{	return tagVECi2(x - v.x, z - v.z);		}
	tagVECi2 operator*(INT f) const				{	return tagVECi2(x*f, z*f);				}
	tagVECi2 operator/(INT f) const				{	return tagVECi2(x/f, z/f);				}

	friend tagVECi2 operator*(INT f,const tagVECi2& v)
												{	return tagVECi2(f * v.x, f * v.z);		}

	bool operator==(const tagVECi2& v) const	{	return x == v.x && z == v.z;			}
	bool operator!=(const tagVECi2& v) const	{	return x != v.x || z != v.z;			}

}VECi2;


typedef	vector<VECi2>		lsVECi2;
typedef	lsVECi2::iterator	itVECi2;

typedef struct tagINT3
{
	union{struct{INT x, y, z;};	INT m[3];};
	tagINT3():x(0),y(0),z(0){}
	tagINT3(INT X,INT Y,INT Z):x(X),y(Y),z(Z){}
}INT3;


typedef struct tagVECi3 : public tagINT3
{
	tagVECi3()									{	x =				y =			  z = 0;		}
	tagVECi3(const INT *_m )					{	if(!_m){x=y=z=0;}else{x=_m[0];y=_m[1];z=_m[2];}	}
	tagVECi3(const tagVECi3& rhs )					{	x = rhs.x;		y= rhs.y;	  z = rhs.z;	}
	tagVECi3( INT _x,INT _y, INT _z)			{	x = _x;			y = _y;		  z = _z;		}
	tagVECi3(VEC3 p)							{	x = INT(p.x);	y = INT(p.y); z = INT(p.z);	}
	tagVECi3(FLOAT _x, FLOAT _y, FLOAT _z)		{	x = INT(_x);	y = INT(_y);  z = INT(_z);	}

	operator INT*()								{	return (INT *) &x;							}
	operator const INT*() const					{	return (const INT *) &x;					}
	
	tagVECi3& operator+=(const tagVECi3& v)		{	x += v.x; y += v.y;	z += v.z; return *this;	}
	tagVECi3& operator-=(const tagVECi3& v)		{	x -= v.x; y -= v.y;	z -= v.z; return *this;	}
	tagVECi3& operator*=(INT f )				{	x *= f;	 y *= f;	z *= f;	  return *this;	}
	tagVECi3& operator/=(INT f )				{	x /= f;	 y /= f;	z /= f;	  return *this;	}
	
	tagVECi3 operator+() const					{	return *this;								}
	tagVECi3 operator-() const					{	return tagVECi3(-x,-y, -z);					}
	
	tagVECi3 operator+(const tagVECi3& v)const	{	return tagVECi3(x + v.x, y + v.y, z + v.z);	}
	tagVECi3 operator-(const tagVECi3& v)const	{	return tagVECi3(x - v.x, y - v.y, z - v.z);	}
	tagVECi3 operator*(INT f) const				{	return tagVECi3(x*f, y*f, z*f);				}
	tagVECi3 operator/(INT f) const				{	return tagVECi3(x/f, y/f, z/f);				}

	friend tagVECi3 operator*(INT f,const tagVECi3& v)
												{	return tagVECi3(f * v.x, f * v.y, f * v.z);	}

	bool operator==(const tagVECi3& v) const	{	return x == v.x && y == v.y && z == v.z;	}
	bool operator!=(const tagVECi3& v) const	{	return x != v.x || y != v.y || z != v.z;	}

}VECi3;


typedef	vector<VECi3>		lsVECi3;
typedef	lsVECi3::iterator	itVECi3;


typedef struct tagINT4
{
	union	{	struct	{	INT x, y, z, w;	};	INT m[4];	};
	tagINT4():x(0),y(0),z(0),w(0){}
	tagINT4(INT X,INT Y,INT Z,INT W):x(X),y(Y),z(Z),w(W){}
}INT4;


typedef struct tagVECi4 : public tagINT4
{
	tagVECi4()									{	x=y=z=w=0;									}
	tagVECi4(const INT *_m )	{	if(!_m){x=y=z=w=0;}else{x=_m[0];y=_m[1];z=_m[2];w=_m[3];}	}
	tagVECi4(const tagVECi4& r )						{	x=r.x; y=r.y; z=r.z; w= r.w;				}
	tagVECi4(INT X,INT Y,INT Z,INT W)			{	x=X; y=Y; z=Z; w=W;							}
	tagVECi4(VEC4 p)							{	x=INT(p.x);y=INT(p.y);z=INT(p.z);w=INT(p.w);}

	operator INT*()								{	return (INT *) &x;							}
	operator const INT*() const					{	return (const INT *) &x;					}
	
	// assignment operators
	tagVECi4& operator+=(const tagVECi4& v)		{	x+=v.x;y+=v.y;z+=v.z;w+=v.w;return *this;	}
	tagVECi4& operator-=(const tagVECi4& v)		{	x-=v.x;y-=v.y;z-=v.z;w-=v.w;return *this;	}
	tagVECi4& operator*=(INT f )				{	x*=f; y*=f;	z*=f; w*=f;		return *this;	}
	tagVECi4& operator/=(INT f )				{	x/=f; y/=f;	z/=f; w/=f;		return *this;	}
	
	// unary operators
	tagVECi4 operator+() const					{	return *this;								}
	tagVECi4 operator-() const					{	return tagVECi4(-x,-y,-z,-w);				}
	
	// binary operators
	tagVECi4 operator+(const tagVECi4& v)const	{	return tagVECi4(x+v.x,y+v.y,z+v.z,w+v.w);	}
	tagVECi4 operator-(const tagVECi4& v)const	{	return tagVECi4(x-v.x,y-v.y,z-v.z,w-v.w);	}
	tagVECi4 operator*(INT f) const				{	return tagVECi4(x*f,y*f,z*f, w*f);			}
	tagVECi4 operator/(INT f) const				{	return tagVECi4(x/f, y/f, z/f, w/f);		}

	friend tagVECi4 operator*(INT f,const tagVECi4& v)
												{	return tagVECi4(f*v.x,f*v.y,f*v.z,f*v.w);	}

	bool operator==(const tagVECi4& v) const	{	return x==v.x&&y==v.y&&z==v.z&&w==v.w;		}
	bool operator!=(const tagVECi4& v) const	{	return x!=v.x||y!=v.y||z!=v.z||w!=v.w;		}

}VECi4;


typedef	vector<VECi4>		lsVECi4;
typedef	lsVECi4::iterator	itVECi4;


typedef struct tagMcRc
{
	union	{	struct	{	float x0, y0, x1, y1;	};	float m[4];		};
	
	tagMcRc()									{	x0 = y0 = x1 = y1 = 0.f;										}
	tagMcRc(const FLOAT *_m )					{	x0 = _m[0];	y0 = _m[1];	x1 = _m[2];	y1 = _m[3];					}

	tagMcRc(const tagMcRc& _rt )						{	x0 = _rt.x0; y0 = _rt.y0; x1 = _rt.x1;	y1 = _rt.y1;			}

	tagMcRc( FLOAT fx0,FLOAT fy0,FLOAT fx1,FLOAT fy1)
												{	x0 = fx0;	y0 = fy0;	x1 = fx1;	y1 = fy1;					}

	tagMcRc( VEC2 p0, VEC2 p1)					{	x0 = p0.x;	y0 = p0.y;	x1 = p1.x;	y1 = p1.y;					}

	VEC2   Get00()	 const						{	return VEC2(x0, y0);											}
	VEC2   Get10()	 const						{	return VEC2(x1, y0);											}
	VEC2   Get01()	 const						{	return VEC2(x0, y1);											}
	VEC2   Get11()	 const						{	return VEC2(x1, y1);											}

	RECT   GetRECT()							{	RECT r={LONG(x0),LONG(y0),LONG(x1),LONG(y1)};	return r;		}
	D3DRECT   GetRectD3()						{	D3DRECT r={LONG(x0),LONG(y0),LONG(x1), LONG(y1)};	return r;	}

	FLOAT	GetWidth()							{	return (x1 - x0);												}
	FLOAT	GetHeight()							{	return (y1 - y0);												}
	
	// casting
	operator FLOAT*()							{	return (FLOAT *) &x0;											}
	operator const FLOAT*() const				{	return (const FLOAT *) &x0;										}
	
	// assignment operators
	tagMcRc& operator+=(const tagMcRc& v)		{	x0 += v.x0;	y0 += v.y0;	x1 += v.x1;	y1 += v.y1;	return *this;	}
	tagMcRc& operator-=(const tagMcRc& v)		{	x0 -= v.x0;	y0 -= v.y0;	x1 -= v.x1;	y1 -= v.y1;	return *this;	}
	tagMcRc& operator*=(FLOAT f )				{	x0 *= f;	y0 *= f;	x1 *= f;	y1 *= f;	return *this;	}
	tagMcRc& operator/=(FLOAT f )				{	FLOAT fInv = 1.0f / f;	x0 *= fInv;	y0 *= fInv;	x1 *= fInv;	y1 *= fInv;		return *this;	}
	
	// unary operators
	tagMcRc operator+() const					{	return *this;													}
	tagMcRc operator-() const					{	return tagMcRc(-x0, -y0, -x1, -y1);								}
	
	// binary operators
	tagMcRc operator+(const tagMcRc& v)const	{	return tagMcRc(x0 + v.x0, y0 + v.y0, x1 + v.x1, y1 + v.y1);		}
	tagMcRc operator-(const tagMcRc& v)const	{	return tagMcRc(x0 - v.x0, y0 - v.y0, x1 - v.x1, y1 - v.y1);		}
	tagMcRc operator*(FLOAT f) const			{	return tagMcRc(x0 * f, y0 * f, x1 * f, y1 * f);				}
	tagMcRc operator/(FLOAT f) const			{	FLOAT fInv = 1.0f / f;	return tagMcRc(x0 * fInv, y0 * fInv, x1 * fInv, y1 * fInv);		}

	friend tagMcRc operator*(FLOAT f,const tagMcRc& v)
												{	return tagMcRc(f * v.x0, f * v.y0, f * v.x1, f * v.y1);			}

	bool operator==(const tagMcRc& v) const		{	return x0 == v.x0 && y0 == v.y0 && x1 == v.x1 && y1 == v.y1;	}
	bool operator!=(const tagMcRc& v) const		{	return x0 != v.x0 || y0 != v.y0 || x1 != v.x1 || y0 != v.y1;	}
}McRc;

typedef	vector<McRc>		lsMcRc;
typedef	lsMcRc::iterator	itMcRc;



#endif