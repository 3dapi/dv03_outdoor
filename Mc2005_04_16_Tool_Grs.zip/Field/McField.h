// Interface for the CMcField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFIELD_H_
#define _MCFIELD_H_

class CMcField
{
public:
	CMpInf		m_Inf	;
	CMpMsh		m_Msh	;

	CMcGrs*		m_pGrs	;

	lsTlPkT		m_vPk	;
	bool		m_bClick;
	VEC3		m_vcPck	;

public:
	CMcField();
	~CMcField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		CreateBlc(INT iNx, INT iWx, FLOAT fUV, VEC3 pos);
	void	SetMaterial(DMTL& _mtl);
	void	SetAmbientLight(DWORD& _dAmL);
	void	SetLight(DLGT* pLgt, INT nCnt);
	void	SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns);
	
protected:
	INT		MapLoad();
	INT		MapSave();
};

#endif