// Implementation of the CMpMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMpMsh::CMpMsh()
{
	D3DXMatrixIdentity(&m_mtW);
	m_iNl	= 0;																// Lighting Num
	m_pLg	= 0;
	
	memset(&m_Mtl, 0, sizeof(m_Mtl));											// Material

	m_dFt	= D3DFOG_LINEAR;
	m_dFc	= 0;																// Fog Color
	m_fFb	= 0;																// Fog Begin
	m_fFe	= 0;																// Fog End
	m_fFd	= 1.f;
	
	m_dAb	= 0;																// Ambient color
	
	m_iNx	= 0;																// Number of tile for Width
	m_iWx	= 0;																// Width of tile for x;
	
	m_iNi	= 0;																// Index Number
	m_pIx	= 0;
	
	m_iNv	= 0;																// Vertex Number
	m_pVx	= 0;
	m_fUV	= 1.f;
	
	m_iVs	= 0;																// Vertex Size
	m_dFVF	= 0;
	
	m_iNt	= 0;																// Texture Num
	m_pTx	= 0;
	
	m_vcP.x = 0;
	m_vcP.y = 0;
	m_vcP.z = 0;
}



CMpMsh::~CMpMsh()
{
	Destroy();
}



void CMpMsh::Destroy()
{
	D3DXMatrixIdentity(&m_mtW);
	m_iNl	= 0;
	m_dFc	= 0;
	m_fFb	= 0;
	m_fFe	= 0;
	m_dAb	= 0;
	m_iNx	= 0;
	m_iWx	= 0;
	m_iNi	= 0;
	m_iNv	= 0;
	m_fUV	= 1.f;
	m_iVs	= 0;
	m_dFVF	= 0;
	m_iNt	= 0;
	
	SAFE_DELETE_ARRAY(	m_pLg	);
	SAFE_DELETE_ARRAY(	m_pIx	);
	SAFE_DELETE_ARRAY(	m_pVx	);
	
	//SAFE_DELETE_ARRAY(	m_sNt	);
	
	for(int i=0; i<m_iNt; ++i)
		SAFE_RELEASE(	m_pTx[0]	);
	
	SAFE_DELETE_ARRAY(	m_pTx	);
}



INT CMpMsh::Init()
{
	return 1;
}


INT CMpMsh::FrameMove()
{
	return 1;
}


void CMpMsh::Render()
{
	if(!m_pVx)
		return;

	GDEVICE->SetRenderState( D3DRS_LIGHTING,	GMAIN->m_bLgt);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE,	GMAIN->m_bFog);
	GDEVICE->SetRenderState( D3DRS_FILLMODE,	GMAIN->m_bFill);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	GDEVICE->SetSamplerState(1, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(1, D3DSAMP_MIPFILTER, D3DTEXF_NONE);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP );
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_WRAP );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_DISABLE );


	if(GMAIN->m_bLgt)
	{
		GDEVICE->SetLight( 1, &m_pLg[0] );	GDEVICE->LightEnable( 1, TRUE );
		GDEVICE->SetLight( 2, &m_pLg[1] );	GDEVICE->LightEnable( 2, TRUE );
		GDEVICE->SetLight( 3, &m_pLg[2] );	GDEVICE->LightEnable( 3, TRUE );

		GDEVICE->SetRenderState( D3DRS_AMBIENT, m_dAb);								// Set Ambient
		GDEVICE->SetMaterial( &m_Mtl );												// Set Material
	}
	

	GDEVICE->SetRenderState(D3DRS_FOGTABLEMODE, m_dFt);
	GDEVICE->SetRenderState(D3DRS_FOGCOLOR, m_dFc);								// Set Fog
	GDEVICE->SetRenderState(D3DRS_FOGSTART,		FtoDW(m_fFb));
	GDEVICE->SetRenderState(D3DRS_FOGEND,		FtoDW(m_fFe));
	GDEVICE->SetRenderState(D3DRS_FOGDENSITY,	FtoDW(m_fFd));

	GDEVICE->SetTransform(D3DTS_WORLD, &m_mtW);									// Set World

	GDEVICE->SetTexture(0, m_pTx[0]);											// Set Texture
	GDEVICE->SetFVF(m_dFVF);													// Set FVF

	GDEVICE->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, m_iNv, m_iNi
		, m_pIx, D3DFMT_INDEX16
		, m_pVx, m_iVs);
	

	
	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_CCW);

	D3DXMATRIX	mtWorld;
	D3DXMatrixIdentity(&mtWorld);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtWorld);
}



void CMpMsh::CreateMesh(INT iNx, INT iWx, FLOAT fUV)
{
	INT		z, x;

	m_iWx	= 128;
	m_dFVF	= VtxNDUV1::FVF;
	m_iVs	= sizeof(VtxNDUV1);
	m_fUV	= fUV;



	m_iNx = iNx;
	m_iWx = iWx;
	m_fUV = fUV;
	m_iNv	= m_iNx * m_iNx;
	m_pVx	= new VtxNDUV1[m_iNv];

	for(z=0; z<m_iNx; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			m_pVx[z * m_iNx + x].p = VEC3(FLOAT(x * m_iWx), 0.f, FLOAT(z * m_iWx));
			
			m_pVx[z * m_iNx + x].p += m_vcP;

			m_pVx[z * m_iNx + x].d =0xFFFFFFFF;
			m_pVx[z * m_iNx + x].u0 = x /m_fUV;
			m_pVx[z * m_iNx + x].v0 = z /m_fUV;
		}
	}

	SetNormal();
	SetIndex();
}


void CMpMsh::SetMaterial(DMTL& mtrl)
{
	memcpy( &m_Mtl, &mtrl, sizeof(m_Mtl) );
}


void CMpMsh::SetAmLgt(DWORD dAmLgt)
{
	m_dAb	= 0x00F0F0F0;
}



void CMpMsh::SetLight(DLGT* pLgt, INT iSize)
{
	SAFE_DELETE_ARRAY(	m_pLg	);
	
	m_iNl = iSize;
	m_pLg = new DLGT[m_iNl];

	memcpy(m_pLg, pLgt, sizeof(DLGT)*m_iNl );	
}



void CMpMsh::SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns)
{
	m_dFt	= dT;
	m_dFc	= dC;
	m_fFb	= fBgn;
	m_fFe   = fEnd;
	m_fFd	= fDns;
}



void CMpMsh::SetTexture()
{
	m_iNt	= 1;																// Texture Num

	m_sNt	= new char[m_iNt][128];
	m_pTx	= new PDTX[m_iNt];
	memset(m_pTx, 0, sizeof(PDTX)*m_iNt);

	strcpy(m_sNt[0], "Texture/detail2.jpg");										// 0 ��° �ؽ�ó �̸�
	McUtil_TextureLoad(m_sNt[0], m_pTx[0], 0x00000000);							//	Load texture
}



void CMpMsh::SetVertex()
{
	INT x, z;
	TCHAR sFile[] = "Map/Height3.raw";
	FILE* fp;
	
	fp = fopen(sFile, "rb");
	
	if(!fp)
	{
//		McUtil_ErrMsgBox("Height file load failed");
		return;
	}
	
	long end;
	
	fseek(fp, 0L, SEEK_SET);
	fseek(fp, 0L, SEEK_END);
	end	   = ftell(fp);
	fseek(fp, 0L, SEEK_SET);
	
	BYTE*	pHi = new BYTE[end];
	fread(pHi, sizeof(BYTE), end, fp);
	fclose(fp);
	

	m_iNv	= end;
	m_iNx	= int(sqrtf( FLOAT(m_iNv)));
	m_pVx	= new VtxNDUV1[m_iNv];
	
	
	for(z=0; z<m_iNx; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			FLOAT fH = pHi[ (m_iNx-1-z) * m_iNx + x];
			DWORD c;
		
			if( (fH) < 1.f )
				c = D3DCOLOR_XRGB(255, 249, 157);
			else if( (fH) < 35.0f )
				c = D3DCOLOR_XRGB(124, 197, 118);
			else if( (fH) < 75.5f )
				c = D3DCOLOR_XRGB(  0, 166,  81);
			else if( (fH) < 100.0f )
				c = D3DCOLOR_XRGB( 25, 123,  48);
			else if( (fH) < 140.5f )
				c = D3DCOLOR_XRGB(115, 100,  87);
			else
				c = D3DCOLOR_XRGB(255, 255, 255);
			
			m_pVx[z * m_iNx + x].p = VEC3(FLOAT(x * m_iWx), fH*4.5f, FLOAT(z * m_iWx));
			m_pVx[z * m_iNx + x].d = c;
			m_pVx[z * m_iNx + x].u0 = x /m_fUV;
			m_pVx[z * m_iNx + x].v0 = z /m_fUV;
		}
	}

	SAFE_DELETE_ARRAY(	pHi	);
}



void CMpMsh::SetDiffuse(int nIdx)
{
	INT		x,z;

	if(-1 == nIdx)
	{
		for(z=0; z<m_iNx; ++z)
		{
			for(x=0; x<m_iNx; ++x)
			{
				FLOAT fH = m_pVx[z * m_iNx + x].p.y;
				DWORD c;
			
				if( (fH) < -100.f )
					c = D3DCOLOR_XRGB(128, 120, 70);
				else if( (fH) < 100.f )
					c = D3DCOLOR_XRGB(255, 249, 157);
				else if( (fH) < 500.0f )
					c = D3DCOLOR_XRGB(124, 197, 118);
				else if( (fH) <2000.5f )
					c = D3DCOLOR_XRGB(  0, 166,  81);
				else if( (fH) < 3000.0f )
					c = D3DCOLOR_XRGB( 25, 123,  48);
				else if( (fH) < 4000.5f )
					c = D3DCOLOR_XRGB(115, 100,  87);
				else
					c = D3DCOLOR_XRGB(255, 255, 255);
				
				m_pVx[z * m_iNx + x].d = c;
			}
		}
	}

	else
	{
		FLOAT fH = m_pVx[nIdx].p.y;
		DWORD c;
	
		if( (fH) < -100.f )
			c = D3DCOLOR_XRGB(128, 120, 70);
		else if( (fH) < 100.f )
			c = D3DCOLOR_XRGB(255, 249, 157);
		else if( (fH) < 500.0f )
			c = D3DCOLOR_XRGB(124, 197, 118);
		else if( (fH) <2000.5f )
			c = D3DCOLOR_XRGB(  0, 166,  81);
		else if( (fH) < 3000.0f )
			c = D3DCOLOR_XRGB( 25, 123,  48);
		else if( (fH) < 4000.5f )
			c = D3DCOLOR_XRGB(115, 100,  87);
		else
			c = D3DCOLOR_XRGB(255, 255, 255);
		
		m_pVx[nIdx].d = c;
	}
}

void CMpMsh::SetIndex()
{
	INT		x, z;
	INT		iN;
	
	
	iN = m_iNx-1;
	
	m_iNi = 8 * (m_iNx-1)/2 * (m_iNx-1)/2;
	
	m_pIx = new VtxIdx[m_iNi];
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iNx*z + m_iNx+1 + 2*x;
			
			f[6] = index +m_iNx-1;	f[5] = index + m_iNx;	f[4] = index +m_iNx	+1;
			f[7] = index	   -1;	f[8] = index		;	f[3] = index		+1;
			f[0] = index -m_iNx-1;	f[1] = index - m_iNx;	f[2] = index -m_iNx	+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pIx[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}
}


void CMpMsh::SetNormal()
{
	INT		x,z;
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	
	for(z=0; z<m_iNx; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			m_pVx[m_iNx*z + x].n = -NormalVec(z, x);
		}
	}
}






VEC3 CMpMsh::NormalVec(int z, int x)
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	INT		i;

	INT		index = m_iNx*z + x;
	INT		iVtx[10];

	iVtx[9] = index;
	iVtx[0] = iVtx[9];
	iVtx[1] = iVtx[9];
	iVtx[2] = iVtx[9];
	iVtx[3] = iVtx[9];
	iVtx[4] = iVtx[9];
	iVtx[5] = iVtx[9];
	iVtx[6] = iVtx[9];
	iVtx[7] = iVtx[9];
	iVtx[8] = iVtx[9];
	
	if(0==z && 0==x)
	{
		iVtx[0] = iVtx[9] + 1;
		iVtx[1] = iVtx[0] + m_iNx;
		iVtx[2] = iVtx[9] + m_iNx;
	}

	else if(0==z && (m_iNx-1) == x)
	{
		iVtx[0] = iVtx[9] + m_iNx;
		iVtx[1] = iVtx[0] - 1;
		iVtx[2] = iVtx[9] - 1;
	}

	else if(0==z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iNx;
			iVtx[2] = iVtx[9] - 1;			
		}
		else
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iNx;
			iVtx[2] = iVtx[9] + m_iNx;
			iVtx[3] = iVtx[2] - 1;
			iVtx[4] = iVtx[9] - 1;
		}
	}
	
	else if( (m_iNx-1) == z && 0==x)
	{
		iVtx[0] = iVtx[9] - m_iNx;
		iVtx[1] = iVtx[0] + 1;
		iVtx[2] = iVtx[9] + 1;
	}

	else if( (m_iNx-1) == z && (m_iNx-1) == x)
	{
		iVtx[0] = iVtx[9] - 1;
		iVtx[1] = iVtx[0] - m_iNx;
		iVtx[2] = iVtx[9] - m_iNx;

	}

	else if((m_iNx-1) == z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iNx;
			iVtx[2] = iVtx[9] + 1;
		}
		else
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[0] - m_iNx;
			iVtx[2] = iVtx[9] - m_iNx;
			iVtx[3] = iVtx[2] + 1;
			iVtx[4] = iVtx[9] + 1;
		}
	}

	else if(0 == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - m_iNx;
			iVtx[1] = iVtx[9] + 1;
			iVtx[2] = iVtx[9] + m_iNx;
		}
		else
		{
			iVtx[0] = iVtx[9] - m_iNx;
			iVtx[1] = iVtx[0] + 1;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[2] + m_iNx;
			iVtx[4] = iVtx[9] + m_iNx;
		}
	}

	else if((m_iNx-1) == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + m_iNx;
			iVtx[1] = iVtx[9] - 1;
			iVtx[2] = iVtx[9] - m_iNx;
		}
		else
		{
			iVtx[0] = iVtx[9] + m_iNx;
			iVtx[1] = iVtx[0] - 1;
			iVtx[2] = iVtx[9] - 1;
			iVtx[3] = iVtx[2] - m_iNx;
			iVtx[4] = iVtx[9] - m_iNx;
		}
	}
	

	else
	{
		if(index%2)																// Ȧ ��
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iNx;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[9] + m_iNx;
			iVtx[4] = iVtx[0];
		}
		else																	// ¦ ��
		{
			iVtx[6] = index +m_iNx	-1;		iVtx[5] = iVtx[6] + 1;	iVtx[4] = iVtx[5] + 1;
			iVtx[7] = index			-1;		iVtx[9] = iVtx[7] + 1;	iVtx[3] = iVtx[9] + 1;
			iVtx[0] = index -m_iNx	-1;		iVtx[1] = iVtx[0] + 1;	iVtx[2] = iVtx[1] + 1;
			iVtx[8] = iVtx[0];
		}
	}

	for(i=0; i<8; ++i)
	{
		a = m_pVx[iVtx[i+0] ].p - m_pVx[iVtx[9] ].p;
		b = m_pVx[iVtx[i+1] ].p - m_pVx[iVtx[9] ].p;
		D3DXVec3Cross(&nT, &a, &b);
		D3DXVec3Normalize(&nT, &nT);
		n +=nT;
	}

	
	D3DXVec3Normalize(&n, &n);
	
	return n;
}




INT CMpMsh::FileRead(FILE* fp)
{
	fread(&m_iNl,	sizeof(m_iNl),	1, fp);

	fread(&m_Mtl,	sizeof(m_Mtl),	1, fp);

	fread(&m_dFc,	sizeof(m_dFc),	1, fp);
	fread(&m_fFb,	sizeof(m_fFb),	1, fp);
	fread(&m_fFe,	sizeof(m_fFe),	1, fp);

	fread(&m_dAb,	sizeof(m_dAb),	1, fp);

	fread(&m_iNx,	sizeof(m_iNx),	1, fp);
	fread(&m_iWx,	sizeof(m_iWx),	1, fp);

	fread(&m_iNi,	sizeof(m_iNi),	1, fp);
	fread(&m_iNv,	sizeof(m_iNv),	1, fp);
	fread(&m_fUV,	sizeof(m_fUV),	1, fp);
		
	fread(&m_iVs,	sizeof(m_iVs),	1, fp);
	fread(&m_dFVF,	sizeof(m_dFVF),	1, fp);

	fread(&m_iNt,	sizeof(m_iNt),	1, fp);

	if(m_iNl)
	{
		m_pLg	= new DLGT[m_iNl];
		fread(m_pLg,	sizeof(DLGT),		m_iNl, fp);
	}

	if(m_iNi)
	{
		m_pIx	= new VtxIdx[m_iNi];
		fread(m_pIx,	sizeof(VtxIdx),		m_iNi, fp);
	}

	if(m_iNv)
	{
		m_pVx	= new VtxNDUV1[m_iNv];
		fread(m_pVx,	sizeof(VtxNDUV1),	m_iNv, fp);
	}

	if(m_iNt)
	{
		m_sNt = new char[m_iNt][128];
		m_pTx	= new PDTX[m_iNt];
		memset(m_pTx, 0, sizeof(PDTX)*m_iNt);

		for(int i=0; i<m_iNt; ++i)
			fread(m_sNt[i],	sizeof(char),	128, fp);
	}

	McUtil_TextureLoad(m_sNt[0], m_pTx[0], 0x00000000);							//	Load texture

	return 1;
}


INT CMpMsh::FileWrite(FILE* fp)
{
	fwrite(&m_iNl,	sizeof(m_iNl),		1, fp);

	fwrite(&m_Mtl,	sizeof(m_Mtl),		1, fp);

	fwrite(&m_dFc,	sizeof(m_dFc),		1, fp);
	fwrite(&m_fFb,	sizeof(m_fFb),		1, fp);
	fwrite(&m_fFe,	sizeof(m_fFe),		1, fp);

	fwrite(&m_dAb,	sizeof(m_dAb),		1, fp);

	fwrite(&m_iNx,	sizeof(m_iNx),		1, fp);
	fwrite(&m_iWx,	sizeof(m_iWx),		1, fp);


	fwrite(&m_iNi,	sizeof(m_iNi),		1, fp);
	fwrite(&m_iNv,	sizeof(m_iNv),		1, fp);
	fwrite(&m_fUV,	sizeof(m_fUV),		1, fp);
	
	
	fwrite(&m_iVs,	sizeof(m_iVs),		1, fp);
	fwrite(&m_dFVF,	sizeof(m_dFVF),		1, fp);

	fwrite(&m_iNt, sizeof(m_iNt),		1, fp);

	if(m_iNl)
		fwrite(m_pLg,	sizeof(DLGT),		m_iNl, fp);

	if(m_iNi)
		fwrite(m_pIx,	sizeof(VtxIdx),		m_iNi, fp);

	if(m_iNv)
		fwrite(m_pVx,	sizeof(VtxNDUV1),	m_iNv, fp);

	if(m_iNt)
	{
		for(int i=0; i<m_iNt; ++i)
			fwrite(m_sNt[i],	sizeof(char),	128, fp);
	}

	return 1;
}





FLOAT CMpMsh::GetHeight(VEC3& pos)
{
	INT	x;
	INT	z;

	z = INT((-m_vcP.z + pos.z)/ m_iWx);
	x = INT((-m_vcP.x + pos.x)/ m_iWx);

	
	INT index = m_iNx*z + x;

	VEC3 pos0 = m_pVx[index].p;
	VEC3 posX;
	VEC3 posZ;
	VEC3 posT;


	float dX = pos.x - pos0.x;
	float dZ = pos.z - pos0.z;

	if( (x+z)%2)			// Ȧ��
	{
		if(dZ >(m_iWx-dX))			// ���� �ﰢ��
		{
			index += (m_iNx+1);

			pos0 = m_pVx[index].p;
			posX = m_pVx[index-1].p;
			posZ = m_pVx[index-m_iNx].p;
		}

		else
		{
			pos0 = m_pVx[index].p;
			posX = m_pVx[index+1].p;
			posZ = m_pVx[index+m_iNx].p;
		}
	}
	else					// ¦��
	{
		if(dZ > dX)			// ���� �ﰢ��
		{
			index += (m_iNx);

			pos0 = m_pVx[index].p;
			posX = m_pVx[index+1].p;
			posZ = m_pVx[index-m_iNx].p;
		}

		else
		{
			index += 1;

			pos0 = m_pVx[index].p;
			posX = m_pVx[index-1].p;
			posZ = m_pVx[index+m_iNx].p;
		}
	}

	posT  = pos0 + (posX - pos0) * dX/m_iWx + (posZ - pos0) * dZ/m_iWx;


	return posT.y;
}