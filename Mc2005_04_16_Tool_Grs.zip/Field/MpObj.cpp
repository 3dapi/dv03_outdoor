// Implementation of the CMpObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"

CMd2D::CMd2D()
{
	nT		= -1;
	pTx		= NULL;
	vcP		= VEC3(0,0,0);
	fR		= 0.f;
	pCam	= NULL;
	fImgX	= 0.f;
	fImgY	= 0.f;

	pVx[0] = VtxDUV1( 0, 0, 0, 0.001f, 0.001f);
	pVx[1] = VtxDUV1( 0, 0, 0, 0.999f, 0.001f);
	pVx[2] = VtxDUV1( 0, 0, 0, 0.001f, 0.999f);
	pVx[3] = VtxDUV1( 0, 0, 0, 0.999f, 0.999f);
}

INT CMd2D::FrameMove()
{
	MATA	mtB = pCam->GetMatrixViw();
	
	D3DXMatrixInverse(&mtB, 0, &mtB);
	
	VEC3 vcCam	= VEC3(mtB._41, mtB._42, mtB._43);
	VEC3 vcZ	= VEC3(mtB._31, mtB._32, mtB._33);
	
	mtB._41 = 0;
	mtB._42 = 0;
	mtB._43 = 0;
	
	FLOAT	fX;
	FLOAT	fY;
	VtxDUV1	Vtx[4];
	VEC3	vcTmp;

	
	vcTmp = vcP-vcCam;
	fR = D3DXVec3Dot(&vcZ, &vcTmp);

	SetColor( D3DXCOLOR( 1, 1, 1,  (500.f)/fabsf(fR)  ));

	fX = fImgX;
	fY = fImgY;

	pVx[0].d = dcC;
	pVx[1].d = dcC;
	pVx[2].d = dcC;
	pVx[3].d = dcC;

	Vtx[0].p = VEC3(-fX, fY, 0);
	Vtx[1].p = VEC3( fX, fY, 0);
	Vtx[2].p = VEC3(-fX,-fY, 0);
	Vtx[3].p = VEC3( fX,-fY, 0);
	
	D3DXVec3TransformCoord(&Vtx[0].p, &Vtx[0].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[1].p, &Vtx[1].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[2].p, &Vtx[2].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[3].p, &Vtx[3].p, &mtB);
	
	Vtx[0].p += vcP;
	Vtx[1].p += vcP;
	Vtx[2].p += vcP;
	Vtx[3].p += vcP;
	
	Vtx[0].p.y += fY * .9f;
	Vtx[1].p.y += fY * .9f;
	Vtx[2].p.y += fY * .9f;
	Vtx[3].p.y += fY * .9f;
	
	pVx[0].p = Vtx[0].p;
	pVx[1].p = Vtx[1].p;
	pVx[2].p = Vtx[2].p;
	pVx[3].p = Vtx[3].p;

	return 1;
}

void CMd2D::Render()
{
	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	GDEVICE->SetTexture(0, pTx);
	GDEVICE->SetFVF(VtxDUV1::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &pVx, sizeof(VtxDUV1));

	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}
