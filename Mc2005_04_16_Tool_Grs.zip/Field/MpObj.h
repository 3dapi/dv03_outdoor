// Interface for the CMpObj class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MPOBJ_H_
#define _MPOBJ_H_


struct McImg
{
	PDTX	pTx;
	DIMG	Img;
};

typedef vector<McImg>			lsMcImg;
typedef lsMcImg::iterator		itMcImg;

class CMd2D
{
public:
	INT			nT;																// Texture Index;
	PDTX		pTx;
	VEC3		vcP;															// Position
	FLOAT		fR;																// Distance From Camera
	CMcCam*		pCam;

	FLOAT		fImgX;
	FLOAT		fImgY;
	DCLR		dcC;
	VtxDUV1		pVx[4];

public:
	CMd2D();
	INT		FrameMove();
	void	Render();

	void	SetCam(CMcCam*	_pCam)	{	pCam=_pCam;	}
	void	SetColor(DWORD _dc)		{	dcC= _dc;	}
};


typedef vector<CMd2D>			lsMdl2D;
typedef lsMdl2D::iterator		itMdl2D;

typedef vector<lsMdl2D >		llsMdl2D;
typedef llsMdl2D::iterator		iitMdl2D;


class CMd3D																	// Camera Independent
{
public:
	INT			nT;																// Texture Index;
	PDTX		pTx;
	VEC3		vcP;															// Position
	FLOAT		fR;																// Distance From Camera
	CMcCam*		pCam;

	CMd3D():nT(-1),pTx(0),vcP(0,0,0),fR(0), pCam(0){}

	INT		FrameMove();
	void	Render();

	void	SetCam(CMcCam*	_pCam)	{	pCam=_pCam;	}
};


typedef vector<CMd3D>			lsMdl3D;
typedef lsMdl2D::iterator		itMdl3D;

typedef vector<lsMdl3D >		llsMdl3D;
typedef llsMdl3D::iterator		iitMdl3D;


#endif