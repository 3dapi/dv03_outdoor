// Interface for the CWndWrk class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK_H_
#define _WNDWRK_H_


class CWndWrk
{
public:
	HWND			m_hWnd		;

	HWND			m_hwTab		;												// Tab control handle

	INT				m_nTabCur	;
	INT				m_nTabOld	;

	HIMAGELIST		m_gWrk		;												// Image List for Tab and List control
	CWndTool		m_Tool		;												// Tool dialog
	CWndWrk1		m_Wrk1		;
	CWndWrk2		m_Wrk2		;

public:
	CLSS_DLG_DECLEAR( CWndWrk );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif