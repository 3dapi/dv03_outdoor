// Interface for the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK1_H_
#define _WNDWRK1_H_

class CWndWrk1
{
public:
	HWND			m_hWnd		;
	TlSwpWn			m_SwpWn		;												// Swap Chain Window

	HWND			m_hGrp		;												// Group
	HWND			m_hObj		;												// Object
	HWND			m_hLst		;												// List

	INT				m_nGrp		;
	INT				m_nObj		;
	INT				m_nLst		;
	CMd2D			m_Obj		;

	CWndCreate		m_WndCreate	;
	INT				m_iRng		;
	FLOAT			m_fDH		;
	INT				m_bAc		;												//

protected:
	HBITMAP			m_bmBtn[20]	;

	lsStr			m_vTxStr	;
	lsMcImg			m_vTxImg	;
	
public:
	CLSS_DLG_DECLEAR( CWndWrk1 );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	void	DataTxRead();
	void	DataTxWrite();


public:
	INT		GetRng()	{	return m_iRng;	}
	INT		GetLstIdx()	{	return m_nLst;	}
	void	SetObj();
	CMd2D*	GetObj()	{	return &m_Obj;	}
};

#endif