// Implementation of the CMcGrs class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcGrs::CMcGrs()
{
}


CMcGrs::~CMcGrs()
{
	Destroy();
}


INT CMcGrs::Init()
{
	INT i=0;

	return 1;
}


void CMcGrs::Destroy()
{
	for(INT i=0; i<m_vvBill.size(); ++i)
		m_vvBill[i].clear();
	
	m_vvBill.clear();
}


INT CMcGrs::FrameMove()
{
	INT		i, j;
	INT		iSize, jSize;

	m_vBill.clear();
	iSize = m_vvBill.size();
	
	for(i=0; i<iSize; ++i)
	{
		lsMdl2D*	vMdl2D = &m_vvBill[i];

		jSize = vMdl2D->size();

		for(j=0; j<jSize; ++j)
		{
			itMdl2D pObj = vMdl2D->begin() + j;

			pObj->FrameMove();

			m_vBill.push_back(*pObj);
		}

//		sort(vMdl2D->begin(), vMdl2D->end(), CLnSrtG<CMd2D >());
	}
	
	sort(m_vBill.begin(), m_vBill.end(), CLnSrtG<CMd2D >());

	return 1;
}


void CMcGrs::Render()
{
	INT		i;
	INT		iSize;
	
//	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	iSize = m_vBill.size();
	
	for(i=0; i<iSize; ++i)
		m_vBill[i].Render();

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}





void CMcGrs::SetHeight()
{
	INT		iNx = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetNx();
	INT		iWx = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetWx();
	VEC3	pos = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetPos();

	INT		i, j;
	INT		iSize, jSize;
	
	iSize = m_vvBill.size();
	
	for(i=0; i<iSize; ++i)
	{
		lsMdl2D*	vMdl2D = &m_vvBill[i];

		jSize = vMdl2D->size();

		for(j=0; j<jSize; ++j)
		{
			itMdl2D pObj = vMdl2D->begin() + j;

			FLOAT	fY = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetHeight(pObj->vcP);
			pObj->vcP.y = fY;
		}
	}
}



void CMcGrs::AddGrs(INT nIdx, PDTX pTx, FLOAT fX, FLOAT fY, VEC3 vcP)
{
	INT	i;
	INT	iSize = m_vvBill.size();

	if(nIdx+1-iSize>0)
	{
		for(i=0; i<nIdx+1-iSize; ++i)
			m_vvBill.push_back(lsMdl2D());
	}

	INT nT		= nIdx;
	lsMdl2D*	vMdl2D = &m_vvBill[nT];
	CMd2D		pObj;

	vcP.y = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetHeight(vcP);

	pObj.nT		= nT;
	pObj.pTx	= pTx;
	pObj.vcP	= vcP;
	pObj.fImgX	= fX;
	pObj.fImgY	= fY;

	pObj.SetCam(GCAMGNL);
	vMdl2D->push_back(pObj);
}