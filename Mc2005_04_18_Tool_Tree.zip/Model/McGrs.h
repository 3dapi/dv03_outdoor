// Interface for the CMcGrs class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCGRS_H_
#define _MCGRS_H_


class CMcGrs
{
protected:
	llsMdl2D	m_vvBill;
	lsMdl2D		m_vBill;

public:
	CMcGrs();
	~CMcGrs();
	
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

	void	SetHeight();

	void	AddGrs(INT nIdx, PDTX pTx, FLOAT fX, FLOAT fY, VEC3 vcP);
};

#endif