// Interface for the CMpMsh class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPMSH_H_
#define _MPMSH_H_


class CMpMsh																	// Mesh
{
public:
	MATA		m_mtW;															// World Matrix
	VEC3		m_vcP;															// Position

	INT			m_iNl;															// Lighting Num
	DLGT*		m_pLg;

	DMTL		m_Mtl;															// Material

	DWORD		m_dFt;															// Fog Table Mode
	DWORD		m_dFc;															// Fog Color
	FLOAT		m_fFb;															// Fog Begin
	FLOAT		m_fFe;															// Fog End
	FLOAT		m_fFd;															// fog Density

	DWORD		m_dAb;															// Ambient color

	INT			m_iNx;															// Number of tile for Width
	INT			m_iWx;															// Width of tile for x;

	INT			m_iNi;															// Index Number
	VtxIdx*		m_pIx;

	INT			m_iNv;															// Vertex Number
	VtxNDUV1*	m_pVx;
	FLOAT		m_fUV;															// UV Width

	INT			m_iVs;															// Vertex Size
	DWORD		m_dFVF;


	INT			m_iNt;															// Texture Num
	CHAR		(*m_sNt)[128];													// 0 ��° �ؽ�ó �̸�
	PDTX*		m_pTx;

public:
	CMpMsh();
	virtual ~CMpMsh();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();


	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);

	void	SetPos(VEC3	pos)		{	m_vcP = pos	;	}
	VEC3	GetPos()				{	return m_vcP;	}
	INT		GetNx()					{	return m_iNx;	}
	INT		GetWx()					{	return m_iWx;	}

	void	SetVertex();
	void	SetNormal();
	void	SetIndex();
	void	SetMaterial(DMTL& mtrl);
	void	SetDiffuse(int nIdx=-1);
	void	SetAmLgt(DWORD dAmLgt);
	void	SetLight(DLGT* pLgt, INT iSize);
	void	SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns);
	void	SetTexture();
	

	VEC3	NormalVec(int z, int x);
	INT		FileRead(FILE* fp);
	INT		FileWrite(FILE* fp);

	FLOAT	GetHeight(VEC3& pos);
};

#endif