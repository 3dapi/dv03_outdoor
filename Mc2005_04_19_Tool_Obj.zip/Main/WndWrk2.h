// Interface for the CWndWrk2 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK2_H_
#define _WNDWRK2_H_

class CWndWrk2
{
public:
	HWND			m_hWnd		;
	TlSwpWn			m_SwpWn		;												// Swap Chain Window

public:
	CLSS_DLG_DECLEAR( CWndWrk2 );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
};

#endif