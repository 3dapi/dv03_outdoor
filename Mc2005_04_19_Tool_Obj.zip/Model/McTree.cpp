// Implementation of the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMcTree::CMcTree()
{
}


CMcTree::~CMcTree()
{
	Destroy();
}


INT CMcTree::Init()
{
	INT i=0;

	return 1;
}


void CMcTree::Destroy()
{
	for(INT i=0; i<m_vObj.size(); ++i)
		SAFE_DELETE(	m_vObj[i]	);
	
	m_vObj.clear();
}


INT CMcTree::FrameMove()
{
	INT		i;
	INT		iSize;

	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		CMd3D*	pObj = m_vObj[i];
		pObj->FrameMove();
	}

	
	sort(m_vObj.begin(), m_vObj.end(), CLnSrtGp<CMd3D* >());

	return 1;
}


void CMcTree::Render()
{
	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
		m_vObj[i]->Render();

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}





void CMcTree::SetHeight()
{
	INT		iNx = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetNx();
	INT		iWx = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetWx();
	VEC3	pos = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetPos();

	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		CMd3D*	pObj = m_vObj[i];
		VEC3	pos		= pObj->GetPos();
		FLOAT	fY = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetHeight(pos);
		pos.y = fY;

		pObj->	SetPos(pos);
	}
}



void CMcTree::AddObj(CMd3D* pObj, VEC3 vcP)
{
	vcP.y = GMAIN->m_pGmWrk1->m_pField->m_Msh.GetHeight(vcP);

	CMd3D*	pT = new CMd3D;

	pT->Copy(pObj);
	pT->SetPos(vcP);
	
	m_vObj.push_back(pT);
}