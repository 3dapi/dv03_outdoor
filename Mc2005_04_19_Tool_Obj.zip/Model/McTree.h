// Interface for the CMcTree class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCTREE_H_
#define _MCTREE_H_


class CMcTree
{
protected:
	lsMdl3D		m_vObj;

public:
	CMcTree();
	~CMcTree();
	
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

	void	SetHeight();

	void	AddObj(CMd3D* pObj, VEC3 vcP);
};

#endif