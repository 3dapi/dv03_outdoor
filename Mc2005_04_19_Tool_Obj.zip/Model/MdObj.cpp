// Implementation of the CMdObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMd2D::CMd2D()
{
	nT		= -1;
	pTx		= NULL;
	vcP		= VEC3(0,0,0);
	fR		= 0.f;
	pCam	= NULL;
	fImgX	= 0.f;
	fImgY	= 0.f;

	pVx[0] = VtxDUV1( 0, 0, 0, 0.001f, 0.001f);
	pVx[1] = VtxDUV1( 0, 0, 0, 0.999f, 0.001f);
	pVx[2] = VtxDUV1( 0, 0, 0, 0.001f, 0.999f);
	pVx[3] = VtxDUV1( 0, 0, 0, 0.999f, 0.999f);
}

INT CMd2D::FrameMove()
{
	MATA	mtB = pCam->GetMatrixViw();
	
	D3DXMatrixInverse(&mtB, 0, &mtB);
	
	VEC3 vcCam	= VEC3(mtB._41, mtB._42, mtB._43);
	VEC3 vcZ	= VEC3(mtB._31, mtB._32, mtB._33);
	
	mtB._41 = 0;
	mtB._42 = 0;
	mtB._43 = 0;
	
	FLOAT	fX;
	FLOAT	fY;
	VtxDUV1	Vtx[4];
	VEC3	vcTmp;

	
	vcTmp = vcP-vcCam;
	fR = D3DXVec3Dot(&vcZ, &vcTmp);

	SetColor( D3DXCOLOR( 1, 1, 1,  (1000.f)/fabsf(fR)  ));

	fX = fImgX;
	fY = fImgY;

	pVx[0].d = dcC;
	pVx[1].d = dcC;
	pVx[2].d = dcC;
	pVx[3].d = dcC;

	Vtx[0].p = VEC3(-fX, fY, 0);
	Vtx[1].p = VEC3( fX, fY, 0);
	Vtx[2].p = VEC3(-fX,-fY, 0);
	Vtx[3].p = VEC3( fX,-fY, 0);
	
	D3DXVec3TransformCoord(&Vtx[0].p, &Vtx[0].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[1].p, &Vtx[1].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[2].p, &Vtx[2].p, &mtB);
	D3DXVec3TransformCoord(&Vtx[3].p, &Vtx[3].p, &mtB);
	
	Vtx[0].p += vcP;
	Vtx[1].p += vcP;
	Vtx[2].p += vcP;
	Vtx[3].p += vcP;
	
	Vtx[0].p.y += fY * .9f;
	Vtx[1].p.y += fY * .9f;
	Vtx[2].p.y += fY * .9f;
	Vtx[3].p.y += fY * .9f;
	
	pVx[0].p = Vtx[0].p;
	pVx[1].p = Vtx[1].p;
	pVx[2].p = Vtx[2].p;
	pVx[3].p = Vtx[3].p;

	return 1;
}

void CMd2D::Render()
{
	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHAREF, 0x30);
	GDEVICE->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	GDEVICE->SetTexture(0, pTx);
	GDEVICE->SetFVF(VtxDUV1::FVF);
	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &pVx, sizeof(VtxDUV1));

	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
}






CMd3D::CMd3D()
: m_pTx(0),m_pIx(0), m_pVx(0), m_iNi(0), m_iNv(0)
{
}



CMd3D::~CMd3D()
{
	Destroy();
}



INT CMd3D::Init()
{
	D3DXMatrixIdentity(&mtW);

	return 1;
}


void CMd3D::Destroy()
{
	SAFE_RELEASE(	m_pTx	);
	SAFE_DELETE_ARRAY(	m_pIx	);
	SAFE_DELETE_ARRAY(	m_pVx	);
}


INT CMd3D::FrameMove()
{
	return 1;
}


void CMd3D::Render()
{
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);

	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	
	GDEVICE->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHAREF, 0x80);
	GDEVICE->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	

	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetTexture(0, m_pTx);

	GDEVICE->SetFVF(VtxNDUV1::FVF);

	GDEVICE->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, m_iNv, m_iNi
		, m_pIx, D3DFMT_INDEX16
		, m_pVx, sizeof(VtxNDUV1));

	McUtil_SetWorldIdentity();
}


INT CMd3D::SetMdl(TCHAR* sMdl)
{
	strcpy(m_sMd, sMdl);

	Destroy();

	if(FAILED(Load()))
		return -1;

	return 1;
}


INT CMd3D::Load()
{
	INT		i=0;
	TCHAR	sTmp[512];
	
	GetPrivateProfileString("Header", "iNfce", NULL, sTmp, sizeof(sTmp), m_sMd);
	m_iNi = atoi(sTmp);

	GetPrivateProfileString("Header", "iNvtx", NULL, sTmp, sizeof(sTmp), m_sMd);
	m_iNv = atoi(sTmp);


	GetPrivateProfileString("Header", "Texture", NULL, sTmp, sizeof(sTmp), m_sMd);
	strcpy(m_sTx, sTmp);

	if(0 == m_iNi || 0 == m_iNv)
		return -1;

	m_pIx = new VtxIdx[m_iNi];
	m_pVx = new VtxNDUV1[m_iNv];

	for(i=0; i<m_iNi; ++i)
	{
		int a, b, c;
		GetPrivateProfileString("Idx", McUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp), m_sMd);
		sscanf(sTmp, "%d %d %d", &a, &b, &c);

		m_pIx[i] = VtxIdx(a, b,c );
	}

	for(i=0; i<m_iNv; ++i)
	{
		VtxNDUV1	tVtx;
		GetPrivateProfileString("Vtx", McUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp), m_sMd);

		sscanf(sTmp, "%f %f %f   %f %f %f  %f %f %x"
			, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
			, &tVtx.n.x, &tVtx.n.y, &tVtx.n.z
			, &tVtx.u0, &tVtx.v0
			, &tVtx.d
			);

		tVtx.p *= 0.35f;
		m_pVx[i] = tVtx;
	}

	McUtil_TextureLoad(McUtil_Forming("Model/%s", m_sTx), m_pTx, 0x00385C20);

	return 1;
}



INT CMd3D::Copy(CMd3D*	pRhs)
{
	this->nI1 = pRhs->GetId1();
	this->nI2 = pRhs->GetId2();
	this->nI3 = pRhs->GetId3();

	this->m_iNi = pRhs->m_iNi;
	this->m_iNv = pRhs->m_iNv;
	
	strcpy(m_sMd, pRhs->GetMdlName());
	strcpy(m_sTx, pRhs->GetMdlTx());

	m_pIx = new VtxIdx[m_iNi];
	m_pVx = new VtxNDUV1[m_iNv];

	memcpy(m_pIx, pRhs->m_pIx, m_iNi * sizeof(VtxIdx));
	memcpy(m_pVx, pRhs->m_pVx, m_iNv * sizeof(VtxNDUV1));

	McUtil_TextureLoad(McUtil_Forming("Model/%s", m_sTx), m_pTx, 0x00385C20);

	this->SetCam(GCAMGNL);

	return 1;
}