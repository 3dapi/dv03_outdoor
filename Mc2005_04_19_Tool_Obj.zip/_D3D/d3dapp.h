// Interface for the CD3DApplication class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _D3DAPP_H_
#define _D3DAPP_H_

// Error codes
enum APPMSGTYPE { MSG_NONE, MSGERR_APPMUSTEXIT, MSGWARN_SWITCHEDTOREF };

#define D3DAPPERR_NODIRECT3D          0x82000001
#define D3DAPPERR_NOWINDOW            0x82000002
#define D3DAPPERR_NOCOMPATIBLEDEVICES 0x82000003
#define D3DAPPERR_NOWINDOWABLEDEVICES 0x82000004
#define D3DAPPERR_NOHARDWAREDEVICE    0x82000005
#define D3DAPPERR_HALNOTCOMPATIBLE    0x82000006
#define D3DAPPERR_NOWINDOWEDHAL       0x82000007
#define D3DAPPERR_NODESKTOPHAL        0x82000008
#define D3DAPPERR_NOHALTHISMODE       0x82000009
#define D3DAPPERR_NONZEROREFCOUNT     0x8200000a
#define D3DAPPERR_MEDIANOTFOUND       0x8200000b
#define D3DAPPERR_RESETFAILED         0x8200000c
#define D3DAPPERR_NULLREFDEVICE       0x8200000d



class CD3DApplication
{
public:
	CD3DEnum		m_d3dEnumeration;
	CD3DBundle		m_d3dSettings;


	// Internal variables for the state of the app
	bool			m_bWindowed;
	bool			m_bActive;

protected:
	bool			m_bDeviceLost;
	bool			m_bMinimized;
	bool			m_bMaximized;
	bool			m_bIgnoreSizeChange;
	bool			m_bDeviceObjectsInited;
	bool			m_bDeviceObjectsRestored;
	
	// Internal variables used for timing
	bool			m_bFrameMoving;
	bool			m_bSingleStep;
	
	// Internal error handling function
	HRESULT			DisplayErrorMsg(HRESULT, DWORD);
	
	// Internal functions to manage and render the 3D scene
	static bool		ConfirmDeviceHelper( D3DCAPS9*, VertexProcessingType,D3DFORMAT);
	void			BuildPresentParamsFromSettings();
	bool			FindBestWindowedMode(bool, bool);
	bool			FindBestFullscreenMode(bool, bool);
	HRESULT			ChooseInitialD3DSettings();
	HRESULT			Initialize3DEnvironment();
	HRESULT			HandlePossibleSizeChange();
	HRESULT			Reset3DEnvironment();
	HRESULT			ToggleFullscreen();
	HRESULT			ForceWindowed();
	void			Cleanup3DEnvironment();
	HRESULT			Render3DEnvironment();
	virtual HRESULT	AdjustWindowForChange();
	virtual void	UpdateStats();
	
public:
	// Main objects used for creating and rendering the 3D scene
	HINSTANCE				m_hInst;
	HWND					m_hWnd;												// The main app window
	HWND					m_hWndFocus;										// The D3D focus window (usually same as m_hWnd)
	HDC						m_hDC;												// Backbuffer DC
	HMENU					m_hMenu;											// App menu bar (stored here when fullscreen)
	LPDIRECT3D9				m_pD3D;												// The main D3D object
	LPDIRECT3DDEVICE9		m_pd3dDevice;										// The D3D rendering device
	LPDIRECT3DSURFACE9		m_pBackBuffer;										// Backbuffer point
	LPD3DXSPRITE			m_pd3dSprite;										// 2D Sprite
	DWORD					m_dwClr;											// Clear Mode
	DWORD					m_dwFl;												// Fill mode

	BOOL					m_bLoadingRnd;										// TRUE, if the Loading Scene Rendering

protected:	
	D3DPRESENT_PARAMETERS	m_d3dpp;											// Parameters for CreateDevice/Reset
	D3DCAPS9				m_d3dCaps;											// Caps for the device
	D3DSURFACE_DESC			m_d3dsdBackBuffer;									// Surface desc of the backbuffer

	DWORD					m_dwCreateFlags;									// Indicate sw or hw vertex processing
	DWORD					m_dwWindowStyle;									// Saved window style for mode switches
	RECT					m_rcWindowBounds;									// Saved window bounds for mode switches
	RECT					m_rcWindowClient;									// Saved client area size for mode switches
	BOOL					m_bLoadingApp;										// TRUE, if the app is loading
	

	// Variables for timing
	FLOAT					m_fTime;											// Current time in seconds
	FLOAT					m_fElapsedTime;										// Time elapsed since last frame
	FLOAT					m_fFPS;												// Instanteous frame rate
	TCHAR					m_strDeviceStats[90];								// String to hold D3D device stats
	TCHAR					m_strFrameStats[90];								// String to hold frame stats
	
	// Overridable variables for the app
	TCHAR*					m_strWindowTitle;									// Title for the app's window
	DWORD					m_dwCreationW;										// Width used to create window
	DWORD					m_dwCreationH;										// Height used to create window
	bool					m_bShowCursorWhenFullscreen;						// Whether to show cursor when fullscreen
	bool					m_bClipCursorWhenFullscreen;						// Whether to limit cursor pos when fullscreen
	bool					m_bStartFullscreen;									// Whether to start up the app in fullscreen mode

protected:
	// Overridable functions for the 3D scene created by the app
	virtual HRESULT			ConfirmDevice(D3DCAPS9*,DWORD,D3DFORMAT);
	virtual HRESULT			OneTimeSceneInit();
	virtual HRESULT			Init()							{ return S_OK; }
	virtual HRESULT			Restore()						{ return S_OK; }
	virtual HRESULT			FrameMove()						{ return S_OK; }
	virtual HRESULT			Render()						{ return S_OK; }
	virtual HRESULT			Invalidate()					{ return S_OK; }
	virtual HRESULT			Destroy()						{ return S_OK; }
	virtual HRESULT			FinalCleanup();

public:
	CD3DApplication();
	virtual HRESULT			Create(HINSTANCE);
	virtual INT				Run();
	virtual void			Pause(bool);
	virtual LRESULT			MsgProc(HWND,UINT,WPARAM,LPARAM);

	bool					IsActive()		{ return m_bActive;	}

	static LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

public:
	UINT					GetBackW()	{	return m_d3dsdBackBuffer.Width;	}
	UINT					GetBackH()	{	return m_d3dsdBackBuffer.Height;}
	D3DFORMAT				GetBackF()	{	return m_d3dsdBackBuffer.Format;}
};

#endif