// Interface for the CGmWrk2 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GMWRK2_H_
#define _GMWRK2_H_


class CGmWrk2
{
protected:
	VEC2*				m_pLine	;
	FLOAT				m_fW	;
	INT					m_icX	;
	INT					m_icY	;
	LPD3DXLINE			m_pDxL	;

	TlWnRc				m_rtWnd[2];

public:
	CGmWrk2();
	virtual ~CGmWrk2();

	INT		Init();
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();
	void	RenderS();
};

#endif