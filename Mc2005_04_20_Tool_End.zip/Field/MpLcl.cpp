// Implementation of the CMpLcl class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"



CMpLcl::CMpLcl()
{
	D3DXMatrixIdentity(&m_mtW);
	
	m_iNx	= 0;																// Number of tile for Width
	m_iWx	= 0;																// Width of tile for x;
	
	m_iNi	= 0;																// Index Number
	m_pIx	= 0;
	
	m_iNv	= 0;																// Vertex Number
	m_pVc	= 0;
	
	m_iVs	= 0;																// Vertex Size
	m_FVF	= 0;
	
	m_vcP.x = 0;
	m_vcP.y = 0;
	m_vcP.z = 0;

	m_pMdb2D= NULL;
	m_pMdb3D= NULL;

	m_pDev	= NULL;
}



CMpLcl::~CMpLcl()
{
	Destroy();
}



void CMpLcl::Destroy()
{
	D3DXMatrixIdentity(&m_mtW);
	
	m_iNx	= 0;
	m_iWx	= 0;
	m_iNi	= 0;
	m_iNv	= 0;
	m_fUV	= 1.f;
	m_iVs	= 0;
	m_FVF	= 0;
	
	SAFE_DELETE_ARRAY(	m_pIx	);
	SAFE_DELETE_ARRAY(	m_pVc	);

	SAFE_DELETE_ARRAY(	m_pTxI	);
	m_vTxN.clear();
	SAFE_DEL_LST(	m_vTxL	);

	SAFE_DELETE(	m_pMdb2D	);
	SAFE_DELETE(	m_pMdb3D	);
}



INT CMpLcl::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	SAFE_NEWCREATE1(	m_pMdb2D,	CMdPack2D, m_pDev);
	m_pMdb2D->SetLcl(this);

	SAFE_NEWCREATE1(	m_pMdb3D,	CMdPack3D, m_pDev);
	m_pMdb3D->SetLcl(this);

	return 1;
}


INT CMpLcl::FrameMove()
{
	SAFE_FRMOV(	m_pMdb2D	);
	SAFE_FRMOV(	m_pMdb3D	);

	return 1;
}


void CMpLcl::RenderLcl()
{
	INT z, x;

	if(!m_pVc)
		return;

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,	D3DTOP_MODULATE);
	
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP,	D3DTOP_SELECTARG1);
	
	m_pDev->SetFVF(m_FVF);

	for(INT i=0; i<m_vTxL.size();++i)
	{
		MpTlTx*	pMcTd = m_vTxL[i];
		PDTX	pTx = pMcTd->pTx;

		m_pDev->SetTexture(0, pTx);
		
		for(z=0; z<m_iNx; ++z)
		{
			for(x=0; x<m_iNx; ++x)
			{
				DWORD	argb1 = m_pVc[z*m_iNx+x].d;
				DWORD	argb2 = DWORD(pMcTd->pTw[z*m_iNx+x]);

				argb1 <<=8;
				argb1 >>=8;
				
				argb1 = argb1 | (argb2<<24);
				m_pVc[z*m_iNx+x].d = argb1;
			}
		}
		
		m_pDev->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST
			, 0
			, m_iNv
			, m_iNi
			, m_pIx
			, D3DFMT_INDEX16
			, m_pVc
			, m_iVs);
	}
	
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG1,	D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLORARG2,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_COLOROP,	D3DTOP_MODULATE);
	
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG1,	D3DTA_TEXTURE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAARG2,	D3DTA_DIFFUSE);
	m_pDev->SetTextureStageState(0, D3DTSS_ALPHAOP,	D3DTOP_MODULATE);

	LnUtil_SetWorldIdentity(m_pDev);
}


void CMpLcl::RenderObj()
{
	SAFE_RENDER(	m_pMdb3D		);
	SAFE_RENDER(	m_pMdb2D		);
}



void CMpLcl::RenderTline()
{
	VtxD	pLine[5];

	FLOAT	fW	= (m_iNx-1) * m_iWx-4.f;
	FLOAT	Px	= m_vcP.x;
	FLOAT	Py	= m_vcP.y+10;
	FLOAT	Pz	= m_vcP.z;

	pLine[0] = VtxD(Px+ 0, Py, Pz+ 0, 0xFFFFFF00);
	pLine[1] = VtxD(Px+ 0, Py, Pz+fW, 0xFFFFFF00);
	pLine[2] = VtxD(Px+fW, Py, Pz+fW, 0xFFFFFF00);
	pLine[3] = VtxD(Px+fW, Py, Pz+ 0, 0xFFFFFF00);
	pLine[4] = pLine[0];

	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetTexture(0,0);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINESTRIP, 4, pLine, sizeof(VtxD));

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}



void CMpLcl::CreateMesh(INT iNx, INT iWx, FLOAT fUV)
{
	INT		z, x;

	m_iWx	= 128;
	m_FVF	= VtxNDUV1::FVF;
	m_iVs	= sizeof(VtxNDUV1);
	m_fUV	= fUV;


	m_iNx	= iNx;
	m_iWx	= iWx;
	m_fUV	= fUV;
	m_iNv	= m_iNx * m_iNx;
	m_pVc	= new VtxNDUV1[m_iNv];

	for(z=0; z<m_iNx; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			m_pVc[z * m_iNx + x].p = VEC3(FLOAT(x * m_iWx), 0.f, FLOAT(z * m_iWx));
			
			m_pVc[z * m_iNx + x].p += m_vcP;

			m_pVc[z * m_iNx + x].d =0xFFFFFFFF;
			m_pVc[z * m_iNx + x].u = x /m_fUV;
			m_pVc[z * m_iNx + x].v = z /m_fUV;
		}
	}

	SetNormal();
	SetIndex();

	m_pTxI = new BYTE[m_iNv];

	memset(m_pTxI, 0, m_iNv * sizeof(BYTE));
}






void CMpLcl::LyrAdd(char* sTx)
{
	INT iSize = m_vTxN.size();

	for(int i=0; i<iSize; ++i)
	{
		if(0 ==m_vTxN[i].compare(sTx))
			return;
	}

	m_vTxN.push_back(sTx);



	MpTlTx*	pTd = new MpTlTx;
	BYTE*	pTw = new BYTE[m_iNv];

	if(0 == iSize)
		memset(pTw, 0xFF, m_iNv * sizeof(BYTE));
	else
		memset(pTw, 0x0, m_iNv * sizeof(BYTE));

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	sTx);
	pTd->pTx = TBTX->SelectTx(nM, nS);
	pTd->pTw = pTw;

	m_vTxL.push_back(pTd);
}





void CMpLcl::SetDiffuse(int nIdx)
{
	INT		x,z;

	if(-1 == nIdx)
	{
		for(z=0; z<m_iNx; ++z)
		{
			for(x=0; x<m_iNx; ++x)
			{
				FLOAT fH = m_pVc[z * m_iNx + x].p.y;
				DWORD c;
			
				if( (fH) < -100.f )
					c = D3DCOLOR_XRGB(128, 120, 70);
				else if( (fH) < 100.f )
					c = D3DCOLOR_XRGB(255, 249, 157);
				else if( (fH) < 500.0f )
					c = D3DCOLOR_XRGB(124, 197, 118);
				else if( (fH) <2000.5f )
					c = D3DCOLOR_XRGB(  0, 166,  81);
				else if( (fH) < 3000.0f )
					c = D3DCOLOR_XRGB( 25, 123,  48);
				else if( (fH) < 4000.5f )
					c = D3DCOLOR_XRGB(115, 100,  87);
				else
					c = D3DCOLOR_XRGB(255, 255, 255);
				
				m_pVc[z * m_iNx + x].d = c;
			}
		}
	}

	else
	{
		FLOAT fH = m_pVc[nIdx].p.y;
		DWORD c;
	
		if( (fH) < -100.f )
			c = D3DCOLOR_XRGB(128, 120, 70);
		else if( (fH) < 100.f )
			c = D3DCOLOR_XRGB(255, 249, 157);
		else if( (fH) < 500.0f )
			c = D3DCOLOR_XRGB(124, 197, 118);
		else if( (fH) <2000.5f )
			c = D3DCOLOR_XRGB(  0, 166,  81);
		else if( (fH) < 3000.0f )
			c = D3DCOLOR_XRGB( 25, 123,  48);
		else if( (fH) < 4000.5f )
			c = D3DCOLOR_XRGB(115, 100,  87);
		else
			c = D3DCOLOR_XRGB(255, 255, 255);
		
		m_pVc[nIdx].d = c;
	}
}

void CMpLcl::SetIndex()
{
	INT		x, z;
	INT		iN;
	
	
	iN = m_iNx-1;
	
	m_iNi = 2 * (m_iNx-1) * (m_iNx-1);
	
	m_pIx = new VtxIdx[m_iNi];
	
	INT i=0;
	
	WORD index;
	WORD f[9];
	
	for(z=0; z< iN/2;++z)														// Index�� ä���.
	{
		for(x=0;x<iN/2;++x)
		{
			index = 2*m_iNx*z + m_iNx+1 + 2*x;
			
			f[6] = index +m_iNx-1;	f[5] = index + m_iNx;	f[4] = index +m_iNx	+1;
			f[7] = index	   -1;	f[8] = index		;	f[3] = index		+1;
			f[0] = index -m_iNx-1;	f[1] = index - m_iNx;	f[2] = index -m_iNx	+1;
			
			
			i = z * iN/2 + x;
			i *=8;
			
			for(int m=0; m<8; ++m)
				m_pIx[i+m] = VtxIdx( f[8], f[(m+1)%8], f[(m+0)%8]);
		}
	}
}


void CMpLcl::SetNormal()
{
	INT		x,z;
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	
	for(z=0; z<m_iNx; ++z)
	{
		for(x=0; x<m_iNx; ++x)
		{
			m_pVc[m_iNx*z + x].n = -NormalVec(z, x);
		}
	}
}






VEC3 CMpLcl::NormalVec(int z, int x)
{
	VEC3	n(0,0,0);
	VEC3	a;
	VEC3	b;
	VEC3	nT;
	INT		i;

	INT		index = m_iNx*z + x;
	INT		iVtx[10];

	iVtx[9] = index;
	iVtx[0] = iVtx[9];
	iVtx[1] = iVtx[9];
	iVtx[2] = iVtx[9];
	iVtx[3] = iVtx[9];
	iVtx[4] = iVtx[9];
	iVtx[5] = iVtx[9];
	iVtx[6] = iVtx[9];
	iVtx[7] = iVtx[9];
	iVtx[8] = iVtx[9];
	
	if(0==z && 0==x)
	{
		iVtx[0] = iVtx[9] + 1;
		iVtx[1] = iVtx[0] + m_iNx;
		iVtx[2] = iVtx[9] + m_iNx;
	}

	else if(0==z && (m_iNx-1) == x)
	{
		iVtx[0] = iVtx[9] + m_iNx;
		iVtx[1] = iVtx[0] - 1;
		iVtx[2] = iVtx[9] - 1;
	}

	else if(0==z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iNx;
			iVtx[2] = iVtx[9] - 1;			
		}
		else
		{
			iVtx[0] = iVtx[9] + 1;
			iVtx[1] = iVtx[0] + m_iNx;
			iVtx[2] = iVtx[9] + m_iNx;
			iVtx[3] = iVtx[2] - 1;
			iVtx[4] = iVtx[9] - 1;
		}
	}
	
	else if( (m_iNx-1) == z && 0==x)
	{
		iVtx[0] = iVtx[9] - m_iNx;
		iVtx[1] = iVtx[0] + 1;
		iVtx[2] = iVtx[9] + 1;
	}

	else if( (m_iNx-1) == z && (m_iNx-1) == x)
	{
		iVtx[0] = iVtx[9] - 1;
		iVtx[1] = iVtx[0] - m_iNx;
		iVtx[2] = iVtx[9] - m_iNx;

	}

	else if((m_iNx-1) == z)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iNx;
			iVtx[2] = iVtx[9] + 1;
		}
		else
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[0] - m_iNx;
			iVtx[2] = iVtx[9] - m_iNx;
			iVtx[3] = iVtx[2] + 1;
			iVtx[4] = iVtx[9] + 1;
		}
	}

	else if(0 == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] - m_iNx;
			iVtx[1] = iVtx[9] + 1;
			iVtx[2] = iVtx[9] + m_iNx;
		}
		else
		{
			iVtx[0] = iVtx[9] - m_iNx;
			iVtx[1] = iVtx[0] + 1;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[2] + m_iNx;
			iVtx[4] = iVtx[9] + m_iNx;
		}
	}

	else if((m_iNx-1) == x)
	{
		if(index%2)
		{
			iVtx[0] = iVtx[9] + m_iNx;
			iVtx[1] = iVtx[9] - 1;
			iVtx[2] = iVtx[9] - m_iNx;
		}
		else
		{
			iVtx[0] = iVtx[9] + m_iNx;
			iVtx[1] = iVtx[0] - 1;
			iVtx[2] = iVtx[9] - 1;
			iVtx[3] = iVtx[2] - m_iNx;
			iVtx[4] = iVtx[9] - m_iNx;
		}
	}
	

	else
	{
		if(index%2)																// Ȧ ��
		{
			iVtx[0] = iVtx[9] - 1;
			iVtx[1] = iVtx[9] - m_iNx;
			iVtx[2] = iVtx[9] + 1;
			iVtx[3] = iVtx[9] + m_iNx;
			iVtx[4] = iVtx[0];
		}
		else																	// ¦ ��
		{
			iVtx[6] = index +m_iNx	-1;		iVtx[5] = iVtx[6] + 1;	iVtx[4] = iVtx[5] + 1;
			iVtx[7] = index			-1;		iVtx[9] = iVtx[7] + 1;	iVtx[3] = iVtx[9] + 1;
			iVtx[0] = index -m_iNx	-1;		iVtx[1] = iVtx[0] + 1;	iVtx[2] = iVtx[1] + 1;
			iVtx[8] = iVtx[0];
		}
	}

	for(i=0; i<8; ++i)
	{
		a = m_pVc[iVtx[i+0] ].p - m_pVc[iVtx[9] ].p;
		b = m_pVc[iVtx[i+1] ].p - m_pVc[iVtx[9] ].p;
		D3DXVec3Cross(&nT, &a, &b);
		D3DXVec3Normalize(&nT, &nT);
		n +=nT;
	}

	
	D3DXVec3Normalize(&n, &n);
	
	return n;
}



FLOAT CMpLcl::GetHeight(VEC3& pos)
{
	INT	x;
	INT	z;

	z = INT((-m_vcP.z + pos.z)/ m_iWx);
	x = INT((-m_vcP.x + pos.x)/ m_iWx);

	
	INT index = m_iNx*z + x;

	VEC3 pos0 = m_pVc[index].p;
	VEC3 posX;
	VEC3 posZ;
	VEC3 posT;


	float dX = pos.x - pos0.x;
	float dZ = pos.z - pos0.z;

	if( (x+z)%2)			// Ȧ��
	{
		if(dZ >(m_iWx-dX))			// ���� �ﰢ��
		{
			index += (m_iNx+1);

			pos0 = m_pVc[index].p;
			posX = m_pVc[index-1].p;
			posZ = m_pVc[index-m_iNx].p;
		}

		else
		{
			pos0 = m_pVc[index].p;
			posX = m_pVc[index+1].p;
			posZ = m_pVc[index+m_iNx].p;
		}
	}
	else					// ¦��
	{
		if(dZ > dX)			// ���� �ﰢ��
		{
			index += (m_iNx);

			pos0 = m_pVc[index].p;
			posX = m_pVc[index+1].p;
			posZ = m_pVc[index-m_iNx].p;
		}

		else
		{
			index += 1;

			pos0 = m_pVc[index].p;
			posX = m_pVc[index-1].p;
			posZ = m_pVc[index+m_iNx].p;
		}
	}

	dX = fabsf(pos.x - pos0.x);
	dZ = fabsf(pos.z - pos0.z);

	posT  = pos0 + (posX - pos0) * dX/m_iWx + (posZ - pos0) * dZ/m_iWx;


	return posT.y;
}









////////////////////////////////////////////////////////////////////////////////
void CMpLcl::SetTileIdx()
{
	INT i;

	int iSize = m_vTxL.size();
	
	for(i=0; i<iSize; ++i)
	{
		SetTiling(i, m_vTxL[i]->pTw);
	}
}

void CMpLcl::SetTiling(int nTx, BYTE* &xpTxA)
{
	INT		x, z, m, n;
	INT		nXBgn, nXEnd;
	INT		nZBgn, nZEnd;

	INT		nIdx;

	FLOAT	fAlpha;
	FLOAT	fN;
		
	for (z=0; z<m_iNx; ++z)
	{
		for (x=0; x<m_iNx; ++x)
		{
			fAlpha = 0.0f;
			
			if(z==0)
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= 0;	nZEnd	= 1;
				}
				
				else if(x==(m_iNx-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= 0;	nZEnd	= 1;
				}
				
				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= 0;	nZEnd	= 1;
				}
			}
			
			else if(z==(m_iNx-1))
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 0;
				}
				
				else if(x==(m_iNx-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= -1;	nZEnd	= 0;
				}
				
				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 0;
				}
			}
			
			else
			{
				if(x==0)
				{
					nXBgn	= 0;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 1;
				}
				
				else if(x==(m_iNx-1))
				{
					nXBgn	= -1;	nXEnd	= 0;
					nZBgn	= -1;	nZEnd	= 1;
				}
				
				else
				{
					nXBgn	= -1;	nXEnd	= 1;
					nZBgn	= -1;	nZEnd	= 1;
				}
			}
			
			for(m=nZBgn; m<=nZEnd; ++m)
			{
				for(n=nXBgn; n<=nXEnd; ++n)
				{
					nIdx = (z+m)*m_iNx + x+n;

					if(m_pTxI[nIdx] ==nTx)
						fAlpha +=1.f;
				}
			}

			fN = (abs(nXEnd-nXBgn +1) * abs(nZEnd-nZBgn +1));

			fAlpha *=6.f;
			fAlpha /= fN;

			if(fAlpha>1.f)
				fAlpha = 1.f;



			xpTxA[m_iNx*z + x] = BYTE(255 * fAlpha);
		}// for
	}// for



}