// Implementation of the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#define DIRECTINPUT_VERSION		0x0800
#include <dinput.h>

#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"

#include "LnUtil.h"														// Util
#include "LnInput.h"


CLnInput::CLnInput()
{
	m_hInst		= NULL;
	m_hWnd		= NULL;
	m_pDev		= NULL;

	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMs		= NULL;
}

CLnInput::~CLnInput()
{
	SAFE_RELEASE(	m_pDiKey	);
	SAFE_RELEASE(	m_pDiMs		);
	SAFE_RELEASE(	m_pDInput	);
}


INT CLnInput::Create(void* p1)
{
	D3DDEVICE_CREATION_PARAMETERS d3Parameter;

	m_hInst = (HINSTANCE) GetModuleHandle(NULL);
	m_pDev = (PDEV)p1;

	m_pDev->GetCreationParameters(&d3Parameter);
	m_hWnd = d3Parameter.hFocusWindow;


	memset(KeyCur, 0, sizeof(KeyCur));
	memset(KeyOld, 0, sizeof(KeyOld));

	memset(&vcMsCur, 0, sizeof(vcMsCur));
	memset(&vcMsOld, 0, sizeof(vcMsOld));
	memset(&MsStCur, 0, sizeof(MsStCur));
	memset(&MsStOld, 0, sizeof(MsStOld));

	InitDInput();
	
	return 1;
}

INT CLnInput::FrameMove()
{
	vcDelta = vcMsCur - vcMsOld;

	memcpy(KeyOld		, KeyCur	, sizeof(KeyCur		));
	memcpy(&vcMsOld		, &vcMsCur	, sizeof(vcMsCur	));
	memcpy(&MsStOld		, &MsStCur	, sizeof(MsStCur	));

	memset(&MsStCur, 0  , sizeof(MsStCur));

	UpdateDInput();
	
	return 1;
}




BOOL CLnInput::IsInRect(LnRc& rt)
{
	return (	vcMsCur.x>rt.m[0]
			&&	vcMsCur.y>rt.m[1]
			&&	vcMsCur.x<rt.m[2]
			&&	vcMsCur.y<rt.m[3]);
}



BOOL CLnInput::GetKey(BYTE cKey)
{
	return (KeyCur[cKey] & 0x80 && KeyOld[cKey] != KeyCur[cKey]);
}

BOOL CLnInput::KeyState(BYTE cKey)
{
	return (KeyCur[cKey] & 0x80 && TRUE);
}

BOOL CLnInput::GetMouseSt(INT nM)
{
	return MsStOld.rgbButtons[nM]? TRUE: FALSE;
}

VEC3 CLnInput::GetMousePos()
{
	return vcMsCur;
}


BOOL CLnInput::ButtonDn(INT nM)
{
	return ( MsStOld.rgbButtons[nM] == 0 && MsStCur.rgbButtons[nM] != 0)? TRUE: FALSE;
}

BOOL CLnInput::ButtonUp(INT nM)
{
	return ( MsStOld.rgbButtons[nM] != 0 && MsStCur.rgbButtons[nM] == 0)? TRUE: FALSE;
}

BOOL CLnInput::ButtonSt(INT nM)
{
	return ( MsStOld.rgbButtons[nM] != 0 && MsStCur.rgbButtons[nM] != 0)? TRUE: FALSE;
}


VEC3 CLnInput::GetMouseDelta()
{
	return vcDelta;
}

INT CLnInput::InitDInput()
{
	DWORD		flags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY;

	// Mouse
	if (FAILED(DirectInput8Create(	m_hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMs, NULL)))
		return -1;
	
	if (FAILED(m_pDiMs->SetDataFormat(&c_dfDIMouse)))
		return -1;
	
	if (FAILED(m_pDiMs->SetCooperativeLevel(m_hWnd, flags)))
		return -1;

	// Keyboard
	if (FAILED(DirectInput8Create(	m_hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
		return -1;
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		return -1;
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		return -1;
	
	return 1;
}


INT CLnInput::UpdateDInput()
{
	// Keyboard
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
	{
		memset(KeyCur, 0, sizeof(KeyCur));
		
		if (FAILED(m_pDiKey->Acquire()))
			return -1;
		
		if (FAILED(m_pDiKey->GetDeviceState(sizeof(KeyCur), (LPVOID)KeyCur)))
			return -1;
	}



	// Mouse
	if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
	{
		if (FAILED(m_pDiMs->Acquire()))
			return -1;
		
		if (FAILED(m_pDiMs->GetDeviceState(sizeof(DIMOUSESTATE), &MsStCur)))
			return -1;
	}

	POINT	MsPos;
	GetCursorPos(&MsPos);
	::ScreenToClient(m_hWnd, &MsPos);

	m_pDev->SetCursorPosition( MsPos.x, MsPos.y, 0 );

	vcMsCur.x = FLOAT(MsPos.x);
	vcMsCur.y = FLOAT(MsPos.y);

	vcMsCur.z += FLOAT(MsStCur.lZ);
	
	return 1;
}