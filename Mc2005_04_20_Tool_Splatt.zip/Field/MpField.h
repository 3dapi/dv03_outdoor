// Interface for the CMpField class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPFIELD_H_
#define _MPFIELD_H_

class CMpField
{
public:
	CMpInf		m_Inf	;
	CMpLcl		m_Msh	;

	CMcGrs*		m_pGrs	;

	CMcWood*	m_pTree	;

	lsTlPkT		m_vPk	;
	bool		m_bClick;
	VEC3		m_vcPck	;

public:
	CMpField();
	~CMpField();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		CreateBlc(INT iNx, INT iWx, FLOAT fUV, VEC3 pos);
	void	SetMaterial(DMTL& _mtl);
	void	SetAmbientLight(DWORD& _dAmL);
	void	SetLight(DLGT* pLgt, INT nCnt);
	void	SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns);
	
protected:
	INT		MapLoad();
	INT		MapSave();
};

#endif