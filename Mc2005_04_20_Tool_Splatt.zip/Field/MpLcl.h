// Interface for the CMpLcl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPLCL_H_
#define _MPLCL_H_


class CMpLcl																	// Mesh
{
protected:
	struct McTd
	{
		PDTX	pTx;																// Texture
		BYTE*	pTw;																// Layer Weight constructed by Alpha

		McTd() : pTx(0), pTw(0)
		{
		}

		void	Destroy()
		{
			SAFE_RELEASE(	pTx	);
			SAFE_FREE(	pTw	);
		}

		~McTd()
		{
			Destroy();	
		}
	};

	typedef std::vector<McTd* >		lsMcTd;
	typedef lsMcTd::iterator		itMcTd;

public:
	MATA		m_mtW;															// World Matrix
	VEC3		m_vcP;															// Position

	INT			m_iNl;															// Lighting Num
	DLGT*		m_pLg;

	DMTL		m_Mtl;															// Material

	DWORD		m_dFt;															// Fog Table Mode
	DWORD		m_dFc;															// Fog Color
	FLOAT		m_fFb;															// Fog Begin
	FLOAT		m_fFe;															// Fog End
	FLOAT		m_fFd;															// fog Density

	DWORD		m_dAb;															// Ambient color

	INT			m_iNx;															// Number of tile for Width
	INT			m_iWx;															// Width of tile for x;

	INT			m_iNi;															// Index Number
	VtxIdx*		m_pIx;

	INT			m_iNv;															// Vertex Number
	VtxNDUV1*	m_pVx;
	FLOAT		m_fUV;															// UV Width

	INT			m_iVs;															// Vertex Size
	DWORD		m_dFVF;

	lsStr		m_vTxN;
	lsMcTd		m_vTxL;

	BYTE*		m_pIdxL;

public:
	CMpLcl();
	virtual ~CMpLcl();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();


	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);

	void	SetPos(VEC3	pos)		{	m_vcP = pos	;	}
	VEC3	GetPos()				{	return m_vcP;	}
	INT		GetNx()					{	return m_iNx;	}
	INT		GetWx()					{	return m_iWx;	}

	void	SetVertex();
	void	SetNormal();
	void	SetIndex();
	void	SetMaterial(DMTL& mtrl);
	void	SetDiffuse(int nIdx=-1);
	void	SetAmLgt(DWORD dAmLgt);
	void	SetLight(DLGT* pLgt, INT iSize);
	void	SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns);
	
	void	LyrAdd(TCHAR* sTx);
	

	VEC3	NormalVec(int z, int x);

	FLOAT	GetHeight(VEC3& pos);

public:
	void	CalculateMap();
	void	CalculateMapTile(int nTx, BYTE* &xpTxA);
};

#endif