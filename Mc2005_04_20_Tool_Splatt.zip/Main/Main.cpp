// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	m_ePhCur		= GP_WRK1;
	m_ePhOld		= GP_WRK2;

	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCamG			= NULL;
	m_pCamO			= NULL;

	m_pGmWrk1		= NULL;
	m_pGmWrk2		= NULL;

	OnFrm[GP_WRK1] = &CMain::OnFrmWrk1	;
	OnRnd[GP_WRK1] = &CMain::OnRndWrk1	;
	OnRns[GP_WRK1] = &CMain::OnRnsWrk1	;
	OnFrm[GP_WRK2] = &CMain::OnFrmWrk2	;
	OnRnd[GP_WRK2] = &CMain::OnRndWrk2	;
	OnRns[GP_WRK2] = &CMain::OnRnsWrk2	;


	m_bLgt			= 0;
	m_bFog			= 0;
	m_bFill			= D3DFILL_SOLID;

	m_fAl = 45;
	m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
}



HRESULT CMain::Init()
{
	SAFE_NEWINIT(	m_pInput	,	CMcInput	);
	SAFE_NEWINIT(	m_pCamG		,	CMcCam		);
	SAFE_NEWINIT(	m_pCamO		,	CMcCam		);
	SAFE_NEWINIT(	m_pGmWrk1	,	CGmWrk1		);
	SAFE_NEWINIT(	m_pGmWrk2	,	CGmWrk2		);


	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;

	m_Wrk.Create(m_hWnd);
	SetFocus(GHWND);


	memset(&m_pLg, 0, sizeof(m_pLg) );

	m_pLg.Type = D3DLIGHT_DIRECTIONAL;
	m_pLg.Diffuse = D3DXCOLOR( .6F, .6F, .6F, 1.F);

	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamG		);
	SAFE_DELETE(	m_pCamO		);

	SAFE_DELETE(	m_pGmWrk1	);
	SAFE_DELETE(	m_pGmWrk2	);

	SAFE_DESTROY(	&m_Wrk		);

	return S_OK;
}


HRESULT CMain::Restore()
{
	GDEVICE->GetViewport(&m_Vp);

	if(m_bWindowed)
	{
		GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);
		GDEVICE->GetDepthStencilSurface(&m_SwpWn.pS);
	}

	SAFE_RESTORE(	&m_Wrk		);

	SAFE_RESTORE(	m_pGmWrk1	);
	SAFE_RESTORE(	m_pGmWrk2	);

	m_pD3DXFont->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();

	SAFE_INVALID(	&m_Wrk		);
	
	SAFE_INVALID(	m_pGmWrk1	);
	SAFE_INVALID(	m_pGmWrk2	);

	m_SwpWn.Release();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	SAFE_FRMOV(	m_pInput	);													// Update Input
	SAFE_FRMOV(	m_pCamG		);

	if(FAILED((this->*OnFrm[m_ePhCur])()))
		return -1;



	if( GINPUT->KeyState(DIK_F11))
	{
		++m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}
	
	if( GINPUT->KeyState(DIK_F12))
	{
		--m_fAl;
		m_vcLgt = VEC3( -cosf(D3DXToRadian(m_fAl)), -sinf(D3DXToRadian(m_fAl)), 0);
	}




	m_ePhOld = m_ePhCur;

	SAFE_FRMOV(&m_Wrk	);
	
	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 1;
	
	if(!GDEVICE)
		return -1;

	if(m_ePhOld != m_ePhCur)													// Phase�� �ٸ� ��쿡�� �׸��� �ʴ´�.
		return 1;


	m_Wrk.Render();


	if(m_bWindowed)
	{
		GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
		GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	}

	GCAMGNL->SetTransForm();
	GDEVICE->SetViewport(&m_Vp);

	GDEVICE->Clear( 0L, 0, m_dwClr, 0xAAAAAAAA, 1.0f, 0L );
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;

	m_pLg.Direction = m_vcLgt;
	GDEVICE->SetLight( 0, &m_pLg );
	GDEVICE->LightEnable( 0, TRUE );											// Set Main Lighting
	
	(this->*OnRnd[m_ePhCur])();



	GDEVICE->EndScene();
	
	
	m_pBackBuffer->GetDC(&m_hDC);

	if(m_hDC)
	{
		(this->*OnRns[m_ePhCur])();
		GBACKSF->ReleaseDC(m_hDC);
	}

	return S_OK;
}


GAME_LOOP_FR(Wrk1);
GAME_LOOP_FR(Wrk2);