// Implementation of the CWndFog class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndFog, MsgPrc);


INT CWndFog::Init()
{
	m_hWnd	= 0;
	m_hWPrn	= 0;


	m_dFt	= D3DFOG_LINEAR;
	m_dFc	= 0xFF336699;
	m_fFb	= 200.0f;
	m_fFe	= 5000.0f;
	m_fFd	= 1.f;

	int iSize = sizeof(m_crT)/ sizeof(m_crT[0]);

	for(int i=0; i< iSize; ++i)
		m_crT[i] = RGB( rand()%256, rand()%256, rand()%256);

	return 1;
}


INT CWndFog::Create(HWND hWnd)
{
	if(m_hWnd)
		return 1;

	m_hWPrn= hWnd;
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_FOG), m_hWPrn, CLSS_DLG_WNDPROC(CWndFog));
	m_hWfc	= GetDlgItem(m_hWnd, IDC_FOG_C);

	RECT	rt1;
	RECT	rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(m_hWPrn, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left + 80;
	iY = rt1.top  + 250;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);
	::ShowWindow(m_hWnd, SW_SHOW);


	RECT		rc;
	HWND		hWpnt;
	HDC			hdc;
	BYTE*		pClr;
	BYTE		ClrR;
	BYTE		ClrG;
	BYTE		ClrB;
	HBRUSH		hbrsh;
	COLORREF	clrf;

	hWpnt	= m_hWfc;
	hdc		= GetDC(hWpnt);
	pClr	= McUtil_GetColorARGB(m_dFc);
	ClrR	= pClr[1];
	ClrG	= pClr[2];
	ClrB	= pClr[3];
	clrf	= RGB(ClrR, ClrG, ClrB);
	hbrsh	= CreateSolidBrush(clrf);
	GetClientRect(hWpnt, &rc);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(hWpnt, hdc);

	SetDlgItemInt(m_hWnd, IDC_FOG_R, ClrR, 0);
	SetDlgItemInt(m_hWnd, IDC_FOG_G, ClrG, 0);
	SetDlgItemInt(m_hWnd, IDC_FOG_B, ClrB, 0);

	SetDlgItemFlt(m_hWnd, IDC_FOG_BGN, m_fFb, 0);
	SetDlgItemFlt(m_hWnd, IDC_FOG_END, m_fFe, 0);
	SetDlgItemFlt(m_hWnd, IDC_FOG_DNS, m_fFd, 4);

	CheckRadioButton(m_hWnd, IDC_FOG_NONE, IDC_FOG_NONE+4, IDC_FOG_NONE + m_dFt);


	



	return 1;
}



void CWndFog::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}



void CWndFog::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}



LRESULT CWndFog::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	CHOOSECOLOR	COL;

	BYTE		ClrR;
	BYTE		ClrG;
	BYTE		ClrB;

	RECT		rc;
	HWND		hWpnt;
	HDC			hdc;
	BYTE*		pClr;
	HBRUSH		hbrsh;
	COLORREF	clrf;
	PAINTSTRUCT ps;

	DWORD		dClr;



	switch( uMsg )
	{
		case WM_PAINT:
		{
			hWpnt	= m_hWfc;
			hdc		= BeginPaint(hWpnt, &ps);
			pClr	= McUtil_GetColorARGB(m_dFc);
			ClrR	= pClr[1];
			ClrG	= pClr[2];
			ClrB	= pClr[3];
			clrf	= RGB(ClrR, ClrG, ClrB);
			hbrsh	= CreateSolidBrush(clrf);
			GetClientRect(hWpnt, &rc);
			InvalidateRect(hWpnt, &rc, 1);
			FillRect(hdc, &rc, hbrsh);
			DeleteObject(hbrsh);
			ReleaseDC(hWpnt, hdc);
			EndPaint(hWpnt, &ps);
			
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_FOG_OK:
				{
					GMAIN->m_pGmWrk1->m_pField->SetFog(m_dFt, m_dFc, m_fFb, m_fFe, m_fFd);
					break;
				}

				case IDC_FOG_CANCEL:
				{
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}


				case IDC_FOG_C:
				{	
					memset(&COL, 0, sizeof(CHOOSECOLOR));
					COL.lStructSize = sizeof(CHOOSECOLOR);
					COL.hwndOwner=hWnd;
					COL.lpCustColors=m_crT;

					if (ChooseColor(&COL))
					{
						SetPickColor(dClr, COL.rgbResult,IDC_FOG_C, true);

						ClrR	= GetRValue(COL.rgbResult);
						ClrG	= GetGValue(COL.rgbResult);
						ClrB	= GetBValue(COL.rgbResult);
						
						m_dFc	= D3DCOLOR_XRGB( ClrR, ClrG, ClrB);

						SetDlgItemInt(m_hWnd, IDC_FOG_R, ClrR, 0);
						SetDlgItemInt(m_hWnd, IDC_FOG_G, ClrG, 0);
						SetDlgItemInt(m_hWnd, IDC_FOG_B, ClrB, 0);
					}

					break;
				}

				case IDC_FOG_BGN:{	switch(wparHi)	{	case EN_CHANGE:	{	m_fFb= GetDlgItemFlt(hWnd, IDC_FOG_BGN);break;	}}	break;	}
				case IDC_FOG_END:{	switch(wparHi)	{	case EN_CHANGE:	{	m_fFe= GetDlgItemFlt(hWnd, IDC_FOG_END);break;	}}	break;	}
				case IDC_FOG_DNS:{	switch(wparHi)	{	case EN_CHANGE:	{	m_fFd= GetDlgItemFlt(hWnd, IDC_FOG_DNS);break;	}}	break;	}

				case IDC_FOG_NONE:	{	m_dFt = D3DFOG_NONE;	break;	}
				case IDC_FOG_EXP:	{	m_dFt = D3DFOG_EXP;		break;	}
				case IDC_FOG_EXP2:	{	m_dFt = D3DFOG_EXP2;	break;	}
				case IDC_FOG_LINE:	{	m_dFt = D3DFOG_LINEAR;	break;	}

				case IDC_FOG_R:	{	switch(wparHi)	{	case EN_CHANGE:	{	OnChangeColor(hWnd, IDC_FOG_C);	break;	}}	break;	}
				case IDC_FOG_G:	{	switch(wparHi)	{	case EN_CHANGE:	{	OnChangeColor(hWnd, IDC_FOG_C);	break;	}}	break;	}
				case IDC_FOG_B:	{	switch(wparHi)	{	case EN_CHANGE:	{	OnChangeColor(hWnd, IDC_FOG_C);	break;	}}	break;	}
			}
			
			break;
		}

		case WM_CLOSE:
		{
			DestroyWindow( hWnd );
			m_hWnd	= NULL;
			break;
		}
	}

	return(FALSE);
}




void CWndFog::SetPickColor(DWORD&	clrOut,DWORD& clrIn, INT nID, bool IsBGR)
{
	COLORREF	col;
	BYTE*		bgr;
	RECT		rc;
	HWND		hWnd;
	HDC			hdc;
	HBRUSH		hbrsh;

	if(IsBGR)
		bgr	= McUtil_GetColorBGR(clrIn);

	else
		bgr = McUtil_GetColorARGB(clrIn);


	col = RGB(bgr[1],bgr[2], bgr[3]);
	clrOut = D3DCOLOR_XRGB(bgr[1],bgr[2], bgr[3]);
						
	hWnd= GetDlgItem(m_hWnd, nID);
	hdc = GetDC(hWnd);
	hbrsh = CreateSolidBrush(col);

	GetClientRect(hWnd, &rc);
	InvalidateRect(hWnd, &rc, 1);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(hWnd, hdc);
	
}




void CWndFog::OnChangeColor(HWND hWnd, INT nID)
{
	BYTE	ClrR = GetDlgItemInt(hWnd, nID + 1, 0,0);
	BYTE	ClrG = GetDlgItemInt(hWnd, nID + 2, 0,0);
	BYTE	ClrB = GetDlgItemInt(hWnd, nID + 3, 0,0);
	DWORD	dClr = RGB(ClrR, ClrG, ClrB);

	SetPickColor(dClr, dClr , nID, true);
	m_dFc	= D3DCOLOR_XRGB( ClrR,ClrG,ClrB);
}
