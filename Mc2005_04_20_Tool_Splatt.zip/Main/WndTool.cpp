// WndTool.cpp: implementation of the CWndTool class.
//
//////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndTool, MsgPrc);


INT CWndTool::Init()
{
	m_hWnd	= 0;
	m_hWPrn	= 0;

	m_dC= 0x66006699;

	for(int i=0; i< sizeof(m_crT)/sizeof(m_crT[0]); ++i)
		m_crT[i] = RGB( 128+rand()%128, 128+rand()%128, 128+rand()%128);

	return 1;
}


INT CWndTool::Create(HWND hWnd)
{
	if(m_hWnd)
		return 1;

	m_hWPrn= hWnd;
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_TOOL), m_hWPrn, CLSS_DLG_WNDPROC(CWndTool));
	m_hCol	= GetDlgItem(m_hWnd, IDC_TOOL_COL);

	RECT	rt1;
	RECT	rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(GHWND, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left -0;
	iY = rt1.top  +40;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);

	memset(m_bTool, 0, sizeof(m_bTool));
	memset(m_bmBtn, 0, sizeof(m_bmBtn));

	m_bmBtn[ 0] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN01));
	m_bmBtn[ 1] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN02));
	m_bmBtn[ 2] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN03));
	m_bmBtn[ 3] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN04));
	m_bmBtn[ 4] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN21));
	
	m_bmBtn[ 5] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN22));
	m_bmBtn[ 6] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN23));
	m_bmBtn[ 7] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN24));
	m_bmBtn[ 8] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN25));
	m_bmBtn[ 9] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN26));
	
	m_bmBtn[10] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN27));
	m_bmBtn[11] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN28));
	m_bmBtn[12] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN29));
	m_bmBtn[13] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN30));
	m_bmBtn[14] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN31));
	
	m_bmBtn[15] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN32));
	m_bmBtn[16] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN33));
	m_bmBtn[17] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN34));
	m_bmBtn[18] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN35));
	m_bmBtn[19] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN36));
	m_bmBtn[20] = LoadBitmap(GHINST,MAKEINTRESOURCE(IDB_ICN37));

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT01,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 0]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT02,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 1]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT03,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 2]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT04,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 3]);

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT05,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 4]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT06,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 5]);

	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT07,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[18]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT08,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[19]);
	
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT09,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[20]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT10,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 9]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT11,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[15]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT12,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[11]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT13,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[12]);
	SendDlgItemMessage(m_hWnd,IDC_TOOL_BT14,BM_SETIMAGE, (WPARAM)IMAGE_BITMAP,(LPARAM)m_bmBtn[ 7]);

	BYTE* pClr	= McUtil_GetColorARGB(m_dC);
	BYTE ClrR	= pClr[1];
	BYTE ClrG	= pClr[2];
	BYTE ClrB	= pClr[3];

	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
	SetDlgItemHex(m_hWnd, IDC_TOOL_COL_ALL, m_dC, false);


	CheckRadioButton(m_hWnd, IDC_TOOL_BT01, IDC_TOOL_BT14, IDC_TOOL_BT14);

	::ShowWindow(m_hWnd, SW_SHOW);

	

	RECT	rc;
	HDC		hdc;
	hdc		= GetDC(m_hCol);

	GetClientRect(m_hCol, &rc);
	HBRUSH hbrsh = CreateSolidBrush(m_dC);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(m_hWnd, hdc);

	return 1;
}

void CWndTool::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}


void CWndTool::Destroy()
{
	SAFE_DELETE_OBJECT_ARRAY(m_bmBtn, sizeof(m_bmBtn)/sizeof(m_bmBtn[0]) );
	SAFE_DESTROY_WINDOW(m_hWnd);
}

LRESULT CWndTool::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	BYTE		ClrR;
	BYTE		ClrG;
	BYTE		ClrB;

	switch( uMsg )
	{
		case WM_PAINT:
		{
			HDC		hdc;
			RECT	rc;
			PAINTSTRUCT ps;
			hdc = BeginPaint(m_hCol, &ps);

			GetClientRect(m_hCol, &rc);

			BYTE bgr[4];
			memset(bgr, 0, sizeof(bgr));
			memcpy(bgr, &m_dC, sizeof(bgr));
			COLORREF	col = RGB(bgr[2],bgr[1], bgr[0]);
			HBRUSH hbrsh = CreateSolidBrush(col);
			FillRect(hdc, &rc, hbrsh);
			DeleteObject(hbrsh);
			EndPaint(m_hCol, &ps);
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_TOOL_BT01:	SetActWnd(IDC_TOOL_BT01);	break;
				case IDC_TOOL_BT02:	SetActWnd(IDC_TOOL_BT02);	break;
				case IDC_TOOL_BT03:	SetActWnd(IDC_TOOL_BT03);	break;
				case IDC_TOOL_BT04:	SetActWnd(IDC_TOOL_BT04);	break;
				case IDC_TOOL_BT05:	SetActWnd(IDC_TOOL_BT05);	break;
				case IDC_TOOL_BT06:	SetActWnd(IDC_TOOL_BT06);	break;
				case IDC_TOOL_BT07:	SetActWnd(IDC_TOOL_BT07);	break;
				case IDC_TOOL_BT08:	SetActWnd(IDC_TOOL_BT08);	break;
				case IDC_TOOL_BT09:	SetActWnd(IDC_TOOL_BT09);	break;
				case IDC_TOOL_BT10:	SetActWnd(IDC_TOOL_BT10);	break;

				case IDC_TOOL_BT11:	SetActWnd(IDC_TOOL_BT11);	break;
				case IDC_TOOL_BT12:	SetActWnd(IDC_TOOL_BT12);	break;
				case IDC_TOOL_BT13:	SetActWnd(IDC_TOOL_BT13);	break;
				case IDC_TOOL_BT14:	SetActWnd(IDC_TOOL_BT14);	break;

				case IDC_TOOL_COL:
				{
					CHOOSECOLOR COL;
					
					memset(&COL, 0, sizeof(CHOOSECOLOR));
					COL.lStructSize = sizeof(CHOOSECOLOR);
					COL.hwndOwner=hWnd;
					COL.lpCustColors=m_crT;

					if (ChooseColor(&COL))
					{
						HWND hwWrk = GMAIN->m_Wrk.m_Wrk1.m_hWnd;
						SetPickColor(COL.rgbResult, true);
						
						BYTE* pClr	= McUtil_GetColorARGB(m_dC);
						BYTE ClrR	= pClr[1];
						BYTE ClrG	= pClr[2];
						BYTE ClrB	= pClr[3];

						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
						SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
						SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC, false);
					}

					break;
				}

				case IDC_TOOL_COL_R:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}

				case IDC_TOOL_COL_G:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}

				case IDC_TOOL_COL_B:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
						{
							ClrR = GetDlgItemInt(hWnd, IDC_TOOL_COL_R, 0, 0);
							ClrG = GetDlgItemInt(hWnd, IDC_TOOL_COL_G, 0, 0);
							ClrB = GetDlgItemInt(hWnd, IDC_TOOL_COL_B, 0, 0);
							DWORD dC = RGB(ClrR, ClrG, ClrB);
							SetPickColor(dC, true);
							SetDlgItemHex(hWnd, IDC_TOOL_COL_ALL, m_dC,false);
							
							break;
						}
					}

					break;
				}


				case IDC_TOOL_COL_ALL:
				{
					break;
				}

			}// switch
			
			break;
		}



		case WM_NOTIFY:
		{
			break;
		}// case
	}

	return(FALSE);
}



void CWndTool::SetPickColor(DWORD	dC, bool IsBGR)
{
	COLORREF	col;
	BYTE		bgr[4];

	memset(bgr, 0, sizeof(bgr));
	memcpy(bgr, &dC, sizeof(bgr));

	if(IsBGR)
	{
		m_dC = D3DCOLOR_ARGB(0x66, bgr[0],bgr[1], bgr[2]);
		col = dC;
	}
	else
	{
		m_dC = dC;
		col = RGB(bgr[2],bgr[1], bgr[0]);
	}
						
	RECT	rc;
	HDC		hdc = GetDC(m_hCol);
	HBRUSH	hbrsh = CreateSolidBrush(col);

	GetClientRect(m_hCol, &rc);
	FillRect(hdc, &rc, hbrsh);
	DeleteObject(hbrsh);
	ReleaseDC(m_hWnd, hdc);
}

FLOAT CWndTool::GetDirection()
{
	return (m_bTool[ 0]*1.f - m_bTool[ 1]*1.f);
}



void CWndTool::SetColor(DWORD dc)
{
	m_dC = dc;
	BYTE* pClr	= McUtil_GetColorARGB(m_dC);
	BYTE ClrR	= pClr[1];
	BYTE ClrG	= pClr[2];
	BYTE ClrB	= pClr[3];

	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_R, ClrR, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_G, ClrG, 0);
	SetDlgItemInt(m_hWnd, IDC_TOOL_COL_B, ClrB, 0);
}


INT CWndTool::Restore()
{
	SAFE_RESTORE(&m_WndLyr);

	return 1;
}

void CWndTool::Invalidate()
{
	SAFE_INVALID(&m_WndLyr);
}


INT CWndTool::FrameMove()
{
	SAFE_FRMOV(&m_WndLyr);

	return 1;
}


void CWndTool::Render()
{
	SAFE_RENDER(&m_WndLyr);
}

void CWndTool::SetActWnd(INT nId)
{
	memset(m_bTool, 0, sizeof(m_bTool));
	m_bTool[nId - IDC_TOOL_BT01] = 1;

	if(nId != IDC_TOOL_BT10 && m_WndLyr.m_hWnd)
		SendMessage(m_WndLyr.m_hWnd, WM_CLOSE, 0, 0);


	// Material
	if(IDC_TOOL_BT07 == nId)
	{
		m_WndMtrl.Create(GHWND);
		m_WndMtrl.ShowWindow();
	}

	// Lighting
	if(IDC_TOOL_BT08 == nId)
	{
		m_WndLght.Create(GHWND);
		m_WndLght.ShowWindow();
	}

	// Fog
	if(IDC_TOOL_BT09 == nId)
	{
		m_WndFog.Create(GHWND);
		m_WndFog.ShowWindow();
	}

	// Layer
	if(IDC_TOOL_BT10 == nId)
	{
		m_WndLyr.Create(GHWND);
		m_WndLyr.ShowWindow();
	}
}
