// Implementation of the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndWrk1, MsgPrc);


INT CWndWrk1::Init()
{
	m_nGrp	=0;
	m_nObj	=0;
	m_nLst	=0;
		
	m_iRng	= 4;
	m_fDH	= 5.f;
	m_bAc	= 1;

	m_pObj	= NULL;

	return 1;
}


INT CWndWrk1::Create(HWND hWnd)
{
	m_hWnd = CreateDialog(GHINST,MAKEINTRESOURCE(IDD_WRK1), hWnd, CLSS_DLG_WNDPROC(CWndWrk1));

	m_hGrp = GetDlgItem(m_hWnd, IDC_WRK1_GRP);
	m_hObj = GetDlgItem(m_hWnd, IDC_WRK1_OBJ);
	m_hLst = GetDlgItem(m_hWnd, IDC_WRK1_LST);

	SetDlgItemInt(m_hWnd, IDC_WRK1_DH,	m_fDH,	1);
	SetDlgItemInt(m_hWnd, IDC_WRK1_RNG, m_iRng,	0);

	SendMessage(GetDlgItem(m_hWnd, IDC_WRK1_AC),BM_SETCHECK,m_bAc,0);

	memset(m_bmBtn, 0, sizeof(m_bmBtn));
	m_bmBtn[0] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN26));
	m_bmBtn[1] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN27));
	m_bmBtn[2] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN29));
	m_bmBtn[3] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN30));
	m_bmBtn[4] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN31));
	m_bmBtn[5] = LoadBitmap(GHINST, MAKEINTRESOURCE(IDB_ICN34));

	SendDlgItemMessage(m_hWnd, IDC_WRK1_WLD_CRT,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[0]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_WLD_LOAD,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[3]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_WLD_SAVE,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[4]);
	
	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_CRT,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[1]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_LOAD,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[5]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_SAVE,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[4]);
	SendDlgItemMessage(m_hWnd, IDC_WRK1_LCL_MOVE,	BM_SETIMAGE,	(WPARAM)IMAGE_BITMAP, (LPARAM)m_bmBtn[2]);
	

	
	ReadDataGrp();
	ReadDataObj();
	ReadDataLst();

	SetObj(m_nGrp, m_nObj, m_nLst);

	return 1;
}


void CWndWrk1::Destroy()
{
	SAFE_DELETE(	m_pObj	);	

	for(int i=0; i<m_vImgLst.size(); ++i)
		SAFE_RELEASE(	m_vImgLst[i].pTx);
	
	m_vImgLst.clear();



	SAFE_DELETE_OBJECT_ARRAY(m_bmBtn, (sizeof(m_bmBtn)/sizeof(m_bmBtn[0])) );
	SAFE_DESTROY_WINDOW(m_hWnd);
}


INT	CWndWrk1::Restore()
{
	HRESULT hr;

	if(!GMAIN->m_bWindowed)
		return 1;

	m_SwpWn.hW = (HWND)GetDlgItem(m_hWnd, IDC_WRK1_PANNEL);

	D3DPRESENT_PARAMETERS	par;
	memset(&par, 0, sizeof(D3DPRESENT_PARAMETERS));
	
	par.SwapEffect = D3DSWAPEFFECT_DISCARD;
	par.Windowed = TRUE;
	
	RECT rt;
	GetWindowRect(m_SwpWn.hW, &rt);

	par.BackBufferWidth= 0;
	par.BackBufferHeight= 0;
	par.hDeviceWindow = m_SwpWn.hW;

	hr = GDEVICE->CreateAdditionalSwapChain(&par, &m_SwpWn.pC) ;

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Create addtional swap chain failed");
		return hr;
	}

	hr = m_SwpWn.pC->GetBackBuffer(0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);

	if ( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Get back buffer Failed");
		return hr;
	}


	D3DFORMAT format = GMAIN->m_d3dSettings.DepthStencilBufferFormat();
	hr = GDEVICE->CreateDepthStencilSurface(par.BackBufferWidth, par.BackBufferHeight, format, D3DMULTISAMPLE_NONE, 0, 0, &m_SwpWn.pS, NULL);

	if ( FAILED(hr))
	{
		MessageBox(NULL, "Failed", "Failed", MB_OK);
		return -1;
	}

	return 1;
}


void CWndWrk1::Invalidate()
{
	m_SwpWn.Release();
}


INT CWndWrk1::FrameMove()
{
	SAFE_FRMOV(	m_pObj	);

	return 1;
}



void CWndWrk1::Render()
{
	if(GP_WRK1 != GMAIN->m_ePhCur)
		return;

	if(!GMAIN->m_bWindowed)
		return;

	if(GCAMOBJ)
	{
		MATA mtViw;
		D3DXMatrixLookAtLH(&mtViw, &VEC3(0,0, -1000), &VEC3(0,200, 0), &VEC3(0,1,0));
		GCAMOBJ->SetMatrixViw(mtViw);
		GCAMOBJ->Update();
		GCAMOBJ->SetTransForm();
	}

	

	GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
	GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	
	GDEVICE->Clear( 0L, 0, GMAIN->m_dwClr,  0x00006699, 1.0f, 0L );

	RECT rt={5,10, 1024,30};
	GMAIN->m_pD3DXFont->DrawText(NULL, "Object", -1, &rt, 0, 0XFFFFFFFF);

	SAFE_RENDER(	GCAMOBJ	);
	SAFE_RENDER(	m_pObj	);

	m_SwpWn.pC->Present(0, 0, 0, 0, 0);
}



LRESULT CWndWrk1::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_WRK1_LCL_CRT:
				{
					m_WndCreate.Create(GHWND);
					m_WndCreate.ShowWindow();

					break;
				}

				case IDC_WRK1_RNG:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
							m_iRng = GetDlgItemInt(hWnd, IDC_WRK1_RNG, 0,0);
							break;
					}

					break;
				}


				case IDC_WRK1_DH:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
							m_fDH= GetDlgItemFlt(hWnd, IDC_WRK1_DH);
							break;
					}

					break;
				}


				case IDC_WRK1_AC:
				{
					if (SendMessage(GetDlgItem(hWnd, IDC_WRK1_AC),BM_GETCHECK,0,0)==BST_CHECKED)
						m_bAc = 1;
					else
						m_bAc =0;

					break;
				}

				case IDC_WRK1_GRP:
				{
					switch( wparHi)
					{
						case LBN_SELCHANGE:
							m_nGrp = SendMessage(m_hGrp, CB_GETCURSEL,0,0);
							m_nObj = 0;
							m_nLst = 0;

							ReadDataObj();
							ReadDataLst();
							SetObj(m_nGrp, m_nObj, m_nLst);
							break;
					}

					break;
				}

				case IDC_WRK1_OBJ:
				{
					switch( wparHi)
					{
						case LBN_SELCHANGE:
							m_nObj = SendMessage(m_hObj, CB_GETCURSEL,0,0);
							m_nLst = 0;
							ReadDataLst();
							SetObj(m_nGrp, m_nObj, m_nLst);
							break;
					}

					break;
				}

				case IDC_WRK1_LST:
				{
					switch( wparHi)
					{
						case LBN_SELCHANGE:
							m_nLst = SendMessage(m_hLst, LB_GETCURSEL,0,0);
							SetObj(m_nGrp, m_nObj, m_nLst);
							break;
					}

					break;
				}

			}

			break;

		}// case WM_COMMAND


		

	}

	return(FALSE);
}




INT CWndWrk1::SetObj(WORD nI1, WORD nI2, WORD nI3)
{
	if(0==nI1)
	{
		McImg*	pImg = FindImg(nI1, nI2, nI3);
		
		if(!pImg)
			return -1;

		SAFE_DELETE(	m_pObj	);

		CMd2D*	pObj = new CMd2D;

		pObj->SetId(nI1, nI2, nI3);

		pObj->nT	= nI3;
		pObj->pTx	= pImg->pTx;
		pObj->vcP	= VEC3(0,0,0);
		pObj->fImgX	= 1.f * pImg->Img.Width;
		pObj->fImgY	= 1.f * pImg->Img.Height;

		pObj->SetCam(GCAMOBJ);

		m_pObj			= pObj;
	}

	if(1==nI1)
	{
		TCHAR	sFile[512];
		SAFE_DELETE(	m_pObj	);
		CMd3D*	pObj = NULL;
		SAFE_NEWINIT(	pObj,	CMd3D	);


		SendMessage(m_hLst, LB_GETTEXT, m_nLst, (LPARAM)sFile);
		pObj->SetId(nI1, nI2, nI3);
		pObj->SetPos(VEC3(0,0, 0));
		pObj->SetMdl(McUtil_Forming("Model/%s", sFile));

		pObj->SetCam(GCAMOBJ);

		m_pObj			= pObj;
	}

	return 1;
}



void CWndWrk1::ReadDataGrp()
{
	INT		i=0;
	TCHAR	sTmp[512];
	INT		iNt=0;

	m_vStrGrp.clear();

	GetCurrentDirectory(sizeof(sTmp), sTmp);

	GetPrivateProfileString("Group", "Num", NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
	iNt = atoi(sTmp);

	for(i=0; i<iNt; ++i)
	{
		GetPrivateProfileString("Group", McUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
		m_vStrGrp.push_back(sTmp);
	}

	SendMessage(m_hGrp, CB_RESETCONTENT, 0, 0);

	for (i=0; i<m_vStrGrp.size(); ++i)
		SendMessage(m_hGrp, CB_ADDSTRING, 0, (LPARAM)m_vStrGrp[i].c_str() );

	SendMessage(m_hGrp, CB_SETCURSEL, m_nGrp, 0);
}


void CWndWrk1::ReadDataObj()
{
	TCHAR	sGrp[128];
	INT		i=0;
	TCHAR	sTmp[512];
	INT		iNt=0;
	
	memset(sGrp, 0, sizeof(sGrp));
	strcpy(sGrp, (char*)m_vStrGrp[m_nGrp].c_str());

	m_vStrObj.clear();

	GetPrivateProfileString(sGrp, "Num", NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
	iNt = atoi(sTmp);

	for(i=0; i<iNt; ++i)
	{
		GetPrivateProfileString(sGrp, McUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
		m_vStrObj.push_back(sTmp);
	}

	SendMessage(m_hObj, CB_RESETCONTENT, 0, 0);

	for (i=0; i<m_vStrObj.size(); ++i)
		SendMessage(m_hObj, CB_ADDSTRING, 0, (LPARAM)m_vStrObj[i].c_str() );

	SendMessage(m_hObj, CB_SETCURSEL, m_nObj, 0);
}


void CWndWrk1::ReadDataLst()
{
	TCHAR	sObj[128];
	INT		i=0, j=0;
	TCHAR	sTmp[512];
	INT		iNt=0;

	INT		iSize = m_vStrObj.size();
	m_vStrLst.clear();
	SendMessage(m_hLst, LB_RESETCONTENT, 0, 0);

	if(iSize<1)
		return;
	
	memset(sObj, 0, sizeof(sObj));
	strcpy(sObj, (char*)m_vStrObj[m_nObj].c_str());

	m_vStrLst.clear();

	GetPrivateProfileString(sObj, "Num", NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
	iNt = atoi(sTmp);

	for(i=0; i<iNt; ++i)
	{
		GetPrivateProfileString(sObj, McUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp),"Data/Model.ini");
		m_vStrLst.push_back(sTmp);
	}

	SendMessage(m_hLst, LB_RESETCONTENT, 0, 0);

	for (i=0; i<m_vStrLst.size(); ++i)
		SendMessage(m_hLst, LB_ADDSTRING, 0, (LPARAM)m_vStrLst[i].c_str() );

	SendMessage(m_hLst, LB_SETCURSEL, m_nLst, 0);


	for(i=0; i<iNt; ++i)
	{
		if(!FindImg(m_nGrp,m_nObj,i))
		{
			TCHAR*	sName = (char*)m_vStrLst[i].c_str();
			McImg	Img;
			Img.nI1 = m_nGrp;
			Img.nI2 = m_nObj;
			Img.nI3 = i;

			McUtil_TextureLoad(McUtil_Forming("Texture/%s", sName), Img.pTx, 0x00FFFFFF, &Img.Img);

			m_vImgLst.push_back(Img);
		}
	}
		

}


void CWndWrk1::DataGrpWrite()
{
	INT		i;
	INT		iTxSize = m_vStrGrp.size();

	WritePrivateProfileString("Texture", "Num", McUtil_Forming("%d", iTxSize), "Data/Texture.ini");
	
	for(i=0; i<iTxSize; ++i)
		WritePrivateProfileString("Texture", McUtil_Forming("%d", i), (char*)m_vStrGrp[i].c_str(), "Data/Texture.ini");
}


McImg*	CWndWrk1::FindImg(WORD nI1, WORD nI2, WORD nI3)
{
	int	j;
	int iSize = m_vImgLst.size();

	for(j=0; j<iSize; ++j)
	{
		if( nI1 == m_vImgLst[j].nI1 &&
			nI2 == m_vImgLst[j].nI2 &&
			nI3 == m_vImgLst[j].nI3)
			return &m_vImgLst[j];
	}

	return NULL;
}