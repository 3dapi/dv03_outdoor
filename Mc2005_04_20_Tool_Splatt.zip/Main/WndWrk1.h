// Interface for the CWndWrk1 class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDWRK1_H_
#define _WNDWRK1_H_


struct McImg
{
	WORD	nI1;
	WORD	nI2;
	WORD	nI3;
	WORD	nI4;
	PDTX	pTx;
	DIMG	Img;

	McImg():nI1(0xFFFF),nI2(0xFFFF),nI3(0xFFFF),nI4(0xFFFF),pTx(0){}
};


typedef vector<McImg>			lsMcImg;
typedef lsMcImg::iterator		itMcImg;



class CWndWrk1
{
public:
	HWND			m_hWnd		;
	TlSwpWn			m_SwpWn		;												// Swap Chain Window

	HWND			m_hGrp		;												// Group
	HWND			m_hObj		;												// Object
	HWND			m_hLst		;												// List

	INT				m_nGrp		;
	INT				m_nObj		;
	INT				m_nLst		;
	CMdObj*			m_pObj		;

	CWndCreate		m_WndCreate	;
	INT				m_iRng		;
	FLOAT			m_fDH		;
	INT				m_bAc		;												//

protected:
	HBITMAP			m_bmBtn[20]	;

	lsStr			m_vStrGrp	;
	lsStr			m_vStrObj	;
	lsStr			m_vStrLst	;
	
	lsMcImg			m_vImgLst	;
	
public:
	CLSS_DLG_DECLEAR( CWndWrk1 );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	void	ReadDataGrp();
	void	ReadDataObj();
	void	ReadDataLst();

	void	DataGrpWrite();


public:
	INT		GetRng()	{	return m_iRng;	}
	INT		GetLstIdx()	{	return m_nLst;	}
	INT		SetObj(WORD wI1, WORD wI2, WORD wI3);
	CMdObj*	GetObj()	{	return m_pObj;	}

	McImg*	FindImg(WORD wI1, WORD wI2, WORD wI3);
};

#endif