// Interface for the CMcWood class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCWOOD_H_
#define _MCWOOD_H_


class CMcWood
{
protected:
	lsMdl3D		m_vObj;

public:
	CMcWood();
	~CMcWood();
	
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

	void	SetHeight();

	void	AddObj(CMd3D* pObj, VEC3 vcP);
};

#endif