// Interface for the CMdObj class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MDOBJ_H_
#define _MDOBJ_H_


class _CMc
{
public:
	virtual ~_CMc()	{}
};



class CBase : public _CMc
{
public:
	WORD		nI1;
	WORD		nI2;
	WORD		nI3;
	WORD		nI4;

public:
	CBase():nI1(0xFFFF),nI2(0xFFFF),nI3(0xFFFF), nI4(0xFFFF){}
	CBase(WORD I1,WORD I2,WORD I3,WORD I4=0xFFFF):nI1(I1),nI2(I2),nI3(I3),nI4(I4){}

	void SetId(WORD I1,WORD I2,WORD I3,WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	WORD GetId1()	{	return nI1;	}
	WORD GetId2()	{	return nI2;	}
	WORD GetId3()	{	return nI3;	}
	WORD GetId4()	{	return nI4;	}
};



class CMdObj : public CBase
{
public:
	VEC3		vcP;															// Position
	MATA		mtW;
	FLOAT		fR;																// Distance From Camera
	CMcCam*		pCam;

public:
	CMdObj() : vcP(0,0,0),fR(0), pCam(0)
	{
		D3DXMatrixIdentity(&mtW);
	}

	virtual ~CMdObj()				{}
	virtual INT		Init()			{	return 1;	}
	virtual void	Destroy()		{				}
	virtual INT		FrameMove()		{	return 1;	}
	virtual void	Render()		{				}

	void	SetCam(CMcCam*	_pCam)	{	pCam=_pCam;	}

	void	SetPos(VEC3	pos)
	{
		vcP = pos;
		mtW._41 = vcP.x;
		mtW._42 = vcP.y;
		mtW._43 = vcP.z;
	}

	VEC3	GetPos()			{	return vcP;		}
};



class CMd2D : public CMdObj
{
public:
	INT			nT;																// Texture Index;
	PDTX		pTx;

	FLOAT		fImgX;
	FLOAT		fImgY;
	DCLR		dcC;
	VtxDUV1		pVx[4];

public:
	CMd2D();
	INT		FrameMove();
	void	Render();

	void	SetColor(DWORD _dc)		{	dcC= _dc;	}
};


typedef vector<CMd2D>			lsMdl2D;
typedef lsMdl2D::iterator		itMdl2D;

typedef vector<lsMdl2D >		llsMdl2D;
typedef llsMdl2D::iterator		iitMdl2D;


class CMd3D : public CMdObj
{
public:
	TCHAR		m_sMd[256];
	TCHAR		m_sTx[256];
	PDTX		m_pTx;

	INT			m_iNi;
	INT			m_iNv;

	VtxIdx*		m_pIx;
	VtxNDUV1*	m_pVx;

public:
	CMd3D();
	virtual ~CMd3D();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

	INT		SetMdl(TCHAR* sMdl);
	INT		Load();
	
	TCHAR*	GetMdlName()	{	return m_sMd;	}
	TCHAR*	GetMdlTx()		{	return m_sTx;	}
	INT		Copy(CMd3D*	rhs);
};


typedef vector<CMd3D* >			lsMdl3D;
typedef lsMdl3D::iterator		itMdl3D;


#endif