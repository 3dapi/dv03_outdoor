// Interface for the Mc Utility functions.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCUTIL_H_
#define _MCUTIL_H_

#define ONE_RADtoDEG	57.295779513082321f
#define ONE_DEGtoRAD	0.0174532925199433f
#define PI_RADIAN		3.1415926535897932f
#define DEG90toRAD		1.5707963267948966f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }


#define SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
																			\
		if(!(p))															\
		{																	\
			return -1;														\
		}																	\
																			\
		if(FAILED((p)->Init()))												\
		{																	\
			delete p;														\
			p = NULL;														\
			return -1;														\
		}																	\
	}																		\
}


#define SAFE_RESTORE(p)														\
{																			\
	if(p)																	\
	{																		\
		if(FAILED((p)->Restore()))											\
			return -1;														\
	}																		\
}



#define SAFE_FRMOV(p)	{ if(p) {if(FAILED( (p)->FrameMove())) return -1; } }
#define SAFE_UPDATE(p)	{ if(p) {if(FAILED( (p)->Update())) return -1; } }

#define SAFE_DESTROY(p)			{	if(p)	(p)->Destroy();			}
#define SAFE_INVALID(p)			{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)			{	if(p)	(p)->Render();			}
#define SAFE_RENDERS(p)			{	if(p)	(p)->RenderS();			}

#define SAFE_ONFRMMOV(p)		{	if(p)	(p)->OnFrmMov();		}
#define SAFE_ONRENDER(p)		{	if(p)	(p)->OnRender();		}


#define	SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}

#define FLOATP(p)			(float*)&(p)


#define SAFE_DELETE_OBJECT(p)	{	if(p){	DeleteObject(p); (p)=NULL;	}	}


#define SAFE_DELETE_OBJECT_ARRAY(p, iSIZE)									\
{																			\
	int i_IDX_OBJ_=0;														\
																			\
	for(i_IDX_OBJ_=0; i_IDX_OBJ_ < (iSIZE) ; ++i_IDX_OBJ_)					\
	{																		\
		if(p[i_IDX_OBJ_])													\
		{																	\
			DeleteObject(p[i_IDX_OBJ_]);									\
			p[i_IDX_OBJ_] = NULL;											\
		}																	\
	}																		\
}


// Vector delete
#define SAFE_DEL_LST(p)														\
{																			\
	if(!p.empty())															\
	{																		\
		int iSizeList = p.size();											\
		for(int indexList=0; indexList<iSizeList; ++indexList)				\
		{																	\
			delete (p[indexList]);											\
		}																	\
		p.clear();															\
	}																		\
}



// Vector release
#define SAFE_REL_LST(p)														\
{																			\
	if(!p.empty())															\
	{																		\
		int iSizeList = p.size();											\
		for(int indexList=0; indexList<iSizeList; ++indexList)				\
		{																	\
			(p[indexList])->Release();										\
		}																	\
		p.clear();															\
	}																		\
}




#define CLASS_DESTROY(CLASS_NAME)											\
CLASS_NAME::~CLASS_NAME()													\
{																			\
	Destroy();																\
}



#define CLASS_CLEAN_ALL(CLASS_NAME)											\
CLASS_NAME::~CLASS_NAME()													\
{																			\
	Invalidate();															\
	Destroy();																\
}




#define	GAME_LOOP_FR(	PhaseName	)										\
INT CMain::OnFrm##PhaseName ()												\
{																			\
	strcat(m_sMsg, " " #PhaseName "");										\
	SAFE_FRMOV(	m_pGm##PhaseName	);										\
	return 1;																\
}																			\
																			\
void CMain::OnRnd##PhaseName ()												\
{																			\
	SAFE_RENDER(	m_pGm##PhaseName	);									\
}																			\
																			\
void CMain::OnRns##PhaseName ()												\
{																			\
	SAFE_RENDERS(	m_pGm##PhaseName	);									\
}



#define CLSS_DLG_DECLEAR(CLASS)												\
CLASS ();																	\
virtual ~CLASS ();															\
static INT_PTR	CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP);

#define CLSS_DLG_DEFINE(CLASS, MSGPROC)										\
static CLASS*	g_pWndDialog##CLASS;										\
INT_PTR CLASS :: CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP)		\
{																			\
	return (g_pWndDialog##CLASS)-> MSGPROC (hW, uM, wP, lP);				\
}																			\
																			\
CLASS :: CLASS ()		{	g_pWndDialog##CLASS = this;	Init();	}			\
CLASS:: ~ CLASS (){}

#define CLSS_DLG_WNDPROC( CLASS )	(LPDLGPROC)((CLASS##WndPrc))




void	McUtil_ErrMsgBox(TCHAR *format,...);
void	McUtil_GetLastErr();
char*	McUtil_GetSmallTime();
INT		McUtil_TextureLoad(TCHAR* sFile, PDTX& pTexture, DWORD dColor=0x00FFFFFF
						   , D3DXIMAGE_INFO* pSrcInf=NULL
						   , DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						   , DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						   , D3DFORMAT d3Fmt = D3DFMT_UNKNOWN);

void	McUtil_ReadFileLine(FILE *fp, TCHAR *str);

void	McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');
void	McUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	McUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx);
void	McUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	McUtil_IBLock(PDIB& pIB, INT nSize, void* pIdx);

bool	McUtil_LineCross2D(VEC2 * p);
INT		McUtil_3Dto2D(VEC3 & Out, const VEC3 & In);
bool	McUtil_PositionMouse3D(VEC3 & vec3dOut);
INT		McUtil_GetPickPos3D(VEC3& pPck, VEC3& p0, VEC3& p1, VEC3& p2, FLOAT& fD, bool bUseCull=true);

INT		McUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	McUtil_SetWindowTitle(const char *format, ...);
void	McUtil_TextOut(float x, float y, DWORD color, const char *format, ...);
void	McUtil_OutputDebug(const char *Format, ...);
TCHAR*	McUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR *sTitle="Choose Folder");
TCHAR*	McUtil_DWtoStr(DWORD dwA);

char*	McUtil_Forming(const char *fmt, ...);
DWORD	McUtil_VectorToRGB(VEC3* NormalVector);
void	McUtil_SetWorldIdentity();

inline DWORD	McUtil_FtoDW(FLOAT f)	{ return *((DWORD*)&f); }
inline DWORD	FtoDW(FLOAT f)	{ return *((DWORD*)&f); }

void	McUtil_ScreenCapture();
void	McUtil_SetCurrentDirectory();
DWORD	McUtil_GetUsedMemory();
FLOAT	McUtil_GetLinearWg(FLOAT f1,FLOAT f2,FLOAT f);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val, bool bAdd0x=true);

DWORD	McUtil_GetFileVersion();
void	McUtil_GetDefaultWebBrowser();
void	McUtil_LogFile(TCHAR *format,...);





// for Test...
void	McUtil_Rectangle(INT x0, INT y0, INT x1, INT y1, DWORD color=RGB(255,255,255));

// Token Seperator
void	McUtil_StrList(lsStr& vStr, char* sIn, char* sSpes=NULL);
long	McUtil_GetFileSize(FILE* &fp);

// ARGB <--> BGR
// 
BYTE* McUtil_GetColorARGB(DWORD& argb);
BYTE* McUtil_GetColorBGR(DWORD& argb);





// for memory

template<class T>
void McUtil_Calloc(T* &p, INT count)
{
	INT		iSize = sizeof(*p);
	p = (T*) malloc(count * iSize);
	memset(p, 0, count * sizeof(*p));
}


template<class T>
void McUtil_Malloc(T* &p, INT count)
{
	INT		iSize = sizeof(*p);
	p = (T*) malloc(count * iSize);
}


template<class T>
void McUtil_Free(T* &p)
{
	if(p)
	{
		free(p);
		p = NULL;
	}
}



template<class T>
void McUtil_Lock(T& pDst, INT nSize, void* pSrc)
{
	void* p;

	if( FAILED( pDst->Lock( 0, 0, &p, 0 )))
		return;

	memcpy(p, pSrc, nSize);
	pDst->Unlock();
}




template<class T>
class CLnSrtG																	// For sort... descendent Sort
{
public:
	bool operator()(const T& t1, const T& t2) const
	{ 
		return t1.fR > t2.fR; 
	}
};



template<class T>
class CLnSrtGp																	// For sort... ascendent Sort
{
public:
	bool operator()(const T& t1, const T& t2) const
	{ 
		return t1->fR > t2->fR; 
	}
};



template<class T>
class CLnSrtL																	// For sort... descendent Sort
{
public:
	bool operator()(const T& t1, const T& t2) const
	{ 
		return t1.fR < t2.fR; 
	}
};



template<class T>
class CLnSrtLp																	// For sort... ascendent Sort
{
public:
	bool operator()(const T& t1, const T& t2) const
	{ 
		return t1->fR < t2->fR; 
	}
};




typedef struct tagTlPkT															// Picking Triangle
{
	VEC3	vcPk;																// Get Position
	VEC3	p0;																	// Triangle
	VEC3	p1;																	// Triangle
	VEC3	p2;																	// Triangle
	FLOAT	fR;																	// Distance From Camera

	tagTlPkT(){}
	tagTlPkT(VEC3& vcP, VEC3& P0, VEC3& P1, VEC3& P2, FLOAT& _fD)
		: vcPk(vcP), p0(P0), p1(P1), p2(P2), fR(_fD){}

}TlPkT;


typedef vector<TlPkT>		lsTlPkT;
typedef lsTlPkT::iterator	itTlPkT;



typedef struct tagTlSwpWn														// Swap chain window
{
	PDSW	pC;																	// Swap chain
	PDSF	pB;																	//Back buffer surface
	PDSF	pS;																	//Stencil buffer surface
	HWND	hW;																	// Window Handle

	tagTlSwpWn() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

}TlSwpWn;

typedef vector<TlSwpWn>		lsTlSwpWn;
typedef lsTlSwpWn::iterator	itTlSwpWn;



//for Exec...
typedef struct tagTlExcInf
{
	TCHAR	sExcPath	[512];
	TCHAR	sVersion	[ 32];
	tagTlExcInf()
	{
		memset(sExcPath,	0, sizeof(sExcPath	));
		memset(sVersion,	0, sizeof(sVersion	));
	}

}TlExcInf;



typedef struct tagTlWnRc
{
	McRc	rc;
	DVWP	vp;

	tagTlWnRc()									{	memset(&rc, 0, sizeof(McRc));	memset(&vp, 0, sizeof(DVWP));	}
	tagTlWnRc(McRc Rc,DVWP Vp)					{	rc = Rc;	vp = Vp;	}
	tagTlWnRc(LONG X1,LONG Y1,LONG X2,LONG Y2) : rc(X1,Y1,X2,Y2)	{vp.X = X1;	 vp.Y = Y1;	vp.Width = X2;	vp.Height = Y2;	vp.MinZ = 0, vp.MaxZ = 1;	}

	tagTlWnRc(LONG X1,LONG Y1,LONG X2,LONG Y2
		, DWORD X,DWORD Y,DWORD W,DWORD H
		, FLOAT Min=0,FLOAT Max=1) : rc(X1,Y1,X2,Y2){	vp.X = X;	 vp.Y = Y;	 vp.Width = W;	 vp.Height = H;	vp.MinZ = Min, vp.MaxZ = Max;	}

	McRc	GetRect()							{	return rc;	}

}TlWnRc;



class CTlSkip
{
protected:
	INT iB;
	INT iC;
	INT	iS;

public:
	CTlSkip() : iB(1), iC(2), iS(2){}
	
	void	SetStep(INT _iS)	{	iS = _iS;	}
	INT		GetStep()			{	return iS;	}

	INT		FrameMove()
	{
		if(iB)
			++iC;

		if(iC<iS)
			return 0;

		if(iC>iS)
			iC = iS;

		return 1;
	}

	INT		IsEnd()
	{
		if(iC>=iS)
			return 1;

		return 0;
	}

	INT	SetStart()
	{
		iB = 1;
		iC =0;

		return 1;
	}
};

#endif