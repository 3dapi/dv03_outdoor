// Interface for the LnDxUtil functions and classes.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNDXUTIL_H_
#define _LNDXUTIL_H_

extern HRESULT GetDXVersion(DWORD* pdwDirectXVersion, TCHAR* strDirectXVersion, int cchDirectXVersion );

#endif