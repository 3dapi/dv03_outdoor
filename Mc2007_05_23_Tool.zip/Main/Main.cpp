// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	SetClsName(EXC_MTX);
	
	m_dHicon		= IDI_MAIN_ICON;
	m_dHmenu		= IDR_MENU;
	m_dHdevalt		= IDM_CHANGEDEVICE;
	m_dHtoggle		= IDM_TOGGLEFULLSCREEN;
	m_dHexit		= IDM_EXIT;
	m_dHaccel		= IDR_MAIN_ACCEL;
	
	
	m_pD3DXFont		= NULL;
	m_pInput		= NULL;
	m_pCamG			= NULL;
	m_pCamO			= NULL;
	
	m_pSkyTexture	= NULL;
	m_pSkyDome		= NULL;
	
	m_pTbTx			= NULL;
	m_pTbMd			= NULL;
	
	m_pFld			= NULL;
	
	m_bMnLgt		= FALSE;
	m_bMnFog		= FALSE;
	m_bMnFill		= D3DFILL_SOLID;
	m_bMnCam		= TRUE;
	m_bMnLcl		= TRUE;
	m_bMnFrame		= TRUE;
	m_bMnSkydome	= FALSE;
	
	m_dScnPosX		=230;
	m_dScnPosY		=0;
}


CMain::~CMain()
{
}



HRESULT CMain::Init()
{
	FLOAT fBack[2]={ FLOAT( GMAIN->GetDxBackW() ), FLOAT( GMAIN->GetDxBackH())};
	
	SAFE_NEWCREATE1(m_pInput,	CLnInput, GDEVICE);
	SAFE_NEWCREATE2(m_pCamG	,	CLnCam, GDEVICE, fBack);
	SAFE_NEWCREATE2(m_pCamO	,	CLnCam, GDEVICE, fBack);
	
	SAFE_NEWCREATE1(m_pTbTx	,	CTbTx, GDEVICE	);
	SAFE_NEWCREATE1(m_pTbMd	,	CTbMdB, GDEVICE	);
	
	SAFE_NEWCREATE1(m_pFld	,	CMpFld, GDEVICE	);
	
	
	m_pCamG->SetPos(VEC3(600, 400, -1000));
	m_pCamG->SetLook(VEC3(600, 300, 0));
	m_pCamG->SetFar(50000);
	m_pCamG->Update();
	m_pCamG->SetTransForm();
	
	
	D3DXFONT_DESC hFont =
	{
		14, 0
		, FW_BOLD, 1, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE
		, "Arial"
	};

	if( FAILED( D3DXCreateFontIndirect(m_pd3dDevice, &hFont, &m_pD3DXFont) ) )
		return -1;
	
	m_Wrk.Create(m_hWnd);
	SetFocus(GHWND);
	
	
	SAFE_NEWCREATE2(m_pSkyDome,	CLnDxMsh, GDEVICE, "Model/SKY/skydome.x");

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	"Env_Sky.jpg");
	m_pSkyTexture = TBTX->SelectTx(nM, nS);
	
	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pD3DXFont	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamG		);
	SAFE_DELETE(	m_pCamO		);
	SAFE_DELETE(	m_pTbTx		);
	SAFE_DELETE(	m_pTbMd		);
	
	SAFE_DELETE(	m_pFld		);
	
	SAFE_DESTROY(	&m_Wrk		);
	
	SAFE_DELETE(	m_pSkyDome	);
	
	return S_OK;
}


HRESULT CMain::Restore()
{
	GDEVICE->GetViewport(&m_Vp);
	
	if(m_bWindowed)
	{
		GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);
		GDEVICE->GetDepthStencilSurface(&m_SwpWn.pS);
	}
	
	SAFE_RESTORE(	&m_Wrk		);
	SAFE_RESTORE(	m_pSkyDome	);
	
	m_pD3DXFont->OnResetDevice();	
	
	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pD3DXFont->OnLostDevice();
	
	SAFE_INVALID(	&m_Wrk		);
	SAFE_INVALID(	m_pSkyDome	);
	
	m_SwpWn.Release();
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	HWND hWnd = GetActiveWindow();
	
	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );
	
	SAFE_FRMOV(	m_pInput	);													// Update Input
	
	VEC3 vcD = GINPUT->GetMouseDelta();
	FLOAT fCamSpeed = 10.f;
	
	if(hWnd && hWnd == GHWND)
	{
		if(vcD.z !=0.f)
			m_pCamG->MoveForward(-vcD.z* 1.f, 1.f);
		
		if(GINPUT->KeyState(DIK_W))					// W
			m_pCamG->MoveForward( fCamSpeed, 1.f);
		
		if(GINPUT->KeyState(DIK_S))					// S
			m_pCamG->MoveForward(-fCamSpeed, 1.f);
		
		if(GINPUT->KeyState(DIK_A))					// A
			m_pCamG->MoveSideward(-fCamSpeed);
		
		if(GINPUT->KeyState(DIK_D))					// D
			m_pCamG->MoveSideward(fCamSpeed);
		
		if(GINPUT->GetMouseSt(1))
		{
			FLOAT	fYaw	= D3DXToRadian(vcD.x * 0.1f);
			FLOAT	fPitch	= D3DXToRadian(vcD.y * 0.1f);
			m_pCamG->MoveRotate(fYaw, fPitch);
		}
	}
	
	else if(hWnd == m_Wrk.m_hWnd && GMAIN->IsWindow())
	{
		if( GetAsyncKeyState(VK_ADD)&0X8000 )
			m_pCamO->MoveForward(-2.f, 1.f);
		
		if( GetAsyncKeyState(VK_SUBTRACT)&0X8000 )
			m_pCamO->MoveForward(2.f, 1.f);
	}
	
	SAFE_FRMOV(	m_pCamG	);
	SAFE_FRMOV(	m_pCamO	);
	
	SAFE_FRMOV(	m_pFld	);
	SAFE_FRMOV(&m_Wrk	);
	
	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 1;
	
	if(!GDEVICE)
		return -1;
	
	
	m_Wrk.Render();
	
	
	if(m_bWindowed)
	{
		GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
		GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	}
	
	m_pCamG->SetTransForm();
	GDEVICE->SetViewport(&m_Vp);
	
	GDEVICE->Clear( 0, 0, GMAIN->GetDxClearMode(), 0x00006699, 1.0f, 0L );
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
	SAFE_RENDER(	m_pFld	);
	
	if(GMAIN->m_bMnSkydome && m_pSkyDome)
	{
		MATA	mtW;
		MATA	matS;
		MATA	matT;
		VEC3	vcCam = m_pCamG->GetCamPos();
		
		D3DXMatrixScaling( &mtW, 16, 10, 16);
		
		mtW._41 = vcCam.x;
		mtW._42 = vcCam.y-3000;
		mtW._43 = vcCam.z;
		
		GDEVICE->SetTransform( D3DTS_WORLD, &mtW );
		GDEVICE->SetRenderState( D3DRS_LIGHTING,     FALSE );
		GDEVICE->SetTexture( 0, m_pSkyTexture );

		SAFE_RENDER(	m_pSkyDome	);
	}	
	
	
	
	if(GMAIN->m_bMnCam)
		SAFE_RENDER( m_pCamG	);
	
	
	if(GMAIN->m_bMnFrame)
	{
		RECT rt={5,5, 800,20};
		GMAIN->m_pD3DXFont->DrawText(NULL, GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
	}
	
	
	GDEVICE->EndScene();
	
	return S_OK;
}
