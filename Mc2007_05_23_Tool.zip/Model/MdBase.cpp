// Implementation of the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdBase::CMdBase()
: m_fD	(0)
, fSrtR	(0)
, m_fBr	(0)
, m_vcBb(0,0,0)
, m_vcBc(0,0,0)

, m_vcP	(0,0,0)
, m_vcS	(1,1,1)
, m_mtW	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
{
	m_pDev	= NULL;
	m_pCam	= NULL;

	m_pMsD	= NULL;
	m_pMsS	= NULL;
}

CMdBase::~CMdBase()
{
	if(m_pMsD)
	{
		CMdMsh* pMshDst = (CMdMsh*)m_pMsD;
		delete pMshDst;
		m_pMsD = NULL;
	}
}

void* CMdBase::GetMshSrc()
{
	return m_pMsS;
}

void CMdBase::SetMshSrc(void* pMshSrc)
{
	m_pMsS = pMshSrc;
}


void* CMdBase::GetMshDst()
{
	return m_pMsD;
}

void CMdBase::SetMshDst(void* pMshDst)
{
	m_pMsD = pMshDst;
}


void CMdBase::SetDev(void* pDev)
{
	m_pDev = (PDEV)pDev;
}

void CMdBase::SetCam(void* pCam)
{
	m_pCam=pCam;
}

VEC3 CMdBase::GetPos()
{
	return m_vcP;
}

void CMdBase::SetPos(VEC3 pos)
{
	m_vcP = pos;
	m_mtW._41 = m_vcP.x;
	m_mtW._42 = m_vcP.y;
	m_mtW._43 = m_vcP.z;
}