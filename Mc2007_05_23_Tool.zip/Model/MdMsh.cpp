// Implementation of the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdMsh::CMdMsh()
:	iNix	(0)	
,	iNvx	(0)
,	dFVF	(0)
,	iVxS	(0)
,	pIdx	(0)
,	pVtx	(0)
{
	m_pDev = NULL;

	memset(m_sMd, 0, sizeof(m_sMd));
	memset(m_sTx, 0, sizeof(m_sTx));
}


CMdMsh::~CMdMsh()
{
	Destroy();
}

void CMdMsh::Destroy()
{
	SAFE_FREE(	pIdx	);
	SAFE_FREE(	pVtx	);
}

INT CMdMsh::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	return 1;
}

void CMdMsh::Render()
{
	m_pDev->SetTexture(0, m_pTx);
	
	m_pDev->SetFVF(dFVF);
	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, iNvx, iNix
		, pIdx, D3DFMT_INDEX16
		, pVtx, iVxS);
}







INT CMdMsh::Load(char* sFile)
{
	INT		i=0;
	char	sTmp[512];

	GetPrivateProfileString("Header", "nType", NULL, sTmp, sizeof(sTmp), sFile);
	nType = atoi(sTmp);

	GetPrivateProfileString("Header", "dFvf", NULL, sTmp, sizeof(sTmp), sFile);
	dFVF = atol(sTmp);

	GetPrivateProfileString("Header", "iVcS", NULL, sTmp, sizeof(sTmp), sFile);
	iVxS= atoi(sTmp);

	GetPrivateProfileString("Header", "iNfce", NULL, sTmp, sizeof(sTmp), sFile);
	iNix = atoi(sTmp);

	GetPrivateProfileString("Header", "iNvtx", NULL, sTmp, sizeof(sTmp), sFile);
	iNvx = atoi(sTmp);


	GetPrivateProfileString("Header", "Texture", NULL, sTmp, sizeof(sTmp), sFile);
	strcpy(m_sTx, sTmp);

	if(0 == iNix || 0 == iNvx)
		return -1;

	pIdx = (VtxIdx*) malloc(iNix * sizeof(VtxIdx));
	pVtx = malloc(iNvx * iVxS);

	for(i=0; i<iNix; ++i)
	{
		int a, b, c;
		GetPrivateProfileString("Idx", LnUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp), sFile);
		sscanf(sTmp, "%d %d %d", &a, &b, &c);

		pIdx[i] = VtxIdx(a,b,c);
	}

	if( VtxDUV1::FVF == dFVF)
	{
		for(i=0; i<iNvx; ++i)
		{
			VtxDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			((VtxDUV1*)pVtx)[i] = tVtx;
		}
	}

	else if(VtxNDUV1::FVF == dFVF)
	{
		for(i=0; i<iNvx; ++i)
		{
			VtxNDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnUtil_Forming("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %f  %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.n.x, &tVtx.n.y, &tVtx.n.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			tVtx.p *= 0.4f;
			((VtxNDUV1*)pVtx)[i] = tVtx;
		}
	}


	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	m_sTx);
	m_pTx	= TBTX->SelectTx(nM, nS);
	
	return 1;
}



void CMdMsh::Copy(CMdMsh* pRhs)
{
	strcpy(m_sMd, pRhs->GetMdlName());
	strcpy(m_sTx, pRhs->GetMdlTx());

	this->nType= pRhs->nType;
	this->iNix = pRhs->iNix;
	this->iNvx = pRhs->iNvx;

	this->dFVF = pRhs->dFVF;
	this->iVxS = pRhs->iVxS;	

	pIdx	= (VtxIdx*) malloc(iNix * sizeof(VtxIdx));
	pVtx	= malloc(iNvx * iVxS);

	memcpy(pIdx, pRhs->pIdx, iNix * sizeof(VtxIdx));
	memcpy(pVtx, pRhs->pVtx, iNvx * iVxS);
	

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	m_sTx);
	m_pTx = TBTX->SelectTx(nM, nS);
}



void* CMdMsh::GetDev()
{
	return m_pDev;
}