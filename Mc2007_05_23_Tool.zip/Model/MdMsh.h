// Interface for the CLnMd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDMSH_H_
#define _MDMSH_H_


class CMdMsh																	// For Rendering
{
public:
	PDEV		m_pDev;
	INT			nType;															// Model Type

	char		m_sTx[128];
	PDTX		m_pTx;

	char		m_sMd[128];

	INT			iNix	;														// Count Vertex Index
	INT			iNvx	;														// Count Vertex

	DWORD		dFVF	;														// FVF
	INT			iVxS	;														// vertex structure size

	VtxIdx*		pIdx	;														// Vertex Face Index
	void*		pVtx	;														//	VtxD, VtxUV, VtxNUV, VtxNDUV	

public:
	CMdMsh();
	virtual ~CMdMsh();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	
	virtual void	Render();

	INT		Load(char* sFile);
	void	Copy(CMdMsh* pRhs);

public:
	void	SetMdlName(char* sMdl)	{	strcpy(m_sMd, sMdl);	}
	char*	GetMdlName()			{	return m_sMd;			}

	void	SetMdlTx(char* sTx)	{	strcpy(m_sTx, sTx);		}
	char*	GetMdlTx()				{	return m_sTx;			}

	void*	GetDev();
};

#endif