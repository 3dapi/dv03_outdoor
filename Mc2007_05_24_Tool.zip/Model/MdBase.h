// Interface for the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDBASE_H_
#define _MDBASE_H_


class CMdBase : public CLnRen														// Model Base
{
protected:
	PDEV		m_pDev;
	void*		m_pCam;

	void*		m_pMsD;															// Mesh Dest Pointer
	void*		m_pMsS;															// Mesh Source Pointer

public:
	VEC3		m_vcP;															// Position
	VEC3		m_vcS;															// Scale
	MATA		m_mtW;															// World which is mtW = mtT * mtS * mtR

	FLOAT		m_fD;															// Distance from Camera
	FLOAT		fSrtR;															// Z Direction Value
	
	FLOAT		m_fBr;															// Radius of Bounding
	VEC3		m_vcBb;															// bound Box width, Height, depth
	VEC3		m_vcBc;															// bound Box Center
	
public:
	CMdBase();
	virtual ~CMdBase();

	virtual	INT		Create(void* p1)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

public:
	void*	GetMshSrc();
	void	SetMshSrc(void* pMshSrc);

	void*	GetMshDst();
	void	SetMshDst(void* pMshDst);

	void	SetDev(void* pDev);
	void	SetCam(void* pCam);

	VEC3	GetPos();
	void	SetPos(VEC3 pos);
};


typedef std::vector<CMdBase* >	lsMdB;
typedef lsMdB::iterator			itMdB;


#endif