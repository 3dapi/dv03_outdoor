// Interface for the CTbTx class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TBTX_H_
#define _TBTX_H_

struct TbTxS
{
	char	sF[128];															// Tx File
	PDTX	pT;																	// Texture Pointer
	DIMG	gI;
	DWORD	dF;																	// Filter

	TbTxS() : pT(0), dF(0x00FFFFFF){}
	~TbTxS()	{		SAFE_RELEASE(pT);	}
};


struct TbTxM
{
	INT		iN;																	// Number of Sub
	char	sP[128];															// Tx Path
	TbTxS*	pS;
	
	TbTxM() : iN(-1), pS(0) {}
	~TbTxM(){	SAFE_DELETE_ARRAY(	pS	);	}
};



class CTbTx  
{
public:
	PDEV	m_pDev;

	char	m_sV[32];															// version
	INT		m_iN;																// Tx class Number
	TbTxM*	m_pM;																// Tx table
	
public:
	CTbTx();
	virtual ~CTbTx();
	
	INT		Create(void* p1);

	INT		Load(char *sFile);
	void	Destroy();


	INT		TxCreate(INT nM, INT nS, DWORD dwC=0);
	INT		Release	(INT nM, INT nS);

	PDTX	SelectTx(INT nM, INT nS);
	DIMG*	SelectInf(INT nM, INT nS);
	INT		SelectIdx(INT* nM/*Out*/, INT* nS/*Out*/, char* sFile);
	
private:
	void Confirm();
};

#endif
