// Interface for the CLnArch class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNARCH_H_
#define _LNARCH_H_

class CLn	{	public:	virtual ~CLn(){};	};

class CLnBase : public CLn														// Base class
{
public:
	union	{	WORD nI1;	WORD wM;	};
	union	{	WORD nI2;	WORD wS;	};
	union	{	WORD nI3;	WORD wT;	};
	union	{	WORD nI4;	WORD wW;	};

	CLnBase(): nI1(0xFFFF),nI2(0xFFFF),nI3(0xFFFF),nI4(0xFFFF){}

	void SetId(	WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void SetMSTW(WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void	SetM(WORD wV=0xFFFF){	wM = wV;	}
	void	SetS(WORD wV=0xFFFF){	wS = wV;	}
	void	SetT(WORD wV=0xFFFF){	wT = wV;	}
	void	SetW(WORD wV=0xFFFF){	wW = wV;	}

	WORD	GetM()		{	return wM;	}
	WORD	GetS()		{	return wS;	}
	WORD	GetT()		{	return wT;	}
	WORD	GetW()		{	return wW;	}

	WORD	GetId1()	{	return nI1;	}
	WORD	GetId2()	{	return nI2;	}
	WORD	GetId3()	{	return nI3;	}
	WORD	GetId4()	{	return nI4;	}
};


typedef std::vector<CLnBase>	lsBase;
typedef lsBase::iterator		itBase;



class CLnRen : public CLnBase													// Rendering Base class
{
public:
	BOOL	bFm;																// FrameMove
	BOOL	bMv;																// FrameMove �ȿ��� Move?
	BOOL	bUa;																// FrameMove �ȿ��� Animation?

	BOOL	bRn;																// ������ �� ���ΰ�?
	
	CLnRen() : bFm(1), bMv(1), bUa(1), bRn(1){}
	
	void	SetFrm(BOOL _bFm=TRUE)		{	bFm	= _bFm;						}
	BOOL	IsFrm()						{	return bFm;						}

	void	SetFrmMov(BOOL _bMv=TRUE)	{	bMv	= _bMv;	bFm=TRUE;			}
	BOOL	IsFrmMov()					{	return bMv;						}

	void	SetFrmUpA(BOOL _bUa=TRUE)	{	bUa	= _bUa; bFm=TRUE; bMv=TRUE;	}
	BOOL	IsFrmUpA()					{	return bUa;						}

	void	SetRender(BOOL  _bRn=TRUE)	{	bRn	= _bRn;						}
	BOOL	IsRender()					{	return bRn;						}
};


#endif
