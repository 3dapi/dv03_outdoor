// Implementation of the CMpFld class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMpFld::CMpFld()
{
	m_ppLcl 	= NULL;
	m_pLcT		= NULL;

	m_pDev		= NULL;
	m_pPkLc 	= NULL; // Pick Local
	m_bClck 	= FALSE;
}

CMpFld::~CMpFld()
{
	Destroy();
}


INT CMpFld::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	return 1;
}


void CMpFld::Destroy()
{
	SAFE_DELETE(	m_pLcT		);

	if(m_ppLcl)
	{
		for(int z=0; z<m_Inf.iNfZ; ++z)
			SAFE_DELETE_ARRAY(	m_ppLcl[z]	);

		SAFE_DELETE_ARRAY(	m_ppLcl );
	}
}


INT CMpFld::FrameMove()
{
	m_vObj2D.clear();
	m_vObj3D.clear();

	PickField();
	PickLocal();

	if(m_ppLcl)
	{
		for(int z=0; z<m_Inf.iNfZ; ++z)
		{
			for(int x=0; x<m_Inf.iNfX; ++x)
			{
				m_ppLcl[z][x].FrameMove();
			}
		}
	}

	SAFE_FRMOV( m_pLcT	);


	SAFE_UPDATE(this);

	return 1;
}


INT CMpFld::Update()
{
	INT i;
	INT iSize;

	m_vObj.clear();

	iSize = m_vObj2D.size();

	for(i=0; i<iSize; ++i)
		m_vObj.push_back((CMdBase*)m_vObj2D[i]);


	iSize = m_vObj3D.size();

	for(i=0; i<iSize; ++i)
		m_vObj.push_back((CMdBase*)m_vObj3D[i]);

	sort(m_vObj.begin(), m_vObj.end(), TsrtGp<CMdBase* >());


	return 1;
}



void CMpFld::AddObj2D(CMdBill* pMdB)
{
	m_vObj2D.push_back(pMdB);
}


void CMpFld::AddObj3D(CMdSolid* pMdB)
{
	m_vObj3D.push_back(pMdB);
}








INT CMpFld::PickField()
{
	if(!m_ppLcl)
		return 0;

	if(GINPUT->ButtonDn(0))
	{
		m_pPkLc = 0;

		m_vPkLc.clear();

		VEC3 pck;


		for(int z=0; z<m_Inf.iNfZ; ++z)
		{
			for(int x=0; x<m_Inf.iNfX; ++x)
			{
				CMpLcl* pLcl = &m_ppLcl[z][x];

				for(INT i=0; i<pLcl->m_iNi; ++i)
				{
					WORD	a, b, c;

					a = pLcl->m_pIx[i].a;
					b = pLcl->m_pIx[i].b;
					c = pLcl->m_pIx[i].c;

					VEC3	vcPk;
					VEC3	p0 = pLcl->m_pVc[a].p;
					VEC3	p1 = pLcl->m_pVc[b].p;
					VEC3	p2 = pLcl->m_pVc[c].p;
					FLOAT	fD;

					POINT	pt={ GINPUT->GetMousePos().x, GINPUT->GetMousePos().y};
					VEC3	vcRayDir= GCAMGNL->Get3DDir(&pt);
					VEC3	vcCamPos= GCAMGNL->GetCamPos();
					

					if(SUCCEEDED(LnUtil_GetPickPos3D(&vcCamPos, &vcRayDir, vcPk, p0, p1, p2, fD)))
					{
						m_vPkLc.push_back(TlPkT(vcPk, p0, p1, p2, fD));
					}
				}
			}
		}

		if(!m_vPkLc.empty())
		{
			sort(m_vPkLc.begin(), m_vPkLc.end(), TsrtL<TlPkT >());
			m_vcPkLc = m_vPkLc[0].vcPk;
			m_bClck = TRUE;

			INT 	nX, nZ;

			nX = INT(m_vcPkLc.x/m_Inf.iExt);
			nZ = INT(m_vcPkLc.z/m_Inf.iExt);

			if(nX>=0 && nZ>=0)
				m_pPkLc = &m_ppLcl[nZ][nX];
	
		}
	}


	if(GINPUT->ButtonUp(0))
	{
		m_vPkLc.clear();
		m_bClck = FALSE;
		m_pPkLc=0;
		return 1;
	}


	if(m_pPkLc)
		return 1;


	return -1;
}






INT CMpFld::PickLocal()
{
	if(!m_pPkLc)
		return 1;

	if(m_bClck && GMAIN->m_Wrk.IsHeight())
	{
		INT x, z, k;

		INT 	iFlat= GMAIN->m_Wrk.IsFlat();
		INT 	iRng= GMAIN->m_Wrk.GetRng(); 							// Radius
		INT 	bAc = GMAIN->m_Wrk.m_bAc;
		FLOAT	fH	= iFlat * fabsf(GMAIN->m_Wrk.m_fDH);
		FLOAT	fDH = fabsf(GMAIN->m_Wrk.m_fDH) * GMAIN->m_Wrk.GetDirection();

		std::vector<Vec3T>	vVtxT;

		for(z=0; z<m_Inf.iNfZ; ++z)
		{
			for(x=0; x<m_Inf.iNfX; ++x)
			{
				for(k=0; k<m_ppLcl[z][x].m_iNv; ++k)
				{
					VEC3	pVc = m_vcPkLc - m_ppLcl[z][x].m_pVc[k].p;
					INT 	iRT = INT(sqrtf(pVc.x * pVc.x + pVc.z * pVc.z)/m_ppLcl[z][x].m_iWx);

					if( iRT<iRng)
					{
						vVtxT.push_back(Vec3T(z, x, k, m_ppLcl[z][x].m_pVc[k].p));
					}
				}

			}
		}

		int iSize = vVtxT.size();

		for(k=0; k<iSize; ++k)
		{
			FLOAT	xSq;
			VEC3	pVc = m_vcPkLc - vVtxT[k].p;

			xSq = pVc.x * pVc.x + pVc.z * pVc.z;

			xSq /=(m_pPkLc->m_iWx * m_pPkLc->m_iWx * iRng*iRng*0.25);
			fH = fDH * expf( -xSq);

			INT Z = vVtxT[k].iZ;
			INT X = vVtxT[k].iX;
			INT K = vVtxT[k].iK;

			m_ppLcl[Z][X].m_pVc[K].p.y += fH;

			if(bAc)
			{
				int idx = Z * m_ppLcl[Z][X].m_iNx + X;
				m_ppLcl[Z][X].SetDiffuse(K);
			}
		}


		for(z=0; z<m_Inf.iNfZ; ++z)
		{
			for(x=0; x<m_Inf.iNfX; ++x)
			{
				INT Z = vVtxT[k].iZ;
				INT X = vVtxT[k].iX;
				INT K = vVtxT[k].iK;

				m_ppLcl[z][x].SetNormal();

				if(m_ppLcl[z][x].m_pMdb2D)
					m_ppLcl[z][x].m_pMdb2D->SetHeight();

				if(m_ppLcl[z][x].m_pMdb3D)
					m_ppLcl[z][x].m_pMdb3D->SetHeight();
			}
		}

	}


	if(m_bClck && GMAIN->m_Wrk.UseSpoid())
	{
		INT 	nIdxZ = INT((-m_pPkLc->m_vcP.z + m_vcPkLc.z+0.5F*m_pPkLc->m_iWx)/ m_pPkLc->m_iWx);
		INT 	nIdxX = INT((-m_pPkLc->m_vcP.x + m_vcPkLc.x+0.5F*m_pPkLc->m_iWx)/ m_pPkLc->m_iWx);

		DWORD color = m_pPkLc->m_pVc[nIdxZ * m_pPkLc->m_iNx + nIdxX].d;

		GMAIN->m_Wrk.SetColor(color);
	}


	if(m_bClck && GMAIN->m_Wrk.UseBrush())
	{
		// ��ŷ ������: m_vcPkLc
		INT		z1=0;
		INT		x1=0;
		INT		z2=0;
		INT		x2=0;

		INT 	iRng= GMAIN->m_Wrk.GetRng();
		DWORD	dC	= GMAIN->m_Wrk.GetColor();

		FLOAT	fWidth = iRng * m_pPkLc->m_iWx;

		VEC3	vcLclMin(m_vcPkLc.x - fWidth, 0, m_vcPkLc.z - fWidth);
		VEC3	vcLclMax(m_vcPkLc.x + fWidth, 0, m_vcPkLc.z + fWidth);

		INT		nLclBgnX = INT(vcLclMin.x/m_Inf.iExt);
		INT		nLclBgnZ = INT(vcLclMin.z/m_Inf.iExt);

		INT		nLclEndX = INT(vcLclMax.x/m_Inf.iExt);
		INT		nLclEndZ = INT(vcLclMax.z/m_Inf.iExt);


		if(nLclBgnZ<0)
			nLclBgnZ = 0;

		if(nLclBgnX<0)
			nLclBgnX = 0;

		if(nLclBgnZ>=m_Inf.iNfZ)
			nLclBgnZ = m_Inf.iNfZ-1;

		if(nLclBgnX>=m_Inf.iNfX)
			nLclBgnX = m_Inf.iNfX-1;


		if(nLclEndZ<0)
			nLclEndZ = 0;

		if(nLclEndX<0)
			nLclEndX = 0;

		if(nLclEndZ>=m_Inf.iNfZ)
			nLclEndZ = m_Inf.iNfZ-1;

		if(nLclEndX>=m_Inf.iNfX)
			nLclEndX = m_Inf.iNfX-1;


		for(z1=nLclBgnZ; z1<=nLclEndZ; ++z1)
		{
			for(x1=nLclBgnX; x1<=nLclEndX; ++x1)
			{
				CMpLcl* pLcl = &m_ppLcl[z1][x1];

				INT 	nIdxZ = INT((-pLcl->m_vcP.z + m_vcPkLc.z+0.5F*pLcl->m_iWx)/ pLcl->m_iWx);
				INT 	nIdxX = INT((-pLcl->m_vcP.x + m_vcPkLc.x+0.5F*pLcl->m_iWx)/ pLcl->m_iWx);

				int 	nIdxBgnZ = nIdxZ-iRng;
				int 	nIdxBgnX = nIdxX-iRng;

				int 	nIdxEndZ = nIdxZ+iRng;
				int 	nIdxEndX = nIdxX+iRng;

				if(nIdxBgnZ<0)
					nIdxBgnZ = 0;

				if(nIdxBgnX<0)
					nIdxBgnX = 0;

				if(nIdxEndZ>=pLcl->m_iNx)
					nIdxEndZ = pLcl->m_iNx;

				if(nIdxEndX>=pLcl->m_iNx)
					nIdxEndX = pLcl->m_iNx;


				for(z2= nIdxBgnZ; z2<nIdxEndZ; ++z2)
				{
					for(x2= nIdxBgnX; x2<nIdxEndX; ++x2)
					{
						int idx = z2 * pLcl->m_iNx + x2;

						int r = (x2-nIdxX) * (x2-nIdxX) + (z2-nIdxZ) * (z2-nIdxZ) - (iRng * iRng);

						if(r>0)
							continue;

						pLcl->m_pVc[idx].d = dC;
					}
				}

				pLcl->SetTileIdx();
			}

		}


	}

	CMdBase* pMdB= GMAIN->m_Wrk.GetMdB();

	if(m_bClck && GMAIN->m_Wrk.UseMdB() && pMdB)
	{
		m_bClck = FALSE;

		WORD nI1 = pMdB->GetId1();
		WORD nI2 = pMdB->GetId2();
		WORD nI3 = pMdB->GetId3();


		if( nI1 == 0)															// Ǯ
		{
			CMdBill*	p3d = (CMdBill*)pMdB;
			INT 	nLst= GMAIN->m_Wrk.GetLstIdx();
			VEC3	pos = m_vcPkLc;

			m_pPkLc->m_pMdb2D->AddObj(p3d, pos);

			if(m_pPkLc->m_pMdb2D)
				m_pPkLc->m_pMdb2D->SetHeight();
		}


		if( nI1 == 1)															// 3D Tree
		{
			CMdSolid*	p3d = (CMdSolid*)pMdB;
			INT 	nLst= GMAIN->m_Wrk.GetLstIdx();
			VEC3	pos = m_vcPkLc;

			m_pPkLc->m_pMdb3D->AddObj(p3d, pos);

			if(m_pPkLc->m_pMdb3D)
				m_pPkLc->m_pMdb3D->SetHeight();
		}

	}



	if(m_bClck && GMAIN->m_Wrk.UseTile())
	{
		// ��ŷ ������: m_vcPkLc
		INT		z1=0;
		INT		x1=0;
		INT		z2=0;
		INT		x2=0;

		INT 	nTile = GMAIN->m_Wrk.m_WndLyr.GetDstIdx();
		INT 	iRng= GMAIN->m_Wrk.GetRng();
		DWORD	dC	= GMAIN->m_Wrk.GetColor();

		FLOAT	fWidth = iRng * m_pPkLc->m_iWx;

		VEC3	vcLclMin(m_vcPkLc.x - fWidth, 0, m_vcPkLc.z - fWidth);
		VEC3	vcLclMax(m_vcPkLc.x + fWidth, 0, m_vcPkLc.z + fWidth);

		INT		nLclBgnX = INT(vcLclMin.x/m_Inf.iExt);
		INT		nLclBgnZ = INT(vcLclMin.z/m_Inf.iExt);

		INT		nLclEndX = INT(vcLclMax.x/m_Inf.iExt);
		INT		nLclEndZ = INT(vcLclMax.z/m_Inf.iExt);


		if(nLclBgnZ<0)
			nLclBgnZ = 0;

		if(nLclBgnX<0)
			nLclBgnX = 0;

		if(nLclBgnZ>=m_Inf.iNfZ)
			nLclBgnZ = m_Inf.iNfZ-1;

		if(nLclBgnX>=m_Inf.iNfX)
			nLclBgnX = m_Inf.iNfX-1;


		if(nLclEndZ<0)
			nLclEndZ = 0;

		if(nLclEndX<0)
			nLclEndX = 0;

		if(nLclEndZ>=m_Inf.iNfZ)
			nLclEndZ = m_Inf.iNfZ-1;

		if(nLclEndX>=m_Inf.iNfX)
			nLclEndX = m_Inf.iNfX-1;


		for(z1=nLclBgnZ; z1<=nLclEndZ; ++z1)
		{
			for(x1=nLclBgnX; x1<=nLclEndX; ++x1)
			{
				CMpLcl* pLcl = &m_ppLcl[z1][x1];

				INT 	nIdxZ = INT((-pLcl->m_vcP.z + m_vcPkLc.z+0.5F*pLcl->m_iWx)/ pLcl->m_iWx);
				INT 	nIdxX = INT((-pLcl->m_vcP.x + m_vcPkLc.x+0.5F*pLcl->m_iWx)/ pLcl->m_iWx);

				int 	nIdxBgnZ = nIdxZ-iRng;
				int 	nIdxBgnX = nIdxX-iRng;

				int 	nIdxEndZ = nIdxZ+iRng;
				int 	nIdxEndX = nIdxX+iRng;

				if(nIdxBgnZ<0)
					nIdxBgnZ = 0;

				if(nIdxBgnX<0)
					nIdxBgnX = 0;

				if(nIdxEndZ>=pLcl->m_iNx)
					nIdxEndZ = pLcl->m_iNx;

				if(nIdxEndX>=pLcl->m_iNx)
					nIdxEndX = pLcl->m_iNx;


				for(z2= nIdxBgnZ; z2<nIdxEndZ; ++z2)
				{
					for(x2= nIdxBgnX; x2<nIdxEndX; ++x2)
					{
						int idx = z2 * pLcl->m_iNx + x2;

						int r = (x2-nIdxX) * (x2-nIdxX) + (z2-nIdxZ) * (z2-nIdxZ) - (iRng * iRng);

						if(r>0)
							continue;

						pLcl->m_pTxI[idx] = nTile;
					}
				}

				pLcl->SetTileIdx();
			}

		}


	}
		


	return 1;
}


void CMpFld::Render()
{
	INT iSize;
	INT i;
	INT x, z;

	LnUtil_SetWorldIdentity(m_pDev);

	m_pDev->SetRenderState( D3DRS_LIGHTING,	GMAIN->m_bMnLgt);
	m_pDev->SetRenderState(D3DRS_FOGENABLE,	GMAIN->m_bMnFog);
	m_pDev->SetRenderState( D3DRS_FILLMODE,	GMAIN->m_bMnFill);
	m_pDev->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);



	if(GMAIN->m_bMnLgt)
	{
		for(int i=0; i<7; ++i)
			m_pDev->LightEnable( i, FALSE);

		for(i=0; i<m_Env.m_iNl; ++i)
		{
			m_pDev->SetLight( i, &m_Env.m_pLg[i] );
			m_pDev->LightEnable( i, TRUE );
		}

		m_pDev->SetRenderState( D3DRS_AMBIENT, m_Env.m_dAb);					// Set Ambient
		m_pDev->SetMaterial( &m_Env.m_Mtl.m );									// Set Material
	}
	

	m_pDev->SetRenderState(D3DRS_FOGTABLEMODE, m_Env.m_dFt);
	m_pDev->SetRenderState(D3DRS_FOGCOLOR, m_Env.m_dFc);						// Set Fog
	m_pDev->SetRenderState(D3DRS_FOGSTART,		LnUtil_FtoDW(m_Env.m_fFb));
	m_pDev->SetRenderState(D3DRS_FOGEND,		LnUtil_FtoDW(m_Env.m_fFe));
	m_pDev->SetRenderState(D3DRS_FOGDENSITY,	LnUtil_FtoDW(m_Env.m_fFd));


	if(m_ppLcl)
	{
		if(GMAIN->m_bMnLcl)
		{
			for(z=0; z<m_Inf.iNfZ; ++z)
			{
				for(x=0; x<m_Inf.iNfX; ++x)
				{
					m_ppLcl[z][x].RenderTline();								// Render Block Line
				}
			}
		}


		for(z=0; z<m_Inf.iNfZ; ++z)
		{
			for(x=0; x<m_Inf.iNfX; ++x)
			{
				m_ppLcl[z][x].RenderLcl();

			}
		}
	}

	if(m_pLcT)
		m_pLcT->RenderLcl();




	iSize = m_vObj.size();

	for(i=0; i<iSize; ++i)
	{
		CMdBase* pMdB = m_vObj[i];

		if(GMAIN->m_bMnBndBox)
			pMdB->BndBoxRender();
		
		pMdB->Render();
	}
}



void CMpFld::RenderPck()
{
	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetRenderState( D3DRS_LIGHTING,	FALSE);
	m_pDev->SetRenderState(D3DRS_FOGENABLE,	FALSE);
	m_pDev->SetRenderState( D3DRS_FILLMODE,	D3DFILL_SOLID);
	m_pDev->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

	if(!m_vPkLc.empty())
	{
		VtxD	pVtx[3];

		pVtx[0].p = m_vPkLc[0].p0;
		pVtx[1].p = m_vPkLc[0].p1;
		pVtx[2].p = m_vPkLc[0].p2;

		pVtx[0].d = 0x9988AAFF;
		pVtx[1].d = 0x9988AAFF;
		pVtx[2].d = 0x9988AAFF;

		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
		m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCCOLOR);
		m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTCOLOR);

		m_pDev->SetRenderState(D3DRS_FOGENABLE,	FALSE);
		m_pDev->SetRenderState( D3DRS_FILLMODE,	D3DFILL_SOLID);
		m_pDev->SetRenderState( D3DRS_CULLMODE,	D3DCULL_NONE);

		m_pDev->SetTexture(0, 0);
		m_pDev->SetFVF(VtxD::FVF);
		m_pDev->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 1, pVtx, sizeof(VtxD));

		m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	}

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}



void CMpFld::CreateFld(CHAR* sN, INT iNfX, INT iNfZ, INT iExt, BOOL bAll, INT iNx, INT iWx, FLOAT fUV)
{
	DMTL	Mtrl;
	DWORD	dAmLgt;

	INT 	iNl;
	DLGT*	pLgt;

	DWORD	dFt;
	DWORD	dFc;
	FLOAT	fFb;
	FLOAT	fFe;
	FLOAT	fFd;


	if(m_ppLcl)
	{
		for(int z=0; z<m_Inf.iNfZ; ++z)
			SAFE_DELETE_ARRAY(	m_ppLcl[z]	);

		SAFE_DELETE_ARRAY(	m_ppLcl );
	}


	Mtrl	= GMAIN->m_Wrk.m_WndMtrl.GetMtrl();
	dAmLgt	= GMAIN->m_Wrk.m_WndMtrl.GetAmLgt();

	iNl 	= GMAIN->m_Wrk.m_WndLght.GetLgtCnt();
	pLgt	= GMAIN->m_Wrk.m_WndLght.GetLgtPnt();

	dFt 	= GMAIN->m_Wrk.m_WndFog.GetFogTable();
	dFc 	= GMAIN->m_Wrk.m_WndFog.GetFogColor();
	fFb 	= GMAIN->m_Wrk.m_WndFog.GetFogBegin();
	fFe 	= GMAIN->m_Wrk.m_WndFog.GetFogEnd  ();
	fFd 	= GMAIN->m_Wrk.m_WndFog.GetFogDns  ();

	strcpy(m_Inf.sN, sN);
	m_Inf.iNfX	= iNfX;
	m_Inf.iNfZ	= iNfZ;

	m_Inf.iExt	= iExt;

	m_ppLcl 	= new CMpLcl*[iNfZ];

	for(int z=0; z<iNfZ; ++z)
	{
		m_ppLcl[z] = new CMpLcl[iNfX];

		for(int x=0; x<iNfX; ++x)
		{
			VEC3	pos = VEC3( x * m_Inf.iExt, 0, z * m_Inf.iExt);

			m_ppLcl[z][x].Create(m_pDev);
			m_ppLcl[z][x].SetPos(pos);
			m_ppLcl[z][x].CreateMesh(iNx+1, iWx, fUV);

			SetTx(&m_ppLcl[z][x]);
		}
	}

}



INT CMpFld::CreateLcl(INT iNx, INT iWx, FLOAT fUV, VEC3 pos)
{
	DMTL	Mtrl	= GMAIN->m_Wrk.m_WndMtrl.GetMtrl();
	DWORD	dAmLgt	= GMAIN->m_Wrk.m_WndMtrl.GetAmLgt();

	INT 	iNl 	= GMAIN->m_Wrk.m_WndLght.GetLgtCnt();
	DLGT*	pLgt	= GMAIN->m_Wrk.m_WndLght.GetLgtPnt();

	DWORD	dFt 	= GMAIN->m_Wrk.m_WndFog.GetFogTable();
	DWORD	dFc 	= GMAIN->m_Wrk.m_WndFog.GetFogColor();
	FLOAT	fFb 	= GMAIN->m_Wrk.m_WndFog.GetFogBegin();
	FLOAT	fFe 	= GMAIN->m_Wrk.m_WndFog.GetFogEnd  ();
	FLOAT	fFd 	= GMAIN->m_Wrk.m_WndFog.GetFogDns  ();


	SAFE_DELETE(	m_pLcT	);
	SAFE_NEWCREATE1(m_pLcT, CMpLcl, m_pDev);

	m_pLcT->SetPos(pos);
	m_pLcT->CreateMesh(iNx+1, iWx, fUV);

	SetTx(m_pLcT);

	return 1;
}



void CMpFld::SetTx(CMpLcl* pLcl)
{
	char	sBase[MAX_PATH];

	INT iSize = GMAIN->m_Wrk.m_WndLyr.GetSizeDst();

	for(int i=0; i<iSize; ++i)
	{
		if(GMAIN->m_Wrk.m_WndLyr.GetStrDst(i))
		{
			strcpy(sBase, GMAIN->m_Wrk.m_WndLyr.GetStrDst(i));

			pLcl->LyrAdd(sBase);
		}
	}
}



INT CMpFld::FileLoad()
{
	FILE*			fp;

	char			sBuf[128];
	INT 			x, z, i=0, j=0;
	INT 			iSize=0, jSize=0;

	char			sDir[MAX_PATH]="\0";
	OPENFILENAME	OFN;
	char			sF[MAX_PATH];
	char			sFullF[MAX_PATH]="";

	GetCurrentDirectory(MAX_PATH, sDir);

	memset(&OFN, 0, sizeof(OFN));
	OFN.lStructSize 	= sizeof(OFN);
	OFN.hwndOwner		= GHWND;
	OFN.lpstrFilter 	="Field Files(*.bod)\0*.bod\0All Files(*.*)\0*.*\0";
	OFN.lpstrFile		=sFullF;
	OFN.nMaxFile		=MAX_PATH;

	OFN.lpstrTitle		="Filed Open...";
	OFN.lpstrFileTitle	=sF;
	OFN.nMaxFileTitle	=MAX_PATH;
	OFN.lpstrDefExt 	="bod";
	OFN.lpstrInitialDir =sDir;

	if( !GetOpenFileName(&OFN))
	{
		SetCurrentDirectory(sDir);
		return 0;
	}

	SetCurrentDirectory(sDir);

	if(NULL ==(fp = fopen(sFullF, "rb")))
		return 0;


	if(m_ppLcl)
	{
		for(int z=0; z<m_Inf.iNfZ; ++z)
			SAFE_DELETE_ARRAY(	m_ppLcl[z]	);

		SAFE_DELETE_ARRAY(	m_ppLcl );
	}

	if(m_Env.m_pLg)
		SAFE_DELETE_ARRAY(	m_Env.m_pLg	);


	fread(&m_Inf, 1, sizeof(m_Inf), fp);

	
	m_ppLcl 	= new CMpLcl*[m_Inf.iNfZ];

	for(z=0; z<m_Inf.iNfZ; ++z)
	{
		m_ppLcl[z] = new CMpLcl[m_Inf.iNfX];
		
		for(x=0; x<m_Inf.iNfX; ++x)
			m_ppLcl[z][x].Create(m_pDev);
	}


	fread(&m_Env.m_dAb,	1, sizeof(m_Env.m_dAb), fp); 					// Ambient color
	fread(&m_Env.m_Mtl,	1, sizeof(m_Env.m_Mtl), fp); 					// Material

	fread(&m_Env.m_dFt,	1, sizeof(m_Env.m_dFt), fp); 					// Fog Table Mode
	fread(&m_Env.m_dFc,	1, sizeof(m_Env.m_dFc), fp); 					// Fog Color
	fread(&m_Env.m_fFb,	1, sizeof(m_Env.m_fFb), fp); 					// Fog Begin
	fread(&m_Env.m_fFe,	1, sizeof(m_Env.m_fFe), fp); 					// Fog End
	fread(&m_Env.m_fFd,	1, sizeof(m_Env.m_fFd), fp); 					// fog Density

	fread(&m_Env.m_iNl,	1, sizeof(m_Env.m_iNl), fp); 					// Lighting Num

	if(m_Env.m_iNl)
	{
		m_Env.m_pLg = new DLGT[m_Env.m_iNl];
		fread(m_Env.m_pLg, m_Env.m_iNl, sizeof(DLGT), fp);					// Lighting
	}


	for(z=0; z<m_Inf.iNfZ; ++z)
	{
		for(x=0; x<m_Inf.iNfX; ++x)
		{
			CMpLcl* pLc = &m_ppLcl[z][x];

			fread(&pLc->m_sN,	1, sizeof(pLc->m_sN),	fp);					// Map Name
			fread(&pLc->m_mtW,	1, sizeof(pLc->m_mtW),	fp);					// World Matrix
			fread(&pLc->m_vcP,	1, sizeof(pLc->m_vcP),	fp);					// Position

			
			// Mesh
			fread(&pLc->m_iNx,	1, sizeof(pLc->m_iNx), fp); 					// Number of tile for Width
			fread(&pLc->m_iWx,	1, sizeof(pLc->m_iWx), fp); 					// Width of tile for x;
			fread(&pLc->m_iVs,	1, sizeof(pLc->m_iVs), fp); 					// Vertex Size
			fread(&pLc->m_FVF,	1, sizeof(pLc->m_FVF), fp);
			fread(&pLc->m_fUV,	1, sizeof(pLc->m_fUV), fp); 					// UV Width
			fread(&pLc->m_iNi,	1, sizeof(pLc->m_iNi), fp); 					// Index Number
			fread(&pLc->m_iNv,	1, sizeof(pLc->m_iNv), fp); 					// Vertex Number

			pLc->m_pIx	= new VtxIdx  [pLc->m_iNi];
			pLc->m_pVc	= new VtxNDUV1[pLc->m_iNv];
			fread(pLc->m_pIx, pLc->m_iNi, sizeof(VtxIdx), fp);
			fread(pLc->m_pVc, pLc->m_iNv, sizeof(VtxNDUV1), fp);





			// Tiling
			pLc->m_pTxI = new BYTE[pLc->m_iNv];
			fread(pLc->m_pTxI, pLc->m_iNv, sizeof(BYTE), fp);

			fread(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				memset(sBuf, 0, sizeof(sBuf));
				fread(sBuf, 1, sizeof(sBuf), fp);

				pLc->m_vTxN.push_back(sBuf);
			}


			fread(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				INT nM=-1, nS=-1;
				CMpLcl::MpTlTx*	pTd = new CMpLcl::MpTlTx;
				BYTE*			pTw = new BYTE[pLc->m_iNv];

				fread(pTw, pLc->m_iNv, sizeof(BYTE), fp);

				TBTX->SelectIdx(&nM, &nS,	(char*)pLc->m_vTxN[i].c_str());
				pTd->pTx = TBTX->SelectTx(nM, nS);
				pTd->pTw = pTw;

				pLc->m_vTxL.push_back(pTd);
			}



			WORD	nI1;
			WORD	nI2;
			WORD	nI3;
			WORD	nI4;

			VEC3	pos;
			MATA	mtW;
			char	sMd[128];



			// Object List 2D
			fread(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				fread(&nI1,	 1, sizeof(nI1), fp);
				fread(&nI2,	 1, sizeof(nI2), fp);
				fread(&nI3,	 1, sizeof(nI3), fp);
				fread(&nI4,	 1, sizeof(nI4), fp);
				fread(&mtW,	 1, sizeof(mtW), fp);
				fread(sMd,	 1, sizeof(sMd), fp);

				pos	= VEC3(mtW._41, mtW._42, mtW._43);

				INT nM=-1, nS=-1;

				if(SUCCEEDED(TBMDB->SelectIdx(&nM, &nS, sMd)))
				{
					CMdBill*	pMdB = NULL;
					CMdMsh*		pSrc = TBMDB->SelectMdB(nM, nS);

					_SAFE_NEWCREATE1( pMdB, CMdBill, m_pDev);

					pMdB->SetMshSrc(pSrc);
					pMdB->SetPos(pos);
					pMdB->SetCam(GCAMGNL);

					pLc->m_pMdb2D->m_vObj.push_back(pMdB);
				}
			}


			// Object List 3D
			fread(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				fread(&nI1,	 1, sizeof(nI1), fp);
				fread(&nI2,	 1, sizeof(nI2), fp);
				fread(&nI3,	 1, sizeof(nI3), fp);
				fread(&nI4,	 1, sizeof(nI4), fp);
				fread(&mtW,	 1, sizeof(mtW), fp);
				fread(sMd,	 1, sizeof(sMd), fp);

				pos	= VEC3(mtW._41, mtW._42, mtW._43);

				INT nM=-1, nS=-1;

				if(SUCCEEDED(TBMDB->SelectIdx(&nM, &nS, sMd)))
				{
					CMdMsh*		pSrc = TBMDB->SelectMdB(nM, nS);
					CMdSolid*	pMdB = NULL;
					_SAFE_NEWCREATE1(pMdB, CMdSolid, m_pDev);

					pMdB->SetMshSrc(pSrc);
					pMdB->SetPos(pos);
					pMdB->SetCam(GCAMGNL);
					pMdB->SetBndInf(pSrc->GetBndInf());

					pLc->m_pMdb3D->m_vObj.push_back(pMdB);
				}
			}
		}
	}

	fclose(fp);

	return 1;
}


INT CMpFld::FileSave()
{
	FILE*			fp;

	char			sBuf[128];
	INT 			x, z, i=0, j=0;
	INT 			iSize=0, jSize=0;

	char			sDir[MAX_PATH]="\0";
	OPENFILENAME	OFN;
	char			sF[MAX_PATH];
	char			sFullF[MAX_PATH]="";

	if(!m_ppLcl)
		return 0;

	GetCurrentDirectory(MAX_PATH, sDir);

	memset(&OFN, 0, sizeof(OFN));
	OFN.lStructSize 	= sizeof(OFN);
	OFN.hwndOwner		= GHWND;
	OFN.lpstrFilter 	="Field Files(*.bod)\0*.bod\0All Files(*.*)\0*.*\0";
	OFN.lpstrFile		=sFullF;
	OFN.nMaxFile		=MAX_PATH;

	OFN.lpstrTitle		="Filed Save...";
	OFN.lpstrFileTitle	=sF;
	OFN.nMaxFileTitle	=MAX_PATH;
	OFN.lpstrDefExt 	="bod";
	OFN.lpstrInitialDir =sDir;

	if( !GetOpenFileName(&OFN))
	{
		SetCurrentDirectory(sDir);
		return 0;
	}

	SetCurrentDirectory(sDir);

	fp = fopen(sFullF, "wb");

	fwrite(&m_Inf, 1, sizeof(m_Inf), fp);


	fwrite(&m_Env.m_dAb, 1, sizeof(m_Env.m_dAb), fp); 					// Ambient color
	fwrite(&m_Env.m_Mtl, 1, sizeof(m_Env.m_Mtl), fp); 					// Material

	fwrite(&m_Env.m_dFt, 1, sizeof(m_Env.m_dFt), fp); 					// Fog Table Mode
	fwrite(&m_Env.m_dFc, 1, sizeof(m_Env.m_dFc), fp); 					// Fog Color
	fwrite(&m_Env.m_fFb, 1, sizeof(m_Env.m_fFb), fp); 					// Fog Begin
	fwrite(&m_Env.m_fFe, 1, sizeof(m_Env.m_fFe), fp); 					// Fog End
	fwrite(&m_Env.m_fFd, 1, sizeof(m_Env.m_fFd), fp); 					// fog Density

	fwrite(&m_Env.m_iNl, 1, sizeof(m_Env.m_iNl), fp); 					// Lighting Num

	if(m_Env.m_iNl)
	{
		fwrite(m_Env.m_pLg, m_Env.m_iNl, sizeof(DLGT), fp);					// Lighting
	}
	


	for(z=0; z<m_Inf.iNfZ; ++z)
	{
		for(x=0; x<m_Inf.iNfX; ++x)
		{
			CMpLcl* pLc = &m_ppLcl[z][x];

			fwrite(&pLc->m_sN,	1, sizeof(pLc->m_sN),	fp);					// Map Name
			fwrite(&pLc->m_mtW, 1, sizeof(pLc->m_mtW),	fp);					// World Matrix
			fwrite(&pLc->m_vcP, 1, sizeof(pLc->m_vcP),	fp);					// Position

			// Mesh
			fwrite(&pLc->m_iNx, 1, sizeof(pLc->m_iNx), fp); 					// Number of tile for Width
			fwrite(&pLc->m_iWx, 1, sizeof(pLc->m_iWx), fp); 					// Width of tile for x;
			fwrite(&pLc->m_iVs, 1, sizeof(pLc->m_iVs), fp); 					// Vertex Size
			fwrite(&pLc->m_FVF, 1, sizeof(pLc->m_FVF), fp);
			fwrite(&pLc->m_fUV, 1, sizeof(pLc->m_fUV), fp); 					// UV Width
			fwrite(&pLc->m_iNi, 1, sizeof(pLc->m_iNi), fp); 					// Index Number
			fwrite(&pLc->m_iNv, 1, sizeof(pLc->m_iNv), fp); 					// Vertex Number

			fwrite(pLc->m_pIx, pLc->m_iNi, sizeof(VtxIdx), fp);
			fwrite(pLc->m_pVc, pLc->m_iNv, sizeof(VtxNDUV1), fp);





			// Tiling
			fwrite(pLc->m_pTxI, pLc->m_iNv, sizeof(BYTE), fp);

			iSize	= pLc->m_vTxN.size();
			fwrite(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				memset(sBuf, 0, sizeof(sBuf));
				sprintf(sBuf, "%s", pLc->m_vTxN[i].c_str());
				fwrite(sBuf, 1, sizeof(sBuf), fp);
			}

			iSize = pLc->m_vTxL.size();
			fwrite(&iSize, 1, sizeof(INT), fp);


			for(i=0; i<iSize; ++i)
				fwrite(pLc->m_vTxL[i]->pTw, pLc->m_iNv, sizeof(BYTE), fp);





			// Object List 2D
			iSize = pLc->m_pMdb2D->m_vObj.size();
			fwrite(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				CMdBill*	pMdB = pLc->m_pMdb2D->m_vObj[i];
				CMdMsh*		pSrc = (CMdMsh*)pMdB->GetMshSrc();

				memset(sBuf, 0, sizeof(sBuf));
				sprintf(sBuf, "%s", pSrc->GetMdlName());

				fwrite(&pMdB->nI1,	 1, sizeof(pMdB->nI1), fp);
				fwrite(&pMdB->nI2,	 1, sizeof(pMdB->nI2), fp);
				fwrite(&pMdB->nI3,	 1, sizeof(pMdB->nI3), fp);
				fwrite(&pMdB->nI4,	 1, sizeof(pMdB->nI4), fp);
				fwrite(&pMdB->m_mtW, 1, sizeof(pMdB->m_mtW), fp);
				fwrite(sBuf,  1, sizeof(sBuf), fp);
			}


			// Object List 3D
			iSize = pLc->m_pMdb3D->m_vObj.size();
			fwrite(&iSize, 1, sizeof(INT), fp);

			for(i=0; i<iSize; ++i)
			{
				CMdSolid*	pMdB = pLc->m_pMdb3D->m_vObj[i];
				CMdMsh*		pSrc = (CMdMsh*)pMdB->GetMshSrc();

				memset(sBuf, 0, sizeof(sBuf));
				sprintf(sBuf, "%s", pSrc->GetMdlName());

				fwrite(&pMdB->nI1,	 1, sizeof(pMdB->nI1), fp);
				fwrite(&pMdB->nI2,	 1, sizeof(pMdB->nI2), fp);
				fwrite(&pMdB->nI3,	 1, sizeof(pMdB->nI3), fp);
				fwrite(&pMdB->nI4,	 1, sizeof(pMdB->nI4), fp);
				fwrite(&pMdB->m_mtW, 1, sizeof(pMdB->m_mtW), fp);
				fwrite(sBuf,  1, sizeof(sBuf), fp);
			}
		}
	}


	fclose(fp);

	return 1;
}





















void CMpFld::SetMaterial(DMTL& mtrl)
{
	memcpy( &m_Env.m_Mtl, &mtrl, sizeof(DMTL) );
}


void CMpFld::SetAmbientLight(DWORD& dAmLgt)
{
	m_Env.m_dAb	= dAmLgt;
}



void CMpFld::SetLight(DLGT* pLgt, INT iSize)
{
	SAFE_DELETE_ARRAY(	m_Env.m_pLg	);
	
	m_Env.m_iNl = iSize;
	m_Env.m_pLg = new DLGT[iSize];

	memcpy(m_Env.m_pLg, pLgt, sizeof(DLGT)*iSize );	
}



void CMpFld::SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns)
{
	m_Env.m_dFt	= dT;
	m_Env.m_dFc	= dC;
	m_Env.m_fFb	= fBgn;
	m_Env.m_fFe = fEnd;
	m_Env.m_fFd	= fDns;
}