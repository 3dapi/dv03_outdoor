// Interface for the CMpLcl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPLCL_H_
#define _MPLCL_H_


class CMpLcl																	// Mesh
{
public:
	struct MpTlTx
	{
		PDTX	pTx;																// Texture
		BYTE*	pTw;																// Layer Weight constructed by Alpha
		
		MpTlTx() : pTx(0), pTw(0){}
		
		void	Destroy()	{	SAFE_DELETE_ARRAY(	pTw	);	}
		~MpTlTx()			{	Destroy();			}
	};

	typedef std::vector<MpTlTx* >	lsMcTd;
	typedef lsMcTd::iterator		itMcTd;

public:
	// Map info
	char		m_sN[128];														// Map Name
	MATA		m_mtW;															// World Matrix
	VEC3		m_vcP;															// Position
	
	// Mesh
	INT			m_iNx;															// Number of tile for Width
	INT			m_iWx;															// Width of tile for x;
	INT			m_iVs;															// Vertex Size
	DWORD		m_FVF;
	FLOAT		m_fUV;															// UV Width
	INT			m_iNi;															// Index Number
	INT			m_iNv;															// Vertex Number
	VtxIdx*		m_pIx;
	VtxNDUV1*	m_pVc;
	
	// Tiling Texture
	BYTE*		m_pTxI;															// Texture Index Weight, it is Layer Index
	lsStr		m_vTxN;															// Texture Tiling Name List
	lsMcTd		m_vTxL;
	
	
	// Element List
	CMdPack2D*	m_pMdb2D;														// 2D Model Pack
	CMdPack3D*	m_pMdb3D;														// 3D Model Pack

protected:
	PDEV		m_pDev;
	
public:
	CMpLcl();
	virtual ~CMpLcl();
	
	INT		Create(void* p1);
	void	Destroy();
	
	INT		FrameMove();
	
	void	RenderLcl();
	void	RenderObj();
	
	void	RenderTline();														// Show Block
	
	void	SetPos(VEC3	pos)		{	m_vcP = pos	;	}
	VEC3	GetPos()				{	return m_vcP;	}
	FLOAT	GetHeight(VEC3& pos);
	
	void	CreateMesh(INT iNx, INT iWx, FLOAT fUV);
	INT		GetNx()					{	return m_iNx;	}
	INT		GetWx()					{	return m_iWx;	}
	
	void	SetNormal();
	void	SetIndex();
	VEC3	NormalVec(int z, int x);
	
	void	SetDiffuse(int nIdx=-1);
	
	void	LyrAdd(char* sTx);
	void	SetTileIdx();
	void	SetTiling(int nTx, BYTE* &xpTxA);
};



typedef std::vector<CMpLcl* >	lsLcl;
typedef lsLcl::iterator			itLcl;

#endif