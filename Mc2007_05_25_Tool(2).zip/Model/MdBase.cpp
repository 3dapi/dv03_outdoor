// Implementation of the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdBase::CMdBase()
: m_fD	(0)
, fSrtR	(0)

, m_vcE	(0,0,0)
, m_vcP	(0,0,0)
, m_vcS	(1,1,1)
, m_mtW	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
{
	m_pDev	= NULL;
	m_pCam	= NULL;

	m_pMsD	= NULL;
	m_pMsS	= NULL;
}

CMdBase::~CMdBase()
{
	if(m_pMsD)
	{
		CMdMsh* pMshDst = (CMdMsh*)m_pMsD;
		delete pMshDst;
		m_pMsD = NULL;
	}
}



void CMdBase::BndBoxTransform()
{
	//Transform Bound Box
	CMdMsh*	pMshS = (CMdMsh*)m_pMsS;
	
	for(int i=0; i<8; ++i)
	{
		D3DXVECTOR3  vcSrc = pMshS->m_BndInf.vcEdge[i].p;
		D3DXVECTOR3* vcDst = &(m_BndInf.vcEdge[i].p);
		
		D3DXVec3TransformCoord(vcDst, &vcSrc, &m_mtW);
		*vcDst += m_vcE;
	}
}

void CMdBase::BndBoxRender()
{
	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);
	
	// Render BoundBox
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);

	m_BndInf.RenderBox(m_pDev);

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}





void* CMdBase::GetMshSrc()
{
	return m_pMsS;
}

void CMdBase::SetMshSrc(void* pMshSrc)
{
	m_pMsS = pMshSrc;
}


void* CMdBase::GetMshDst()
{
	return m_pMsD;
}

void CMdBase::SetMshDst(void* pMshDst)
{
	m_pMsD = pMshDst;
}


void CMdBase::SetDev(void* pDev)
{
	m_pDev = (PDEV)pDev;
}

void CMdBase::SetCam(void* pCam)
{
	m_pCam=pCam;
}

VEC3 CMdBase::GetPos()
{
	return m_vcP;
}

void CMdBase::SetPos(VEC3 pos)
{
	m_vcP = pos;
	m_mtW._41 = m_vcP.x;
	m_mtW._42 = m_vcP.y;
	m_mtW._43 = m_vcP.z;
}

void CMdBase::SetBndInf(TBndAABB* pBnd)
{
	memcpy(&m_BndInf, pBnd, sizeof(TBndAABB));

	m_BndInf.SetOwner(this);
}
