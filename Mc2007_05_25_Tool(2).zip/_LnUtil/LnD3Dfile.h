// Interface for the CLnDxMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LNDXMSH_H_
#define _LNDXMSH_H_


class CLnDxMsh
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	char					m_sFile[MAX_PATH];
	LPD3DXMESH				m_pMshSys;			// SysMem mesh, lives through resize
	LPD3DXMESH				m_pMshLcl;			// Local mesh, rebuilt on resize

	DWORD					m_dMtrl;			// Materials Number
	D3DMATERIAL9*			m_pMtrl;
	LPDIRECT3DTEXTURE9*		m_pTxs;
	BOOL					m_bMtrl;

public:
	CLnDxMsh();
	virtual ~CLnDxMsh();

	virtual INT		Create(void* pDev, void* sFile);
	virtual void	Destroy();

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual void	Render(bool bDrawOpaqueSubsets = true, bool bDrawAlphaSubsets = true );


	void	SetFVF(DWORD dFVF);
	void	UseMaterial(bool bVal);
};



#endif


