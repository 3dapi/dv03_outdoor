// Interface for the CWndFld class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDFLD_H_
#define _WNDFLD_H_

class CWndFld
{
public:
	HWND			m_hWnd		;
	HWND			m_hWPrn		;

public:
	CHAR			m_sN[128];													// Name

	INT				m_iNfX;														// Number of Field for X Direction
	INT				m_iNfZ;														// Number of Field for Z Direction
	INT				m_iExt;														// Extent of Local Width

	BOOL			m_bAll;

	INT				m_iNx;														// Number of tile for Width
	INT				m_iWx;														// Width of tile for x;
	FLOAT			m_fUV;
	
public:
	CLSS_DLG_DECLEAR( CWndFld );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	void	ShowWindow(int _ishw = SW_SHOW);
};

#endif