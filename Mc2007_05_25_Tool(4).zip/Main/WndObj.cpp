// Implementation of the CWndObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndObj, MsgPrc);


INT CWndObj::Init()
{
	m_hWnd	= 0;
	m_hWPrn	= 0;

	m_pObj	= NULL;

	memset( &m_vcR, 0, sizeof m_vcR);
	memset( &m_vcS, 0, sizeof m_vcS);
	memset( &m_vcT, 0, sizeof m_vcT);

	return 1;
}


INT CWndObj::Create(HWND hWnd)
{
	if(m_hWnd)
		return 1;

	if(!GFIELD)
		return 1;

	m_pObj = GFIELD->GetPckObj();

	if(!m_pObj)
		return -1;


	CMdBase* pObj = (CMdBase*)m_pObj;
	CMdMsh*  pSrc = (CMdMsh* )pObj->GetMshSrc();


	m_hWPrn= hWnd;
	HINSTANCE hInst = GetModuleHandle(NULL);
	m_hWnd = CreateDialog(hInst,MAKEINTRESOURCE(IDD_OBJ), m_hWPrn, CLSS_DLG_WNDPROC(CWndObj));

	RECT	rt1;
	RECT	rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(m_hWPrn, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left + 5;
	iY = rt1.top  + 45;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);
	::ShowWindow(m_hWnd, SW_SHOW);


	char sBuf[32]={0};
	sprintf(sBuf, "0x%x" , pObj);

	SetDlgItemText(m_hWnd, IDC_OBJ_ID, sBuf);
	SetDlgItemText(m_hWnd, IDC_OBJ_NAME, pSrc->GetMdlName());

	m_vcR = pObj->GetRot();
	m_vcS = pObj->GetScl();
	m_vcT = pObj->GetPos();

	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_X, m_vcR.x);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Y, m_vcR.y);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Z, m_vcR.z);

	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_X, m_vcS.x);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Y, m_vcS.y);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Z, m_vcS.z);

	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_X, m_vcT.x);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Y, m_vcT.y);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Z, m_vcT.z);

	return 1;
}



void CWndObj::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}



void CWndObj::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}



LRESULT CWndObj::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_PAINT:
		{
			break;
		}

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_OBJ_OK:
				{
					m_vcR.x = GetDlgItemFlt(m_hWnd, IDC_OBJ_R_X);
					m_vcR.y = GetDlgItemFlt(m_hWnd, IDC_OBJ_R_Y);
					m_vcR.z = GetDlgItemFlt(m_hWnd, IDC_OBJ_R_Z);

					m_vcS.x = GetDlgItemFlt(m_hWnd, IDC_OBJ_S_X);
					m_vcS.y = GetDlgItemFlt(m_hWnd, IDC_OBJ_S_Y);
					m_vcS.z = GetDlgItemFlt(m_hWnd, IDC_OBJ_S_Z);

					m_vcT.x = GetDlgItemFlt(m_hWnd, IDC_OBJ_T_X);
					m_vcT.y = GetDlgItemFlt(m_hWnd, IDC_OBJ_T_Y);
					m_vcT.z = GetDlgItemFlt(m_hWnd, IDC_OBJ_T_Z);

					SetVal();

					break;
				}

				case IDC_OBJ_CLOSE:
				{
					m_pObj = NULL;
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}

				case IDC_OBJ_R_X:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcR.x = GetDlgItemFlt(hWnd, IDC_OBJ_R_X);	break;	}}	break;	}
				case IDC_OBJ_R_Y:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcR.y = GetDlgItemFlt(hWnd, IDC_OBJ_R_Y);	break;	}}	break;	}
				case IDC_OBJ_R_Z:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcR.z = GetDlgItemFlt(hWnd, IDC_OBJ_R_Z);	break;	}}	break;	}

				case IDC_OBJ_S_X:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcS.x = GetDlgItemFlt(hWnd, IDC_OBJ_S_X);	break;	}}	break;	}
				case IDC_OBJ_S_Y:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcS.y = GetDlgItemFlt(hWnd, IDC_OBJ_S_Y);	break;	}}	break;	}
				case IDC_OBJ_S_Z:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcS.z = GetDlgItemFlt(hWnd, IDC_OBJ_S_Z);	break;	}}	break;	}

				case IDC_OBJ_T_X:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcT.x = GetDlgItemFlt(hWnd, IDC_OBJ_T_X);	break;	}}	break;	}
				case IDC_OBJ_T_Y:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcT.y = GetDlgItemFlt(hWnd, IDC_OBJ_T_Y);	break;	}}	break;	}
				case IDC_OBJ_T_Z:{	switch(wparHi)	{	case EN_CHANGE:	{	m_vcT.z = GetDlgItemFlt(hWnd, IDC_OBJ_T_Z);	break;	}}	break;	}

			}

			break;
		}

		case WM_CLOSE:
		{
			DestroyWindow( hWnd );
			m_hWnd	= NULL;
			break;
		}
	}

	return(FALSE);
}



void CWndObj::SetObj(void* pMdB)
{
	CMdBase* pObj = NULL;
	CMdMsh*  pSrc = NULL;

	m_pObj = pMdB;

	if(m_pObj)
	{
		pObj = (CMdBase*)m_pObj;
		pSrc = (CMdMsh* )pObj->GetMshSrc();
	}

	SetDlgItemText(m_hWnd, IDC_OBJ_ID, "");
	SetDlgItemText(m_hWnd, IDC_OBJ_NAME, "");


	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_X, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Y, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Z, 0.0F);

	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_X, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Y, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Z, 0.0F);

	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_X, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Y, 0.0F);
	SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Z, 0.0F);


	if(pObj)
	{
		char sBuf[32]={0};
		sprintf(sBuf, "0x%x" , pObj);

		SetDlgItemText(m_hWnd, IDC_OBJ_ID, sBuf);
		SetDlgItemText(m_hWnd, IDC_OBJ_NAME, pSrc->GetMdlName());

		VEC3	m_vcR = pObj->GetRot();
		VEC3	m_vcS = pObj->GetScl();
		VEC3	m_vcT = pObj->GetPos();

		SetDlgItemFlt(m_hWnd, IDC_OBJ_R_X, m_vcR.x);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Y, m_vcR.y);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_R_Z, m_vcR.z);

		SetDlgItemFlt(m_hWnd, IDC_OBJ_S_X, m_vcS.x);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Y, m_vcS.y);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_S_Z, m_vcS.z);

		SetDlgItemFlt(m_hWnd, IDC_OBJ_T_X, m_vcT.x);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Y, m_vcT.y);
		SetDlgItemFlt(m_hWnd, IDC_OBJ_T_Z, m_vcT.z);
	}
}




void CWndObj::SetVal()
{
	CMdBase* pObj = (CMdBase*)m_pObj;

	if(pObj)
	{
		pObj->SetRot( m_vcR);
		pObj->SetScl( m_vcS);
		pObj->SetPos( m_vcT);
	}
}