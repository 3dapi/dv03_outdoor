// Implementation of the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdBase::CMdBase()
: m_fD	(0)
, fSrtR	(0)

, m_vcE	(0,0,0)
, m_vcR	(0,0,0)
, m_vcS	(1,1,1)
, m_vcT	(0,0,0)
, m_mtR	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtS	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtW	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
{
	m_pDev	= NULL;
	m_pCam	= NULL;

	m_pMsD	= NULL;
	m_pMsS	= NULL;

	m_BndInf.SetColor(0xFF666666);
	m_BndInf.SetOwner(this);
}

CMdBase::~CMdBase()
{
	if(m_pMsD)
	{
		CMdMsh* pMshDst = (CMdMsh*)m_pMsD;
		delete pMshDst;
		m_pMsD = NULL;
	}
}



void CMdBase::BndBoxTransform()
{
	//Transform Bound Box
	CMdMsh*	pMshS = (CMdMsh*)m_pMsS;
	
	for(int i=0; i<8; ++i)
	{
		D3DXVECTOR3  vcSrc = pMshS->m_BndInf.vcEdge[i].p;
		D3DXVECTOR3* vcDst = &(m_BndInf.vcEdge[i].p);
		
		D3DXVec3TransformCoord(vcDst, &vcSrc, &m_mtW);
		*vcDst += m_vcE;
	}

	m_BndInf.vcCent = m_BndInf.vcEdge[0].p + m_BndInf.vcEdge[7].p;
	m_BndInf.vcCent *=0.5f;

	m_BndInf.fR = D3DXVec3Length( &(m_BndInf.vcCent - m_BndInf.vcEdge[0].p));
}

void CMdBase::BndBoxRender()
{
	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);
	
	// Render BoundBox
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);

	m_BndInf.RenderBox(m_pDev);

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}





void* CMdBase::GetMshSrc()
{
	return m_pMsS;
}

void CMdBase::SetMshSrc(void* pMshSrc)
{
	m_pMsS = pMshSrc;
}


void* CMdBase::GetMshDst()
{
	return m_pMsD;
}

void CMdBase::SetMshDst(void* pMshDst)
{
	m_pMsD = pMshDst;
}


void CMdBase::SetDev(void* pDev)
{
	m_pDev = (PDEV)pDev;
}

void CMdBase::SetCam(void* pCam)
{
	m_pCam=pCam;
}





VEC3 CMdBase::GetRot()
{
	return m_vcR;
}

void CMdBase::SetRot(VEC3 vcVal)
{
	MATA	mtY;
	MATA	mtZ;
	MATA	mtX;

	m_vcR = vcVal;

	D3DXMatrixRotationY(&mtY, D3DXToRadian(m_vcR.y));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(m_vcR.z));
	D3DXMatrixRotationX(&mtX, D3DXToRadian(m_vcR.x));

	m_mtR = mtY * mtZ * mtX;

	WorldMatrixSetup();
}


VEC3 CMdBase::GetScl()
{
	return m_vcS;
}

void CMdBase::SetScl(VEC3 vcVal)
{
	m_vcS = vcVal;

	m_mtS._11 = m_vcS.x;
	m_mtS._22 = m_vcS.y;
	m_mtS._33 = m_vcS.z;

	WorldMatrixSetup();
}


VEC3 CMdBase::GetPos()
{
	return m_vcT;
}

void CMdBase::SetPos(VEC3 vcVal)
{
	m_vcT = vcVal;

	WorldMatrixSetup();
}



void CMdBase::WorldMatrixSetup()
{
	m_mtW = m_mtR * m_mtS;
	m_mtW._41 = m_vcT.x;
	m_mtW._42 = m_vcT.y;
	m_mtW._43 = m_vcT.z;
}



void CMdBase::SetBndInf(TBndAABB* pBnd)
{
	memcpy(&m_BndInf, pBnd, sizeof(TBndAABB));

	m_BndInf.SetColor(0xFF666666);
	m_BndInf.SetOwner(this);
}


TBndAABB* CMdBase::GetBndInf() const
{
	return (TBndAABB*)&m_BndInf;
}