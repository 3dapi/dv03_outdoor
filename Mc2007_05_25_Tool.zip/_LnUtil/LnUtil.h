// Interface for the Ln Utility functions.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNUTIL_H_
#define _LNUTIL_H_

#pragma warning( disable : 4786)
#include <vector>


#ifndef SAFE_DELETE
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif



#define ONE_RADtoDEG	57.295779513082321f
#define ONE_DEGtoRAD	0.0174532925199433f
#define PI_RADIAN		3.1415926535897932f
#define DEG90toRAD		1.5707963267948966f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }


#define _SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
																			\
		if(!(p))															\
		{																	\
			return;															\
		}																	\
																			\
		if(FAILED((p)->Init()))												\
		{																	\
			delete p;														\
			p = NULL;														\
			return;															\
		}																	\
	}																		\
}


#define SAFE_NEWINIT(p, CLASSTYPE)											\
{																			\
	if(NULL == (p))															\
	{																		\
		p = new CLASSTYPE;													\
																			\
		if(!(p))															\
		{																	\
			return -1;														\
		}																	\
																			\
		if(FAILED((p)->Init()))												\
		{																	\
			delete p;														\
			p = NULL;														\
			return -1;														\
		}																	\
	}																		\
}


#define SAFE_NEWCREATE1(p, CLASSTYPE, P1)									\
{																			\
	if(0 == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED(((CLASSTYPE *)p)->Create(P1)))							\
		{																	\
			delete p; p=0; return -1;										\
		}																	\
	}																		\
}


#define _SAFE_NEWCREATE1(p, CLASSTYPE, P1)									\
{																			\
	if(0 == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(p)																\
		{																	\
			((CLASSTYPE *)p)->Create(P1);									\
		}																	\
	}																		\
}


#define SAFE_NEWCREATE2(p, CLASSTYPE, P1, P2)								\
{																			\
	if(0 == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED(((CLASSTYPE *)p)->Create(P1, P2)))						\
		{																	\
			delete p; p=0; return -1;										\
		}																	\
	}																		\
}


#define SAFE_NEWCREATE3(p, CLASSTYPE, P1, P2, P3)							\
{																			\
	if(0 == (p))															\
	{																		\
		p = new CLASSTYPE;													\
		if(!(p))	{	return -1;	}										\
																			\
		if(FAILED(((CLASSTYPE *)p)->Create(P1, P2, P3)))					\
		{																	\
			delete p; p=0; return -1;										\
		}																	\
	}																		\
}


#define SAFE_RESTORE(p)														\
{																			\
	if(p)																	\
	{																		\
		if(FAILED((p)->Restore()))											\
			return -1;														\
	}																		\
}



#define SAFE_FRMOV(p)														\
{																			\
	if(p)																	\
	{																		\
		if(FAILED(	(p)->FrameMove()))										\
			return -1;														\
	}																		\
}


#define SAFE_UPDATE(p)	{ if(p) {if(FAILED( (p)->Update())) return -1; } }

#define SAFE_DESTROY(p)			{	if(p)	(p)->Destroy();			}
#define SAFE_INVALID(p)			{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)			{	if(p)	(p)->Render();			}

#define SAFE_ONFRMMOV(p)		{	if(p)	(p)->OnFrmMov();		}
#define SAFE_ONRENDER(p)		{	if(p)	(p)->OnRender();		}


#define	SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}

#define FLOATP(p)			(float*)&(p)

#define SAFE_DELETE_OBJECT(p)	{	if(p){	DeleteObject(p); (p)=NULL;	}	}


#define SAFE_DELETE_OBJECT_ARRAY(p, iSIZE)									\
{																			\
	int i_IDX_OBJ_=0;														\
																			\
	for(i_IDX_OBJ_=0; i_IDX_OBJ_ < (iSIZE) ; ++i_IDX_OBJ_)					\
	{																		\
		if(p[i_IDX_OBJ_])													\
		{																	\
			DeleteObject(p[i_IDX_OBJ_]);									\
			p[i_IDX_OBJ_] = NULL;											\
		}																	\
	}																		\
}


// Vector delete
#define SAFE_DEL_LST(p)														\
{																			\
	if(!p.empty())															\
	{																		\
		int iSizeList = p.size();											\
		for(int indexList=0; indexList<iSizeList; ++indexList)				\
			SAFE_DELETE(p[indexList]);										\
		p.clear();															\
	}																		\
}




#define CLASS_DESTROY(CLASS_NAME)											\
CLASS_NAME::~CLASS_NAME()													\
{																			\
	Destroy();																\
}



#define CLASS_CLEAN_ALL(CLASS_NAME)											\
CLASS_NAME::~CLASS_NAME()													\
{																			\
	Invalidate();															\
	Destroy();																\
}




#define	GAME_LOOP_FR(	PhaseName	)										\
INT CMain::OnFrm##PhaseName ()												\
{																			\
	strcat(m_sMsg, " " #PhaseName "");										\
	SAFE_FRMOV(	m_pGm##PhaseName	);										\
	return 1;																\
}																			\
																			\
void CMain::OnRnd##PhaseName ()												\
{																			\
	SAFE_RENDER(	m_pGm##PhaseName	);									\
}																			\




#define CLSS_DLG_DECLEAR(CLASS)												\
CLASS ();																	\
virtual ~CLASS ();															\
static INT_PTR	CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP);

#define CLSS_DLG_DEFINE(CLASS, MSGPROC)										\
static CLASS*	g_pWndDialog##CLASS;										\
INT_PTR CLASS :: CLASS##WndPrc (HWND hW, UINT uM, WPARAM wP, LPARAM lP)		\
{																			\
	return (g_pWndDialog##CLASS)-> MSGPROC (hW, uM, wP, lP);				\
}																			\
																			\
CLASS :: CLASS ()		{	g_pWndDialog##CLASS = this;	Init();	}			\
CLASS:: ~ CLASS (){}

#define CLSS_DLG_WNDPROC( CLASS )	(LPDLGPROC)((CLASS##WndPrc))




void	LnUtil_ErrMsgBox(char *format,...);
void	LnUtil_GetLastError();
char*	LnUtil_GetSmallTime();
INT		LnUtil_TextureLoad(PDEV pDev, char* sFile, PDTX& pTexture, DWORD dColor=0x00FFFFFF
						   , D3DXIMAGE_INFO* pSrcInf=NULL
						   , DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						   , DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR)
						   , D3DFORMAT d3Fmt = D3DFMT_UNKNOWN);

void	LnUtil_ReadFileLine(FILE *fp, char *str);
void	LnUtil_ReadLineQuot(char *strOut, char *strIn, INT iC='\"');
BOOL	LnUtil_LineCross2D(VEC2 * p);
INT		LnUtil_GetPickPos3D(VEC3* pvcCamPos, VEC3* pvcRayDir, VEC3& pPck, VEC3& p0, VEC3& p1, VEC3& p2, FLOAT& fD, BOOL bUseCull=TRUE);
void	LnUtil_SetWindowTitle(HWND, const char *format, ...);

void	LnUtil_OutputDebug(const char *Format, ...);
char*	LnUtil_GetFolder(char*	sPath, HWND hWnd, char *sTitle="Choose Folder");
char*	LnUtil_DWtoStr(DWORD dwA, BOOL bAdd0x=FALSE);

char*	LnUtil_Forming(const char *fmt, ...);
DWORD	LnUtil_VectorToRGB(VEC3* NormalVector);
void	LnUtil_SetWorldIdentity(PDEV pDev);

inline DWORD	LnUtil_FtoDW( FLOAT f )	{ return *((DWORD*)&f); }

void	LnUtil_InitEnvironment();
void	LnUtil_InitRand(DWORD dVal=0);
void	LnUtil_SetCurrentDirectory();
FLOAT	LnUtil_GetLinearWg(FLOAT f1,FLOAT f2,FLOAT f);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val, BOOL bAdd0x=TRUE);

DWORD	LnUtil_GetFileVersion();


// Token Seperator
void	LnUtil_StrList(lsStr& vStr, char* sIn, char* sSpes=NULL);

// Get File Size
long	LnUtil_GetFileSize(FILE* &fp);

// ARGB <--> BGR
// 
BYTE*	LnUtil_GetColorARGB(DWORD& argb);
BYTE*	LnUtil_GetColorBGR(DWORD& argb);



// for sorting
template<class T>
struct TsrtL																	// For sort... ascendent Sort
{
	BOOL operator()(const T& t1,const T& t2) const
	{
		return t1.fSrtR < t2.fSrtR;
	}
};

template<class T>
struct TsrtGp																	// For sort... ascendent Sort
{
	BOOL operator()(const T& t1,const T& t2) const
	{
		return t1->fSrtR > t2->fSrtR;
	}
};





struct LnRc
{
	union	{	struct	{	FLOAT x0, y0, x1, y1;	};	FLOAT m[4];		};
	
	LnRc()										{	x0 = y0 = x1 = y1 = 0.f;										}
	LnRc(const FLOAT*_m)						{	if(!_m){x0=y0=x1=y1=0;}else{x0=_m[0];y0=_m[1];x1=_m[2];y1=_m[3];}}
	LnRc(const LnRc& _rh )						{	x0 = _rh.x0; y0 = _rh.y0; x1 = _rh.x1;	y1 = _rh.y1;			}
	
	LnRc( FLOAT fx0,FLOAT fy0,FLOAT fx1,FLOAT fy1)
	{	x0 = fx0;	y0 = fy0;	x1 = fx1;	y1 = fy1;					}
	
	LnRc( VEC2 p0, VEC2 p1)						{	x0 = p0.x;	y0 = p0.y;	x1 = p1.x;	y1 = p1.y;					}
	
	VEC2   Get00()	 const						{	return VEC2(x0, y0);											}
	VEC2   Get10()	 const						{	return VEC2(x1, y0);											}
	VEC2   Get01()	 const						{	return VEC2(x0, y1);											}
	VEC2   Get11()	 const						{	return VEC2(x1, y1);											}
	
	RECT   GetRECT()							{	RECT r={LONG(x0),LONG(y0),LONG(x1),LONG(y1)};	return r;		}
	D3DRECT   GetRectD3()						{	D3DRECT r={LONG(x0),LONG(y0),LONG(x1), LONG(y1)};	return r;	}
	
	FLOAT	GetWidth()							{	return (x1 - x0);												}
	FLOAT	GetHeight()							{	return (y1 - y0);												}
	
	// casting
	operator FLOAT*()							{	return (FLOAT *) &x0;											}
	operator const FLOAT*() const				{	return (const FLOAT *) &x0;										}
	
	// assignment operators
	LnRc& operator+=(const LnRc& v)				{	x0 += v.x0;	y0 += v.y0;	x1 += v.x1;	y1 += v.y1;	return *this;	}
	LnRc& operator-=(const LnRc& v)				{	x0 -= v.x0;	y0 -= v.y0;	x1 -= v.x1;	y1 -= v.y1;	return *this;	}
	LnRc& operator*=(FLOAT f )					{	x0 *= f;	y0 *= f;	x1 *= f;	y1 *= f;	return *this;	}
	LnRc& operator/=(FLOAT f )					{	FLOAT fInv = 1.0f / f;	x0 *= fInv;	y0 *= fInv;	x1 *= fInv;	y1 *= fInv;		return *this;	}
	
	// unary operators
	LnRc operator+() const						{	return *this;													}
	LnRc operator-() const						{	return LnRc(-x0, -y0, -x1, -y1);								}
	
	// binary operators
	LnRc operator+(const LnRc& v)const			{	return LnRc(x0 + v.x0, y0 + v.y0, x1 + v.x1, y1 + v.y1);		}
	LnRc operator-(const LnRc& v)const			{	return LnRc(x0 - v.x0, y0 - v.y0, x1 - v.x1, y1 - v.y1);		}
	LnRc operator*(FLOAT f) const				{	return LnRc(x0 * f, y0 * f, x1 * f, y1 * f);				}
	LnRc operator/(FLOAT f) const				{	FLOAT fInv = 1.0f / f;	return LnRc(x0 * fInv, y0 * fInv, x1 * fInv, y1 * fInv);		}
	
	friend LnRc operator*(FLOAT f,const LnRc& v){	return LnRc(f * v.x0, f * v.y0, f * v.x1, f * v.y1);			}
	
	BOOL operator==(const LnRc& v) const		{	return x0 == v.x0 && y0 == v.y0 && x1 == v.x1 && y1 == v.y1;	}
	BOOL operator!=(const LnRc& v) const		{	return x0 != v.x0 || y0 != v.y0 || x1 != v.x1 || y0 != v.y1;	}
};

typedef	std::vector<LnRc>	lsLnRc;
typedef	lsLnRc::iterator	itLnRc;


bool	LnUtil_RcCollision(LnRc* v1, LnRc* v2);




struct TlPkT																	// Picking Triangle
{
	VEC3	vcPk;																// Get Position
	VEC3	p0;																	// Triangle
	VEC3	p1;																	// Triangle
	VEC3	p2;																	// Triangle
	FLOAT	fSrtR;																// Distance From Camera

	TlPkT(){}
	TlPkT(VEC3& vcP, VEC3& P0, VEC3& P1, VEC3& P2, FLOAT& _fD)
		: vcPk(vcP), p0(P0), p1(P1), p2(P2), fSrtR(_fD){}
};


typedef std::vector<TlPkT>	lsTlPkT;
typedef lsTlPkT::iterator	itTlPkT;


struct TlSwpWn																	// Swap chain window
{
	PDSW	pC;																	// Swap chain
	PDSF	pB;																	//Back buffer surface
	PDSF	pS;																	//Stencil buffer surface
	HWND	hW;																	// Window Handle

	TlSwpWn() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

};

typedef std::vector<TlSwpWn>	lsTlSwpWn;
typedef lsTlSwpWn::iterator		itTlSwpWn;




struct TlWnRc
{
	LnRc	rc;
	DVWP	vp;

	TlWnRc()								{	memset(&rc, 0, sizeof(LnRc));	memset(&vp, 0, sizeof(DVWP));	}
	TlWnRc(LnRc Rc,DVWP Vp)					{	rc = Rc;	vp = Vp;	}
	TlWnRc(LONG X1,LONG Y1,LONG X2,LONG Y2) : rc(X1,Y1,X2,Y2)	{vp.X = X1;	 vp.Y = Y1;	vp.Width = X2;	vp.Height = Y2;	vp.MinZ = 0, vp.MaxZ = 1;	}

	TlWnRc(LONG X1,LONG Y1,LONG X2,LONG Y2
		, DWORD X,DWORD Y,DWORD W,DWORD H
		, FLOAT Min=0,FLOAT Max=1) : rc(X1,Y1,X2,Y2)
											{	vp.X = X; vp.Y = Y; vp.Width = W; vp.Height = H; vp.MinZ = Min, vp.MaxZ = Max;	}

	LnRc	GetRect()						{	return rc;	}

};




// Cuboid Axis Aligned Bounding Box
//
//	Edges
//
//					 
//		5------------7(Max)
//	y  /|           /|
//	| / |   z      / |
//	|/  |  /      /  |
//	1------------3   |
//	|   |/       |   |
//	|   4--------|---6
//	|  /         |  /
//	| /          | /
//	|/           |/
//	0(Min)-------2----- x


struct TBndAABB
{
	struct VtxD
	{
		VEC3	p;
		DWORD	d;
		enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE) };

		VtxD() : d(0xFFFFFFFF){}

	} vcEdge[8];


	WORD Idx[24];

	FLOAT		fX;		// Width
	FLOAT		fY;		// Height
	FLOAT		fZ;		// Depth
	FLOAT		fR;		// Radius
	D3DXVECTOR3	vcCent;
	

	void*		pOwner;	// Owner of Bound Box
	
	TBndAABB()
	{
		Idx[ 0] = 0;	Idx[ 1] = 1;
		Idx[ 2] = 1;	Idx[ 3] = 3;
		Idx[ 4] = 3;	Idx[ 5] = 2;
		Idx[ 6] = 2;	Idx[ 7] = 0;

		Idx[ 8] = 0;	Idx[ 9] = 4;
		Idx[10] = 1;	Idx[11] = 5;
		Idx[12] = 3;	Idx[13] = 7;
		Idx[14] = 2;	Idx[15] = 6;

		Idx[16] = 4;	Idx[17] = 5;
		Idx[18] = 5;	Idx[19] = 7;
		Idx[20] = 7;	Idx[21] = 6;
		Idx[22] = 6;	Idx[23] = 4;

		pOwner	= NULL;
	}

	TBndAABB(const D3DXVECTOR3& Min, const D3DXVECTOR3& Max, void* pOwn=NULL)
	{
		TBndAABB();

		Set(Min, Max, pOwn);		
	}

	void Set(const D3DXVECTOR3& Min, const D3DXVECTOR3& Max, void* pOwn=NULL)
	{
		vcEdge[0].p = Min;
		vcEdge[7].p = Max;

		fX = Max.x -Min.x;
		fY = Max.y -Min.y;
		fZ = Max.z -Min.z;

		vcCent = Min + D3DXVECTOR3(fX, fY, fZ) * 0.5f;

		fR = sqrtf( fX * fX + fY * fY + fZ * fZ);

		vcEdge[0].p = Min;
		vcEdge[1].p = Min + D3DXVECTOR3( 0, fY,  0);
		vcEdge[2].p = Min + D3DXVECTOR3(fX,  0,  0);
		vcEdge[3].p = Min + D3DXVECTOR3(fX, fY,  0);
		vcEdge[4].p = Min + D3DXVECTOR3( 0,  0, fZ);
		vcEdge[5].p = Min + D3DXVECTOR3( 0, fY, fZ);
		vcEdge[6].p = Min + D3DXVECTOR3(fX,  0, fZ);
		

		vcEdge[0].p = Min;
		vcEdge[1].p = Min + D3DXVECTOR3( 0, fY,  0);
		vcEdge[2].p = Min + D3DXVECTOR3(fX,  0,  0);
		vcEdge[3].p = Min + D3DXVECTOR3(fX, fY,  0);
		vcEdge[4].p = Min + D3DXVECTOR3( 0,  0, fZ);
		vcEdge[5].p = Min + D3DXVECTOR3( 0, fY, fZ);
		vcEdge[6].p = Min + D3DXVECTOR3(fX,  0, fZ);
		vcEdge[7].p = Max;

		if(pOwn)
			pOwner = pOwn;
	}


	void RenderBox(PDEV pDev)
	{
		DWORD dFill;

		pDev->GetRenderState(D3DRS_FILLMODE, &dFill);
		pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);

		pDev->SetTexture(0,0);
		pDev->SetFVF(TBndAABB::VtxD::FVF);
		pDev->DrawIndexedPrimitiveUP(D3DPT_LINELIST, 0, 8, 12, Idx, D3DFMT_INDEX16, vcEdge, sizeof(vcEdge[0]));
		pDev->SetRenderState(D3DRS_FILLMODE, dFill);
	}

	void SetOwner(void* pOwn)
	{
		pOwner = pOwn;
	}

	void SetColor(DWORD dColor)
	{
		for(int i=0 ;i<8; ++i)
			vcEdge[i].d = dColor;
	}

	D3DXVECTOR3*	GetMin() const
	{
		return (D3DXVECTOR3*)&(vcEdge[0].p);
	}

	D3DXVECTOR3*	GetMax() const
	{
		return (D3DXVECTOR3*)&(vcEdge[7].p);
	}

	D3DXVECTOR3*	GetCenter() const
	{
		return (D3DXVECTOR3*)&(vcCent);
	}

	FLOAT	GetWidth()	{	return  fX;	}
	FLOAT	GetHeight()	{	return	fY;	}
	FLOAT	GetDepth()	{	return	fZ;	}
	FLOAT	GetRadius()	{	return	fR;	}
};


#endif
