// Typedef for the Ln types.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNTYPE_H_
#define _LNTYPE_H_

#pragma warning( disable : 4786)

#include <vector>
#include <list>
#include <string>


// Window
typedef WNDPROC						LPWNDPROC;		// for Window Message
typedef DLGPROC						LPDLGPROC;		// for Dialog Message


// Math
typedef D3DXVECTOR2						VEC2;
typedef	D3DXVECTOR3						VEC3;
typedef D3DXVECTOR4						VEC4;
typedef D3DXMATRIX						MATA;
typedef D3DXQUATERNION					QUAT;
typedef D3DXPLANE						DPLN;
typedef D3DXCOLOR						DCLR;

// DirectX
typedef	LPDIRECT3D9						PD3D;
typedef LPDIRECT3DDEVICE9				PDEV;
typedef	LPD3DXSPRITE					PDSP;

typedef D3DVIEWPORT9					DVWP;

typedef	D3DLIGHT9						DLGT;
typedef LPDIRECT3DTEXTURE9				PDTX;
typedef	D3DXIMAGE_INFO					DIMG;
typedef LPDIRECT3DCUBETEXTURE9			PDCB;
typedef LPDIRECT3DVOLUMETEXTURE9		PDVT;
typedef ID3DXRenderToEnvMap*			PDRE;

typedef LPDIRECT3DSURFACE9				PDSF;
typedef LPD3DXRENDERTOSURFACE			PDRS;
typedef	LPDIRECT3DSWAPCHAIN9			PDSW;		//	Swap chain

// STL
typedef std::vector<VEC2>				lsVC2;
typedef lsVC2::iterator					itVC2;

typedef std::vector<VEC3>				lsVC3;
typedef lsVC3::iterator					itVC3;

typedef std::vector<VEC4>				lsVC4;
typedef lsVC4::iterator					itVC4;

typedef std::vector<INT>				lsINT;
typedef lsINT::iterator					itINT;

typedef std::vector<FLOAT>				lsFLT;
typedef lsFLT::iterator					itFLT;

typedef std::vector<WORD>				lsWD;
typedef lsWD::iterator					itWD;

typedef std::vector<DWORD>				lsDWD;
typedef lsDWD::iterator					itDWD;

typedef std::vector<RECT>				lsRc;
typedef lsRc::iterator					itRc;

typedef std::list<HANDLE>				lsHANDLE;
typedef lsHANDLE::iterator				itHANDLE;

typedef std::vector<std::string>		lsStr;
typedef lsStr::iterator					itStr;


// Material Redefine
union DMTL
{
	struct
	{
		DCLR	dcD;					// Diffuse color RGBA
		DCLR	dcA;					// Ambient color RGB
		DCLR	dcS;					// Specular 'shininess'
		DCLR	dcE;					// Emissive color RGB
		FLOAT	fPw;					// Sharpness if specular highlight
	};

	D3DMATERIAL9 m;
};


typedef	std::vector<DMTL*>				lsDMTL;
typedef	lsDMTL::iterator				itDMTL;


#endif
