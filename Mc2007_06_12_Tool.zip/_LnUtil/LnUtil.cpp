// Implementation of Ln Utility functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>

#include <time.h>


#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"
#include "LnUtil.h"


void LnUtil_ErrMsgBox(char *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(0, s, "Err", MB_OK | MB_ICONERROR);
}



void LnUtil_GetLastError()
{
	LPVOID lpMsgBuf;

	FormatMessage( 
				FORMAT_MESSAGE_ALLOCATE_BUFFER | 
				FORMAT_MESSAGE_FROM_SYSTEM | 
				FORMAT_MESSAGE_IGNORE_INSERTS,
				NULL,
				GetLastError(),
				0,
				(LPTSTR) &lpMsgBuf,
				0,
				NULL 
	);

	MessageBox( NULL, (LPCTSTR)lpMsgBuf, "Error", MB_OK | MB_ICONINFORMATION );
	LocalFree( lpMsgBuf );
}



// Texture Load
INT	LnUtil_TextureLoad(PDEV pDev, char* sFile, PDTX& pTexture, DWORD dColor
						   , D3DXIMAGE_INFO* pSrcInf
						   , DWORD Filter, DWORD MipFilter, D3DFORMAT d3Fmt)
{
	HRESULT hr;
	if ( FAILED(hr = D3DXCreateTextureFromFileEx(
		pDev
		, sFile
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3Fmt
		, D3DPOOL_MANAGED
		, Filter
		, MipFilter
		, dColor
		, pSrcInf
		, NULL
		, &pTexture
		)) )
	{
		pTexture = 0;
		return hr;
	}
	
	return 1;
}



void LnUtil_ReadFileLine(FILE *fp, char *str)
{
	static char sTmp[512];
	
	INT nSize;
	INT nBgn, nEnd;
	INT i;

	memset(sTmp,0, sizeof(sTmp));
	fgets(sTmp, 512, fp);

	nSize = strlen(sTmp);
	
	for(i=0; i<nSize; ++i)
	{
		if('\t' == sTmp[i])
			sTmp[i] =' ';
		
		if('\n' == sTmp[i] || '\r' == sTmp[i])
		{
			sTmp[i] = 0;
		}
	}
	
	nBgn=0;
	nEnd= strlen(sTmp);

	if(0 == nEnd)
	{
		str[0] =0;
		return;
	}
	
	for(i=0; i<=nEnd; ++i)
	{
		if(' ' != sTmp[i])
		{
			nBgn =i;
			break;
		}
	}
	
	strncpy(str, sTmp + nBgn, nEnd-nBgn);
	str[nEnd-nBgn] = 0;
}


void LnUtil_ReadLineQuot(char *strOut, char *strIn, INT iC)
{
	INT iB;
	INT iE;
	INT	i;

	// Search forward
	
	INT	iLen= strlen(strIn);

	for(i=0;i<iLen; ++i)
	{
		if(iC == strIn[i])
		{
			iB = i;
			break;
		}
	}

	for(i=iLen-1;i>=0; --i)
	{
		if(iC == strIn[i])
		{
			iE = i;
			break;
		}
	}

	if(iB == (iE-1))															// ���۰� �����̿� ���ڰ� ����.
	{
		strOut[0]=0;
		return;
	}

	strncpy(strOut, strIn+iB+1, iE-iB-1);
}




BOOL LnUtil_LineCross2D(VEC2 * p)
{
	VEC2 L1 = p[1] - p[0];
	VEC2 L2 = p[3] - p[2];
	VEC2 L3 = p[2] - p[0];
	
	
	FLOAT fAlpha = L2.x * L1.y - L2.y * L1.x;
	
	if(0.f == fAlpha)
		return FALSE;
	
	FLOAT fBeta = fAlpha;
	
	fAlpha = (L2.x * L3.y - L2.y * L3.x)/fAlpha;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return FALSE;
	
	fBeta = (L2.x * L3.y - L1.y * L3.x)/fBeta;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return FALSE;
	
	return TRUE;
}








INT	LnUtil_GetPickPos3D(D3DXVECTOR3* pvcCamPos, D3DXVECTOR3* pvcRayDir, D3DXVECTOR3& vcPck, D3DXVECTOR3& p0, D3DXVECTOR3& p1, D3DXVECTOR3& p2, FLOAT& D, BOOL bUseCull)
{
	D3DXVECTOR3	vcCamPos= *pvcCamPos;
	D3DXVECTOR3	vcRayDir= *pvcRayDir;

	FLOAT	U, V;

	if(bUseCull)
	{
		D3DXVECTOR3 vcN;
		D3DXVec3Cross(&vcN, &(p1-p0), &(p2-p0));

		if( D3DXVec3Dot(&vcN, &vcRayDir)>0)
			return -1;
	}

	if(D3DXIntersectTri( &p0, &p1, &p2, &vcCamPos, &vcRayDir, &U, &V, &D))
	{
		vcPck = p0 + U * (p1 - p0) + V * (p2 - p0);
		return 1;
	}

	return -1;
}


void LnUtil_SetWindowTitle(HWND hWnd, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(hWnd, s);
}


void LnUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}


char* LnUtil_GetFolder(char* sPath, HWND hWnd, char* sTitle)
{
	BROWSEINFO		bi;
	static char	sPathName[1024];
	static char	sPathFull[1024];
	LPITEMIDLIST	pidl = NULL;
	LPITEMIDLIST	pidlFolder= NULL;
	LPMALLOC		pMalloc = NULL;

	memset(sPathName, 0, sizeof(sPathName));
	memset(sPathFull, 0, sizeof(sPathFull));
	memset(&bi, 0, sizeof(BROWSEINFO));

	bi.hwndOwner = hWnd;
	bi.lpszTitle = sTitle;
	bi.ulFlags = BIF_STATUSTEXT |BIF_EDITBOX   ;
	bi.ulFlags = BIF_EDITBOX   ;

	GetCurrentDirectory(1024, sPathFull);

	LPSHELLFOLDER pShellFolder = NULL;
	OLECHAR wszPath[MAX_PATH] = {0};
	ULONG nCharsParsed = 0;
	
	// Get an IShellFolder interface pointer
	::SHGetDesktopFolder(&pShellFolder);
	
	// Convert the path name to Unicode
	::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sPathFull, -1, wszPath, MAX_PATH);
	
	// Call ParseDisplayName() to do the job
	pShellFolder->ParseDisplayName(NULL, NULL, wszPath, &nCharsParsed, &pidl, NULL);

	bi.pidlRoot = pidl;


	pidlFolder = SHBrowseForFolder(&bi);

	if(pidlFolder == NULL)
	{
		sPath[0] =0;
		sPathFull[0];
		return sPathFull;														//����� ���
	}

	SHGetPathFromIDList(pidlFolder, sPathName);

	strcpy(sPath, sPathName);
	strcpy(sPathFull, sPathName);

	SHGetMalloc(&pMalloc);
	pMalloc->Free(pidl);
	pMalloc->Free(pidlFolder);
	pMalloc->Release();

	return sPathFull;
}


char*	LnUtil_DWtoStr(DWORD dwA, BOOL bAdd0x)
{
	static char	buf[32];
	char	s[32];
	char*	pDst;

	memset(buf, 0, sizeof(buf));
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", dwA);
	pDst = s + strlen(s) - 8;

	if(bAdd0x)
		sprintf(buf,"0x%s", pDst);
	else
		strcpy(buf, pDst);

	return buf;
}



DWORD	LnUtil_GetFileVersion()
{
	//			
	return 0x00000101;
}


void SetDlgItemFlt(HWND hWnd, UINT id, float z, INT decimal)
{
	char s[128];
	char f[64];
	
	sprintf(f,"%%.%df", decimal);
	memset(s, 0, sizeof(s));
	sprintf(s, f, z);
	SetDlgItemText(hWnd,id,s);
}

FLOAT GetDlgItemFlt(HWND hWnd, UINT id)
{
	char s[256];
	memset(s, 0, sizeof(s));

	GetDlgItemText(hWnd, id, s, sizeof(s));
	return atof(s);
}

void SetDlgItemHex(HWND hWnd, UINT id, INT val, BOOL bAdd0x)
{
	char	buf[64] = "0x";
	char	s[32];
	char*	pDst;
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", val);
	pDst = s + strlen(s) - 8;

	strcat(buf, pDst);
	SetDlgItemText(hWnd,id,buf);
}


char*	LnStr_Format(const char *format, ...)
{
	static char sDst[8192]={0};
	char sOrg[8192]={0};

	va_list ap;

	va_start(ap, format);
	vsprintf(sOrg, format, ap);
	va_end(ap);

	strcpy(sDst, sOrg);

	return sDst;
}

DWORD LnUtil_VectorToRGB(D3DXVECTOR3* NormalVector)
{
	DWORD dwR = (DWORD)(100.f * NormalVector->x + 155.f);
	DWORD dwG = (DWORD)(100.f * NormalVector->y + 155.f);
	DWORD dwB = (DWORD)(100.f * NormalVector->z + 155.f);
	
	return (DWORD)(0xff000000 + (dwR << 16) + (dwG << 8) + dwB);
}


void LnUtil_InitEnvironment()
{
	LnUtil_SetCurrentDirectory();
	LnUtil_InitRand(0);
}


void LnUtil_InitRand(DWORD dVal)
{
	if(0==dVal)
		srand((unsigned)time(0));

	else
		srand(dVal);
}


void LnUtil_SetCurrentDirectory()
{
	char	sExe1[512];
	char	sExe2[512];

	memset(sExe1, 0, sizeof(sExe1));
	memset(sExe2, 0, sizeof(sExe2));

	strcpy(sExe1, GetCommandLine());

	INT	iLen = strlen(sExe1);

	int k=0;

	for(INT i=0; i<iLen; ++i)
	{
		if('"' == sExe1[i])
		{
			++k;
			continue;
		}

		if(2==k)
			break;

		sExe2[i-k] = sExe1[i];
		if('\\' == sExe2[i-k])
			sExe2[i-k] ='/';
	}

	char*pdest;
	
	pdest = strrchr(sExe2, '/');

	int result;
	result = pdest - sExe2;

	sExe2[result] =0;

	BOOL hr = SetCurrentDirectory(sExe2);
}


void LnUtil_SetWorldIdentity(PDEV pDev)
{
	static MATA	mtW(	1,0,0,0
					,	0,1,0,0
					,	0,0,1,0
					,	0,0,0,1);

	pDev->SetTransform(D3DTS_WORLD, &mtW);
}

FLOAT	LnUtil_GetLinearWg(FLOAT f1,FLOAT f2,FLOAT f)
{
		return ( (f-f1) / (f2-f1) );
}



void LnUtil_StrList(lsStr& vStr, char* sIn, char* sSpes)
{
	static char sp[]   = " ,\t/\'\"\\\n";
	char *token = NULL;

	if(!strlen(sIn))
		return;

	if(!sSpes)
		sSpes = sp;

	token = strtok( sIn, sSpes );

	if(!token || !strlen(token))
		return;

	vStr.push_back(token);

	while( token != NULL )
	{
		token = strtok( NULL, sSpes );

		if(token && strlen(token))
			vStr.push_back(token);
	}
}


long	LnUtil_GetFileSize(FILE* &fp)
{
	long lCur = ftell(fp);
	long lSize =0;
	long lB =0, lE =0;

	fseek(fp, 0, SEEK_SET);		lB = ftell(fp);
	fseek(fp, 0, SEEK_END);		lE = ftell(fp);

	lSize = lE-lB;

	fseek(fp, lCur, SEEK_CUR);

	return lSize;
}


// ARGB <--> BGR
BYTE* LnUtil_GetColorARGB(DWORD& _argb)
{
	static BYTE argb[4];
	BYTE* pClr = (BYTE*)&_argb;

	argb[0] = pClr[3];
	argb[1] = pClr[2];
	argb[2] = pClr[1];
	argb[3] = pClr[0];

	return argb;
}

// ARGB <--> BGR
BYTE* LnUtil_GetColorBGR(DWORD& bgr)
{
	static BYTE argb[4];

	BYTE* pClr = (BYTE*)&bgr;

	argb[0] = 0x0;
	argb[1] = pClr[0];
	argb[2] = pClr[1];
	argb[3] = pClr[2];
	return argb;
}



bool LnUtil_RcCollision(LnRc* v1, LnRc* v2)
{
	return (v1->x0 <= v2->x1 && v1->x1 >= v2->x0 &&
			v1->y0 <= v2->y1 && v1->y1 >= v2->y0);
}







INT	LnUtil_PickAABB(FLOAT* fDist, D3DXVECTOR3* pvcOut, D3DXVECTOR3* pvcCamPos, D3DXVECTOR3* pvcRayDir, TBndAABB* pIn)
{
	D3DXVECTOR3	vcCamPos= *pvcCamPos;
	D3DXVECTOR3	vcRayDir= *pvcRayDir;

	D3DXVECTOR3	vcBndCent= *pIn->GetCenter();
	D3DXVECTOR3	vcT		 = vcBndCent - vcCamPos;

	FLOAT	fRadius = pIn->GetRadius();
	FLOAT	fDot	= D3DXVec3Dot(&vcRayDir, &vcT);
	FLOAT	fL		= 0.F;

	// �𷺼ǰ� �ݴ��̸� ��������
	if(fDot<0.f)
		return -1;


	// �浹 �ٿ�� ���� �񱳵� �Ѵ�.
	fL		 =D3DXVec3LengthSq(&vcT);
	fDot	*=fDot;
	fRadius *=fRadius;

	if( fL >(fDot + fRadius))
		return -1;


	// �浹 �ٿ�� ���� �ݰ溸�� ������ 12 ���� �ﰢ�� �浹�� �����Ѵ�.
	

	//					 
	//		5------------7(Max)
	//	y  /|           /|
	//	| / |   z      / |
	//	|/  |  /      /  |
	//	1------------3   |
	//	|   |/       |   |
	//	|   4--------|---6
	//	|  /         |  /
	//	| /          | /
	//	|/           |/
	//	0(Min)-------2----- x

	const static int nIdxTri[][3] =
	{
		{ 0, 1, 2},
		{ 3, 2, 1},

		{ 2, 3, 6},
		{ 7, 6, 3},

		{ 6, 7, 4},
		{ 5, 4, 7},

		{ 4, 5, 0},
		{ 1, 0, 5},

		{ 1, 5, 3},
		{ 7, 3, 5},

		{ 4, 0, 6},
		{ 2, 6, 0},
	};

	
	FLOAT	fMax= FLT_MAX;
	FLOAT	U;
	FLOAT	V;
	FLOAT	D;
	D3DXVECTOR3*	p0;
	D3DXVECTOR3*	p1;
	D3DXVECTOR3*	p2;
	D3DXVECTOR3		vcPck;

	TBndAABB::VtxD* vcEdge = pIn->vcEdge;

	for(int i=0; i<12; ++i)
	{
		p0 = &vcEdge[nIdxTri[i][0] ].p;
		p1 = &vcEdge[nIdxTri[i][1] ].p;
		p2 = &vcEdge[nIdxTri[i][2] ].p;

		if(D3DXIntersectTri( p0, p1, p2, &vcCamPos, &vcRayDir, &U, &V, &D))
		{
			if(D<fMax)
			{
				if(pvcOut)
					*pvcOut = *p0 + U * (*p1 - *p0) + V * (*p2 - *p0);

				fMax = D;
			}
		}
	}

	// �浹�ϸ�...
	if(FLT_MAX != fMax)
	{
		*fDist = fMax;
		return 1;
	}

	return -1;
}