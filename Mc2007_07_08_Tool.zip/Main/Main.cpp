// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	SetClsName(EXC_MTX);
	
	m_dHicon		= IDI_MAIN_ICON;
	m_dHmenu		= IDR_MENU;
	m_dHdevalt		= IDM_CHANGEDEVICE;
	m_dHtoggle		= IDM_TOGGLEFULLSCREEN;
	m_dHexit		= IDM_EXIT;
	m_dHaccel		= IDR_MAIN_ACCEL;
	
	
	m_pMcFnt		= NULL;
	m_pInput		= NULL;
	m_pCamG			= NULL;
	m_pCamO			= NULL;
	
	m_pSkyTexture	= NULL;
	m_pSkyDome		= NULL;
	
	m_pTbTx			= NULL;
	m_pTbMd			= NULL;
	
	m_pFld			= NULL;
	
	m_bMnLgt		= FALSE;
	m_bMnFog		= FALSE;
	m_bMnFill		= D3DFILL_SOLID;
	m_bMnCam		= TRUE;
	m_bMnLcl		= TRUE;
	m_bMnFrame		= TRUE;
	m_bMnSkydome	= FALSE;
	m_bMnBndBox		= FALSE;
	m_bCulling		= TRUE;
	
	m_dScnPosX		=230;
	m_dScnPosY		=0;
}


CMain::~CMain()
{
}



HRESULT CMain::Init()
{
	FLOAT fBack[2]={ FLOAT( GMAIN->GetDxBackW() ), FLOAT( GMAIN->GetDxBackH())};
	
	SAFE_NEWCREATE1(m_pInput,	CLnInput, GDEVICE);
	SAFE_NEWCREATE2(m_pCamG	,	CLnCam, GDEVICE, fBack);
	SAFE_NEWCREATE2(m_pCamO	,	CLnCam, GDEVICE, fBack);
	
	SAFE_NEWCREATE1(m_pTbTx	,	CTbTx, GDEVICE	);
	SAFE_NEWCREATE1(m_pTbMd	,	CTbMdB, GDEVICE	);
	
	SAFE_NEWCREATE1(m_pFld	,	CMpFld, GDEVICE	);
	
	
	m_pCamG->SetPos( VEC3(500, 50, -100));
	m_pCamG->SetLook(VEC3(500, 0, 500));
	m_pCamG->SetFar(8000);	

	m_pCamG->Update();
	m_pCamG->SetTransForm();
	
	
	LOGFONT  lFnt= {16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, VARIABLE_PITCH | FF_ROMAN, "Arial"};
	D3DXCreateFontIndirect(GDEVICE, &lFnt, &m_pMcFnt);
	
	m_Wrk.Create(m_hWnd);
	SetFocus(GHWND);
	
	
	SAFE_NEWCREATE2(m_pSkyDome,	CLnDxMsh, GDEVICE, "Model/SKY/skydome.x");

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	"Env_Sky.jpg");
	m_pSkyTexture = TBTX->SelectTx(nM, nS);



	if( D3DFILL_SOLID == m_bMnFill)
		CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_UNCHECKED);

		
	if(m_bMnLgt)
		CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_UNCHECKED);

		
	if(m_bMnFog)
		CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnCam)
		CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnLcl)
		CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnFrame)
		CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnSkydome)
		CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnBndBox)
		CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_UNCHECKED);

	
	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pMcFnt	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamG		);
	SAFE_DELETE(	m_pCamO		);
	SAFE_DELETE(	m_pTbTx		);
	SAFE_DELETE(	m_pTbMd		);
	
	SAFE_DELETE(	m_pFld		);
	
	SAFE_DESTROY(	&m_Wrk		);
	
	SAFE_DELETE(	m_pSkyDome	);
	
	return S_OK;
}


HRESULT CMain::Restore()
{
	GDEVICE->GetViewport(&m_Vp);
	
	if(m_bWindowed)
	{
		GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);
		GDEVICE->GetDepthStencilSurface(&m_SwpWn.pS);
	}
	
	SAFE_RESTORE(	&m_Wrk		);
	SAFE_RESTORE(	m_pSkyDome	);
	
	m_pMcFnt->OnResetDevice();	
	
	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pMcFnt->OnLostDevice();
	
	SAFE_INVALID(	&m_Wrk		);
	SAFE_INVALID(	m_pSkyDome	);
	
	m_SwpWn.Release();
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	CMdBase* pObj = NULL;
	
	if(m_pFld)
		pObj= (CMdBase*)m_pFld->GetPckObj();

	HWND hWnd = GetActiveWindow();
	
	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );
	
	SAFE_FRMOV(	m_pInput	);													// Update Input
	
	VEC3 vcD = GINPUT->GetMouseDelta();
	FLOAT fCamSpeed = 10.f;
	
	if(hWnd && hWnd == GHWND)
	{
		if(vcD.z !=0.f)
			m_pCamG->MoveForward(-vcD.z* 1.f, 1.f);
		
		if(GINPUT->KeyState(DIK_W))					// W
			m_pCamG->MoveForward( fCamSpeed, 1.f);
		
		if(GINPUT->KeyState(DIK_S))					// S
			m_pCamG->MoveForward(-fCamSpeed, 1.f);
		
		if(GINPUT->KeyState(DIK_A))					// A
			m_pCamG->MoveSideward(-fCamSpeed);
		
		if(GINPUT->KeyState(DIK_D))					// D
			m_pCamG->MoveSideward(fCamSpeed);
		
		if(GINPUT->GetMouseSt(1))
		{
			FLOAT	fYaw	= D3DXToRadian(vcD.x * 0.1f);
			FLOAT	fPitch	= D3DXToRadian(vcD.y * 0.1f);
			m_pCamG->MoveRotate(fYaw, fPitch);
		}
	}
	
	else if(hWnd == m_Wrk.m_hWnd && GMAIN->IsWindow())
	{
		if( GetAsyncKeyState(VK_ADD)&0X8000 )
			m_pCamO->MoveForward(-2.f, 1.f);
		
		if( GetAsyncKeyState(VK_SUBTRACT)&0X8000 )
			m_pCamO->MoveForward(2.f, 1.f);
	}

	
	if(pObj)
	{
		VEC3	vcPos = pObj->GetPos();
		if(GINPUT->KeyState(DIK_LEFT))
			vcPos.x -=1;
		
		if(GINPUT->KeyState(DIK_RIGHT))
			vcPos.x +=1;

		if(GINPUT->KeyState(DIK_UP))
			vcPos.z +=1;
		
		if(GINPUT->KeyState(DIK_DOWN))
			vcPos.z -=1;

		if(GINPUT->KeyState(DIK_ADD))
			vcPos.y +=1;
		
		if(GINPUT->KeyState(DIK_SUBTRACT))
			vcPos.y -=1;

		pObj->SetPos(vcPos);
	}


	if(GINPUT->KeyDown(DIK_C))					// W
		m_bCulling ^=1;
	
	SAFE_FRMOV(	m_pCamG	);
	SAFE_FRMOV(	m_pCamO	);
	
	SAFE_FRMOV(	m_pFld	);
	SAFE_FRMOV(&m_Wrk	);
	
	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 1;
	
	if(!GDEVICE)
		return -1;
	
	
	m_Wrk.Render();
	
	
	if(m_bWindowed)
	{
		GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
		GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	}
	
	m_pCamG->SetTransForm();
	GDEVICE->SetViewport(&m_Vp);
	
	GDEVICE->Clear( 0, 0, GMAIN->GetDxClearMode(), 0x00006699, 1.0f, 0L );
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;


	if(GMAIN->m_bMnCam)
		SAFE_RENDER( m_pCamG	);

	
	if(GMAIN->m_bMnSkydome)
	{
		static DOUBLE	angle =0;
		DWORD			dBgn = timeGetTime();

		D3DXMATRIX	mtR;
		D3DXMATRIX	mtW;

		VEC3		vcCam = m_pCamG->GetEye();
		
		angle += dBgn/2000000000.f;

		if( angle> 360.)
			angle -=360.;
	
		D3DXMatrixRotationY(&mtR, D3DXToRadian(angle));
		
		D3DXMatrixScaling( &mtW, 16, 10, 16);

		mtW *=mtR;
		
		mtW._41 = vcCam.x;
		mtW._42 = vcCam.y-3800;
		mtW._43 = vcCam.z;
		
		GDEVICE->SetTransform( D3DTS_WORLD, &mtW );
		GDEVICE->SetRenderState( D3DRS_LIGHTING,     FALSE );
		GDEVICE->SetTexture( 0, m_pSkyTexture );

		SAFE_RENDER(	m_pSkyDome	);
	}


	SAFE_RENDER(	m_pFld	);	
	
	
	if(GMAIN->m_bMnFrame)
	{
		RECT rt={5,5, 800,20};
		GMAIN->m_pMcFnt->DrawText(GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
	}
	
	
	GDEVICE->EndScene();
	
	return S_OK;
}
