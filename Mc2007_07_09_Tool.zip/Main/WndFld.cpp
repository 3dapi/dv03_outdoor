// Implementation of the CWndFld class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CLSS_DLG_DEFINE(CWndFld, MsgPrc);


INT CWndFld::Init()
{
	m_hWnd	= 0;
	m_hWPrn	= 0;

	m_iNfX	= 3;
	m_iNfZ	= 3;
	m_iExt	= 1024;

	m_bAll	= true;

	m_iNx	= 16;
	m_iWx	= 0;
	m_fUV	= 2.f;

	return 1;
}


INT CWndFld::Create(HWND hWnd)
{
	if(m_hWnd)
		return 1;

	HINSTANCE hInst = GetModuleHandle(NULL);
	m_hWPrn= hWnd;
	m_hWnd = CreateDialog(hInst,MAKEINTRESOURCE(IDD_FLD), m_hWPrn, CLSS_DLG_WNDPROC(CWndFld));

	RECT rt1;
	RECT rt2;
	INT		iWidth;
	INT		iHeight;
	INT		iX;
	INT		iY;

	GetWindowRect(m_hWPrn, &rt1);
	GetWindowRect(m_hWnd, &rt2);
	
	iWidth = rt2.right - rt2.left;
	iHeight=  rt2.bottom- rt2.top;

	iX = rt1.left + 200;
	iY = rt1.top  + 150;
	
	MoveWindow(m_hWnd, iX, iY, iWidth, iHeight, TRUE);


	m_iWx = m_iExt/m_iNx;

	SetDlgItemText(m_hWnd,	IDC_FLD_NAME, "Grave Zone");
	SetDlgItemInt(m_hWnd,	IDC_FLD_NUM_X, m_iNfX, 0);
	SetDlgItemInt(m_hWnd,	IDC_FLD_NUM_Z, m_iNfZ, 0);
	SetDlgItemInt(m_hWnd,	IDC_FLD_EXT, m_iExt, 0);

	CheckRadioButton(m_hWnd, IDC_FLD_LCL_Y, IDC_FLD_LCL_N, IDC_FLD_LCL_Y);

	SetDlgItemInt(m_hWnd,	IDC_FLD_LCL_NUM,	m_iNx, 0);
	SetDlgItemInt(m_hWnd,	IDC_FLD_LCL_WDT,	m_iWx, 0);
	SetDlgItemFlt(m_hWnd,	IDC_FLD_LCL_UV,		m_fUV, 0);
	
	return 1;
}

void CWndFld::ShowWindow(int _ishw)
{
	::ShowWindow(m_hWnd, _ishw);
}


void CWndFld::Destroy()
{
	SAFE_DESTROY_WINDOW(m_hWnd);
}

LRESULT CWndFld::MsgPrc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	WPARAM		wparHi = HIWORD(wParam);
	WPARAM		wparLo = LOWORD(wParam);

	switch( uMsg )
	{
		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDC_FLD_OK:
				{
					GetDlgItemText(hWnd, IDC_FLD_NAME, m_sN, sizeof(m_sN));
					m_iNfX	= GetDlgItemInt(hWnd, IDC_FLD_NUM_X, 0, 0);
					m_iNfZ	= GetDlgItemInt(hWnd, IDC_FLD_NUM_Z, 0, 0);
					m_iExt	= GetDlgItemInt(hWnd, IDC_FLD_EXT,	 0, 0);

					m_iNx	= GetDlgItemInt(m_hWnd,	IDC_FLD_LCL_NUM, 0, 0);
					m_iWx	= GetDlgItemInt(m_hWnd,	IDC_FLD_LCL_WDT, 0, 0);
					m_fUV	= GetDlgItemFlt(m_hWnd,	IDC_FLD_LCL_UV);

					GFIELD->CreateFld(m_sN, m_iNfX, m_iNfZ, m_iExt
						, m_bAll, m_iNx, m_iWx, m_fUV);
					
					SendMessage(hWnd, WM_CLOSE, 0, 0);

					break;
				}

				case IDC_FLD_CLOSE:
				{
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}

				case IDC_FLD_LCL_Y:
				{
					m_bAll = true;
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_NUM),	SW_SHOW);
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_WDT),	SW_SHOW);
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_UV),		SW_SHOW);
					break;
				}
					
				case IDC_FLD_LCL_N:
				{
					m_bAll = FALSE;
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_NUM),	SW_HIDE);
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_WDT),	SW_HIDE);
					::ShowWindow( GetDlgItem(hWnd, IDC_FLD_LCL_UV),		SW_HIDE);
					break;
				}


				case IDC_FLD_LCL_NUM:
				{
					switch(wparHi)
					{
						case EN_CHANGE:
							m_iExt	= GetDlgItemInt(hWnd, IDC_FLD_EXT,	 0, 0);
							m_iNx = GetDlgItemInt(hWnd, IDC_FLD_LCL_NUM, 0, 0);
							m_iWx = m_iExt/m_iNx;
							SetDlgItemInt(hWnd, IDC_FLD_LCL_WDT, m_iWx, 0);
							break;
					}

					break;
				}
			}

			break;
		}

		case WM_CLOSE:
		{
			DestroyWindow( hWnd );
			m_hWnd	= NULL;
			break;
		}
	}

	return(FALSE);
}