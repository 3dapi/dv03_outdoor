// Interface for the CLnMd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDMSH_H_
#define _MDMSH_H_


class CMdMsh																	// For Rendering
{
public:
	PDEV		m_pDev;
	INT			m_nType;														// Model Type

	char		m_sTx[128];
	PDTX		m_pTx;

	char		m_sMd[128];

	INT			m_iNix	;														// Count Vertex Index
	INT			m_iNvx	;														// Count Vertex

	DWORD		m_dFVF	;														// FVF
	INT			m_iVxS	;														// vertex structure size

	TBndAABB	m_BndInf;

	VtxIdx*		m_pIdx	;														// Vertex Face Index
	void*		m_pVtx	;														//	VtxD, VtxUV, VtxNUV, VtxNDUV	

public:
	CMdMsh();
	virtual ~CMdMsh();

	virtual INT		Create(void* p1);
	virtual void	Destroy();
	
	virtual void	Render();

	INT		Load(char* sFile);
	void	Copy(CMdMsh* pRhs);

public:
	void	SetMdlName(char* sMdl)	{	strcpy(m_sMd, sMdl);	}
	char*	GetMdlName()			{	return m_sMd;			}

	void	SetMdlTx(char* sTx)	{	strcpy(m_sTx, sTx);		}
	char*	GetMdlTx()				{	return m_sTx;			}

	void*	GetDev();

	TBndAABB*	GetBndInf() const;
};

#endif