// Interface for the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDBASE_H_
#define _MDBASE_H_


class CMdId
{
public:
	union	{	WORD nI1;	WORD wM;	};
	union	{	WORD nI2;	WORD wS;	};
	union	{	WORD nI3;	WORD wT;	};
	union	{	WORD nI4;	WORD wW;	};

	CMdId(): nI1(0xFFFF),nI2(0xFFFF),nI3(0xFFFF),nI4(0xFFFF){}
	virtual ~CMdId(){};

	void SetId(	WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void SetMSTW(WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void	SetM(WORD wV=0xFFFF){	wM = wV;	}
	void	SetS(WORD wV=0xFFFF){	wS = wV;	}
	void	SetT(WORD wV=0xFFFF){	wT = wV;	}
	void	SetW(WORD wV=0xFFFF){	wW = wV;	}

	WORD	GetM()		{	return wM;	}
	WORD	GetS()		{	return wS;	}
	WORD	GetT()		{	return wT;	}
	WORD	GetW()		{	return wW;	}

	WORD	GetId1()	{	return nI1;	}
	WORD	GetId2()	{	return nI2;	}
	WORD	GetId3()	{	return nI3;	}
	WORD	GetId4()	{	return nI4;	}
};


class CMdBase : public CMdId
{
protected:
	PDEV		m_pDev;
	void*		m_pCam;

	void*		m_pMsD;															// Mesh Dest Pointer
	void*		m_pMsS;															// Mesh Source Pointer

public:
	VEC3		m_vcE;															// Epsilon
	VEC3		m_vcR;															// Rotation
	VEC3		m_vcS;															// Scaling
	VEC3		m_vcT;															// Translation
	MATA		m_mtR;															// Rotation Matrix
	MATA		m_mtS;															// Scaling Matrix
	MATA		m_mtW;															// World which is mtW = mtR * mtS, mtW_41 = pos.x, ....

	FLOAT		m_fD;															// Distance from Camera
	FLOAT		fDistSort;														// Z Direction Value
	
	TBndAABB	m_BndInf;
	
public:
	CMdBase();
	virtual ~CMdBase();

	virtual	INT		Create(void* p1)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

	void	BndBoxTransform();
	void	BndBoxRender();

public:
	void*	GetMshSrc();
	void	SetMshSrc(void* pMshSrc);

	void*	GetMshDst();
	void	SetMshDst(void* pMshDst);

	void	SetDev(void* pDev);
	void	SetCam(void* pCam);

	void*	GetDev();
	void*	GetCam();

	VEC3	GetRot();
	void	SetRot(VEC3 pos);
	
	VEC3	GetScl();
	void	SetScl(VEC3 pos);

	VEC3	GetPos();
	void	SetPos(VEC3 pos);

	void		SetBndInf(TBndAABB* pBnd);
	TBndAABB*	GetBndInf() const;

protected:
	void	WorldMatrixSetup();
};


typedef std::vector<CMdBase* >	lsMdB;
typedef lsMdB::iterator			itMdB;


#endif