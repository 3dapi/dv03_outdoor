// Implementation of the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdMsh::CMdMsh()
:	m_iNix	(0)	
,	m_iNvx	(0)
,	m_dFVF	(0)
,	m_iVxS	(0)
,	m_pIdx	(0)
,	m_pVtx	(0)
{
	m_pDev = NULL;

	memset(m_sMd, 0, sizeof(m_sMd));
	memset(m_sTx, 0, sizeof(m_sTx));

	m_BndInf.SetColor(0xFF666666);
}


CMdMsh::~CMdMsh()
{
	Destroy();
}

void CMdMsh::Destroy()
{
	SAFE_FREE(	m_pIdx	);
	SAFE_FREE(	m_pVtx	);
}

INT CMdMsh::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	return 1;
}

void CMdMsh::Render()
{
	m_pDev->SetTexture(0, m_pTx);
	
	m_pDev->SetFVF(m_dFVF);
	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, m_iNvx, m_iNix
		, m_pIdx, D3DFMT_INDEX16
		, m_pVtx, m_iVxS);

//	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
//
//	m_BndInf.RenderBox(m_pDev);
}







INT CMdMsh::Load(char* sFile)
{
	INT		i=0;
	char	sTmp[512];

	GetPrivateProfileString("Header", "nType", NULL, sTmp, sizeof(sTmp), sFile);
	m_nType = atoi(sTmp);

	GetPrivateProfileString("Header", "dFvf", NULL, sTmp, sizeof(sTmp), sFile);
	m_dFVF = atol(sTmp);

	GetPrivateProfileString("Header", "iVcS", NULL, sTmp, sizeof(sTmp), sFile);
	m_iVxS= atoi(sTmp);

	GetPrivateProfileString("Header", "iNfce", NULL, sTmp, sizeof(sTmp), sFile);
	m_iNix = atoi(sTmp);

	GetPrivateProfileString("Header", "iNvtx", NULL, sTmp, sizeof(sTmp), sFile);
	m_iNvx = atoi(sTmp);


	GetPrivateProfileString("Header", "Texture", NULL, sTmp, sizeof(sTmp), sFile);
	strcpy(m_sTx, sTmp);

	if(0 == m_iNix || 0 == m_iNvx)
		return -1;

	m_pIdx = (VtxIdx*) malloc(m_iNix * sizeof(VtxIdx));
	m_pVtx = malloc(m_iNvx * m_iVxS);

	for(i=0; i<m_iNix; ++i)
	{
		VtxIdx	idx;
		GetPrivateProfileString("Idx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);
		sscanf(sTmp, "%d %d %d", &idx.a, &idx.b, &idx.c);

		m_pIdx[i] = idx;
	}

	if( VtxDUV1::FVF == m_dFVF)
	{
		for(i=0; i<m_iNvx; ++i)
		{
			VtxDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			((VtxDUV1*)m_pVtx)[i] = tVtx;
		}
	}

	else if(VtxNDUV1::FVF == m_dFVF)
	{
		for(i=0; i<m_iNvx; ++i)
		{
			VtxNDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %f  %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.n.x, &tVtx.n.y, &tVtx.n.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			tVtx.p *= 0.4f;
			((VtxNDUV1*)m_pVtx)[i] = tVtx;
		}
	}


	D3DXVECTOR3 vcMin;
	D3DXVECTOR3 vcMax;

	// Set Max and Min vertex Position
	D3DXComputeBoundingBox(	(D3DXVECTOR3*)m_pVtx
							, m_iNvx
							, D3DXGetFVFVertexSize( m_dFVF)
							, &vcMin
							, &vcMax);

	m_BndInf.Set(vcMin, vcMax);

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	m_sTx);
	m_pTx	= TBTX->SelectTx(nM, nS);
	
	return 1;
}



void CMdMsh::Copy(CMdMsh* pRhs)
{
	strcpy(m_sMd, pRhs->GetMdlName());
	strcpy(m_sTx, pRhs->GetMdlTx());

	this->m_nType= pRhs->m_nType;
	this->m_iNix = pRhs->m_iNix;
	this->m_iNvx = pRhs->m_iNvx;

	this->m_dFVF = pRhs->m_dFVF;
	this->m_iVxS = pRhs->m_iVxS;

	memcpy(&this->m_BndInf, &pRhs->m_BndInf, sizeof m_BndInf);

	m_pIdx	= (VtxIdx*) malloc(m_iNix * sizeof(VtxIdx));
	m_pVtx	= malloc(m_iNvx * m_iVxS);

	memcpy(m_pIdx, pRhs->m_pIdx, m_iNix * sizeof(VtxIdx));
	memcpy(m_pVtx, pRhs->m_pVtx, m_iNvx * m_iVxS);
	

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	m_sTx);
	m_pTx = TBTX->SelectTx(nM, nS);
}



void* CMdMsh::GetDev()
{
	return m_pDev;
}


TBndAABB* CMdMsh::GetBndInf() const
{
	return (TBndAABB*)&m_BndInf;
}