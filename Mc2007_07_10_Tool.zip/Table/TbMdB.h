// Interface for the CTbMdB class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _TBMDB_H_
#define _TBMDB_H_


class CMdMsh;


struct TbMdS
{
	char	sF[128];															// Model File
	INT		nTp;																// Model Type
	CMdMsh*	pSrc;																// Model Pointer

	TbMdS() : nTp(-1), pSrc(0){}
};


struct TbMdM
{
	INT		iN;																	// Number of Sub
	char	sP[128];															// Model Path

	TbMdS*	pS;
	
	TbMdM() : iN(-1), pS(0) {}
	~TbMdM(){	SAFE_DELETE_ARRAY(	pS	);	}
};



class CTbMdB
{
public:
	PDEV		m_pDev;

	char		m_sV[32];														// version
	INT			m_iN;															// Tx class Number
	TbMdM*		m_pM;															// Tx table
	
public:
	CTbMdB();
	virtual ~CTbMdB();
	
	INT		Create(void* p1);
	INT		Load(char *sFile);
	void	Destroy();


	INT		Create	(INT nM, INT nS, DWORD dwC=0);

	CMdMsh*	SelectMdB(INT nM, INT nS);
	INT		SelectIdx(INT* nM/*Out*/, INT* nS/*Out*/, char* sFile);
	
private:
	void Confirm();
};

#endif
