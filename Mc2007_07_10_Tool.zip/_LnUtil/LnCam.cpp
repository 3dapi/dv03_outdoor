// Implementation of the CLnCam class.
//
////////////////////////////////////////////////////////////////////////////////

#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"
#include "LnVtxFmt.h"

#include "LnUtil.h"

#include "LnCam.h"



CLnCam::CLnCam()
{
	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= VEC3(0,100,-300);
	m_vcLook	= VEC3(0,100,0);
	m_vcUp		= VEC3(0,1,0);

	m_fFv		= D3DX_PI/4.f;
	m_fNr		= 1.f;
	m_fFr		= 5000.f;
}

CLnCam::~CLnCam()
{
	SAFE_FREE(		m_pLine		);
}

INT	CLnCam::SetInit()
{
	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= VEC3(600, 400, -1000);
	m_vcLook	= VEC3(600, 300, 0);
	
	m_vcUp		= VEC3(0,1,0);

	m_fFv		= D3DX_PI/4.f;
	m_fNr		= 1.f;
	m_fFr		= 15000.f;

	return 1;
}

INT CLnCam::Create(void* p1, void* p2)
{
	m_pDev	= (LPDIRECT3DDEVICE9)p1;

	FLOAT* pVal = (FLOAT*)p2;

	m_fDxBackW = pVal[0];
	m_fDxBackH = pVal[1];
	
	m_fAs	= m_fDxBackW/m_fDxBackH;

	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFv, m_fAs, m_fNr, m_fFr);
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	INT		i, j;
	FLOAT	fMax;

	fMax = 10000;
	m_pLine = (VtxD*)malloc( (6 + 8*4 ) * 2 * sizeof(VtxD));

	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFF770000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFF770000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF007700);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF007700);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF000077);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF000077);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	j =6 * 2;

	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);

		m_pLine[j + 8*i +4 ] = VtxD( 16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
	}

	return 1;
}


INT CLnCam::Restore()
{
	Update();

	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);

	return 1;
}


INT CLnCam::FrameMove()
{
	Update();

	return 1;
}


INT CLnCam::Update()
{
	INT		i=0;
	MATA	mtVPInv;
	VEC3	vcB[4];

	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
	D3DXMatrixPerspectiveFovLH(&m_mtPrj, m_fFv, m_fAs, m_fNr, m_fFr);
	
	m_vcX.x = m_mtViw._11;
	m_vcX.y = m_mtViw._21;
	m_vcX.z = m_mtViw._31;

	m_vcY.x = m_mtViw._12;
	m_vcY.y = m_mtViw._22;
	m_vcY.z = m_mtViw._32;

	m_vcZ.x = m_mtViw._13;
	m_vcZ.y = m_mtViw._23;
	m_vcZ.z = m_mtViw._33;
	
	
	D3DXMatrixInverse(&m_mtViwI, 0, &m_mtViw);
	
	m_mtBill = m_mtViwI;
	m_mtBill._41 = m_mtBill._42 = m_mtBill._43 = 0;								// Bill board Matrix
	
	m_vcEye		= VEC3( m_mtViwI._41, m_mtViwI._42, m_mtViwI._43);				// Camera Position ReSetting
	m_mtVwPj	= m_mtViw * m_mtPrj;


	
	D3DXMatrixInverse(&mtVPInv, NULL, &m_mtVwPj);

	vcB[0] = VEC3(-1,-1, 1);
	vcB[1] = VEC3( 1,-1, 1);
	vcB[2] = VEC3( 1, 1, 1);
	vcB[3] = VEC3(-1, 1, 1);


	for(i=0; i<4; ++i)
		D3DXVec3TransformCoord(&vcB[i], &vcB[i], &mtVPInv);

	VEC3 vcFr = VEC3(m_mtViw._13, m_mtViw._23, m_mtViw._33);					// Far
	VEC3 vcNr = -vcFr;															// Near
	
	VEC3 vcZn = m_vcEye + vcFr * m_fNr;
	VEC3 vcZf = m_vcEye + vcFr * m_fFr;

	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[0], &vcZn, &vcNr);				// Near Plane
	D3DXPlaneFromPointNormal((D3DXPLANE*)&m_Frsm[1], &vcZf, &vcFr);				// Far Plane

	D3DXPlaneFromPoints((D3DXPLANE*)&m_Frsm[2], &m_vcEye, &vcB[0], &vcB[3]);	// Left
	D3DXPlaneFromPoints((D3DXPLANE*)&m_Frsm[3], &m_vcEye, &vcB[2], &vcB[1]);	// Right
	D3DXPlaneFromPoints((D3DXPLANE*)&m_Frsm[4], &m_vcEye, &vcB[3], &vcB[2]);	// Top
	D3DXPlaneFromPoints((D3DXPLANE*)&m_Frsm[5], &m_vcEye, &vcB[1], &vcB[0]);	// Bottom


	VEC3	vcN[4];

	vcN[0] = VEC3(-1, 0, 0);
	vcN[1] = VEC3( 1, 0, 0);
	vcN[2] = VEC3( 0, 1, 0);
	vcN[3] = VEC3( 0,-1, 0);


//	mtVPInv =  m_mtViw * m_mtPrj;
//	D3DXMatrixInverse(&mtVPInv, NULL, &mtVPInv);


	for(i=0; i<4; ++i)
	{
		D3DXVec3TransformCoord(&vcN[i], (VEC3*)&m_Frsm[2+i], &m_mtVwPj);
		D3DXVec3Normalize(&vcN[i], &vcN[i]);
	}
	
	return 1;
}


void CLnCam::SetTransForm()
{
	m_pDev->SetTransform(D3DTS_VIEW, &m_mtViw);
	m_pDev->SetTransform(D3DTS_PROJECTION, &m_mtPrj);
}




VEC3 CLnCam::Get3DDir(POINT* pt)
{
	VEC2	p2;

	p2.x = FLOAT(pt->x);
	p2.y = FLOAT(pt->y);

	// Get the pick ray from the mouse position

	FLOAT w = m_mtPrj._11;
	FLOAT h = m_mtPrj._22;
	
	m_vcScnPos.x =  ( 2.f * p2.x / m_fDxBackW - 1.f ) / w;
	m_vcScnPos.y = -( 2.f * p2.y / m_fDxBackH - 1.f ) / h;
	m_vcScnPos.z =  1.f;

	// Transform the screen space pick ray into 3D space
	// Ray Direction
	m_vcRayDir.x  = D3DXVec3Dot(&m_vcScnPos, &VEC3(m_mtViwI._11, m_mtViwI._21, m_mtViwI._31));
	m_vcRayDir.y  = D3DXVec3Dot(&m_vcScnPos, &VEC3(m_mtViwI._12, m_mtViwI._22, m_mtViwI._32));
	m_vcRayDir.z  = D3DXVec3Dot(&m_vcScnPos, &VEC3(m_mtViwI._13, m_mtViwI._23, m_mtViwI._33));

	return m_vcRayDir;
}


void CLnCam::Render()
{
	// Render Lines
	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	m_pDev->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER , D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER , D3DTEXF_LINEAR);

	m_pDev->SetRenderState( D3DRS_LIGHTING,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	LnUtil_SetWorldIdentity(m_pDev);
	m_pDev->SetTexture(0, 0);
	m_pDev->SetFVF(VtxD::FVF);
	m_pDev->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32, m_pLine, sizeof(VtxD));

	m_pDev->SetRenderState( D3DRS_LIGHTING,	dMnLgt);
}




void CLnCam::MoveSideward(FLOAT fSpeed)
{
	VEC3 tmp(m_mtViw._11, 0, m_mtViw._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CLnCam::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC3 tmp(m_mtViw._13, m_mtViw._23*fY, m_mtViw._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CLnCam::MoveX(FLOAT fSpeed)
{
	m_vcEye.x  += fSpeed;
	m_vcLook.x  += fSpeed;
}


void CLnCam::MoveZ(FLOAT fSpeed)
{
	m_vcEye.z  += fSpeed;
	m_vcLook.z  += fSpeed;
}




void CLnCam::MoveRotate(FLOAT fYaw, FLOAT fPitch)
{
	m_fYaw   = fYaw;
	m_fPitch = fPitch;
	
	MATA rot;
	VEC3 vcZ = m_vcLook-m_vcEye;
	VEC3 vcX;
	D3DXMatrixRotationY(&rot, m_fYaw);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
	
	m_vcLook = vcZ + m_vcEye;
	D3DXMatrixLookAtLH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	
	vcZ = m_vcLook - m_vcEye;
	vcX =VEC3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	
	D3DXMatrixRotationAxis(&rot, & vcX, m_fPitch);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

	m_vcLook = vcZ + m_vcEye;
}