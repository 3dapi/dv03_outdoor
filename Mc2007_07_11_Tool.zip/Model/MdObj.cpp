// Implementation of the CMdObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMdBill::CMdBill()
{
	m_eType	= MDL_BILL;
}



CMdBill::~CMdBill()
{
	Destroy();
}



INT CMdBill::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;

	m_pMsS = p2;
	m_pMsD = p3;

	if(NULL == m_pMsD)
	{
		CMdMsh*	pMshS = (CMdMsh*)m_pMsS;
		CMdMsh* pMshDst = new CMdMsh;
		pMshDst->Create(m_pDev);
		pMshDst->Copy(pMshS);

		m_pMsD = pMshDst;
	}

	return 1;
}


void CMdBill::Destroy()
{
}



INT CMdBill::FrameMove()
{
	if(!m_pMsS)
		return 0;

	int	 i =0;

	CMdMsh*	pMshS = (CMdMsh*)m_pMsS;
	CMdMsh*	pMshD = (CMdMsh*)m_pMsD;
	CLnCam*	pCam  = (CLnCam*)m_pCam;
	

	int		iSize = (pMshS->m_iNvx) * (pMshS->m_iVxS);
	void*	pMshDst = pMshD->m_pVtx;
	void*	pMshSrc = pMshS->m_pVtx;

	m_mtR  = pCam->GetMatrixViwI();
	VEC3	vcCam= VEC3(m_mtR._41, m_mtR._42, m_mtR._43);
	VEC3	vcZ	 = VEC3(m_mtR._31, m_mtR._32, m_mtR._33);
	VEC3	vcTmp;

	m_mtR._41 =0.f;
	m_mtR._42 =0.f;
	m_mtR._43 =0.f;

	m_mtW = m_mtR * m_mtS;
	
	m_mtW._41 = m_vcT.x;
	m_mtW._42 = m_vcT.y;
	m_mtW._43 = m_vcT.z;

	vcTmp = m_vcT - vcCam;
	fDistSort = D3DXVec3Dot(&vcZ, &vcTmp);

	memcpy(pMshDst, pMshSrc, iSize);

	VtxDUV1* pVtx = (VtxDUV1*)(pMshD->m_pVtx);

	m_vcE.y = -pVtx[2].p.y*.9f;

	SetColor( D3DXCOLOR( 1, 1, 1,  (1000.f)/fabsf(fDistSort)  ));

	for(i=0; i<4; ++i)
	{
		pVtx[i].d = m_dC;
		
		D3DXVec3TransformCoord(&pVtx[i].p, &pVtx[i].p, &m_mtW);
		pVtx[i].p += m_vcE;
	}

	//Transform Bound Box
	BndBoxTransform();


	return 1;
}

void CMdBill::Render()
{
	if(!m_pMsD)
		return;

	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x30);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	CMdMsh* pMsD = (CMdMsh*)m_pMsD;
	pMsD->Render();


	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}












CMdSolid::CMdSolid()
{
	m_eType	= MDL_SOLID;
}



CMdSolid::~CMdSolid()
{
	Destroy();
}



INT CMdSolid::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;
	m_pMsS = p2;

	FLOAT	fRotY = rand()%360;
	FLOAT	fRotZ = -7 + rand()%15;
	FLOAT	fRotX = -7 + rand()%15;
	fRotY = fRotY;
	fRotZ = fRotZ;
	fRotX = fRotX;

	SetRot( VEC3(fRotX, fRotY, fRotZ));
	
	return 1;
}


void CMdSolid::Destroy()
{
}


INT CMdSolid::FrameMove()
{
	CMdMsh*	pMshS	= (CMdMsh*)m_pMsS;
	CLnCam*	pCam	= (CLnCam*)m_pCam;

	MATA	mtViwI	= pCam->GetMatrixViwI();
	
	VEC3 vcCam	= VEC3(mtViwI._41, mtViwI._42, mtViwI._43);
	VEC3 vcZ	= VEC3(mtViwI._31, mtViwI._32, mtViwI._33);
	VEC3 vcTmp	= m_vcT-vcCam;

	fDistSort = D3DXVec3Dot(&vcZ, &vcTmp);


	//Transform Bound Box
	BndBoxTransform();

	return 1;
}


void CMdSolid::Render()
{
	if(!m_pMsS)
		return;

	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

//	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
//	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	CMdMsh* pMsS = (CMdMsh*)m_pMsS;
	pMsS->Render();

	LnUtil_SetWorldIdentity(m_pDev);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}





CMdPack2D::CMdPack2D()
{
	m_pDev = NULL;
}


CMdPack2D::~CMdPack2D()
{
	Destroy();
}


INT CMdPack2D::Create(void* p1)
{
	m_pDev = (PDEV)p1;
	
	return 1;
}


void CMdPack2D::Destroy()
{
	SAFE_DEL_LST(	m_vObj	);
}


INT CMdPack2D::FrameMove()
{
	INT		i;
	INT		iSize;

	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
		m_vObj[i]->FrameMove();

	for(i=0; i<iSize; ++i)
		GFIELD->AddObj2D(m_vObj[i]);

	return 1;
}


void CMdPack2D::Render()
{
	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		m_vObj[i]->BndBoxRender();
		m_vObj[i]->Render();
	}
}





void CMdPack2D::SetHeight()
{
	if(!m_pLcl)
		return;

	CMpLcl* pLcl = (CMpLcl*)m_pLcl;

	INT		iNx = pLcl->GetNx();
	INT		iWx = pLcl->GetWx();
	VEC3	pos = pLcl->GetPos();

	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		CMdBill* pMdB = m_vObj[i];
		VEC3	 vcPos=	pMdB->GetPos();
		FLOAT	 fY   = pLcl->GetHeight(vcPos);
		

		vcPos.y = fY;
		pMdB->SetPos(vcPos);
	}
}



void CMdPack2D::AddObj(CMdBill* pMdB, VEC3 vcP)
{
	if(!m_pLcl)
		return;

	CMpLcl* pLcl = (CMpLcl*)m_pLcl;

	vcP.y = pLcl->GetHeight(vcP);

	CMdMsh*	pSrc = (CMdMsh*)pMdB->GetMshSrc();
	PDEV	pDev = (PDEV)pSrc->GetDev();

	if(pSrc)
	{
		CMdBill*	pObj = NULL;
		CMdMsh*		pMshDst= new CMdMsh;

		_SAFE_NEWCREATE1( pObj, CMdBill, pDev);

		pMshDst->Create(pDev);
		pMshDst->Copy(pSrc);

		pObj->SetCam(GCAMGNL);
		pObj->SetMshSrc(pSrc);
		pObj->SetMshDst(pMshDst);
		
		pObj->SetPos(vcP);
		pObj->SetBndInf(pSrc->GetBndInf());
		
		m_vObj.push_back(pObj);
	}
}







CMdPack3D::CMdPack3D()
{
	m_pDev = NULL;
}


CMdPack3D::~CMdPack3D()
{
	Destroy();
}


INT CMdPack3D::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	return 1;
}


void CMdPack3D::Destroy()
{
	SAFE_DEL_LST(	m_vObj	);
}


INT CMdPack3D::FrameMove()
{
	INT		i;
	INT		iSize;

	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		CMdSolid*	pMdB = m_vObj[i];
		pMdB->FrameMove();
	}

	for(i=0; i<iSize; ++i)
	{
		CMdSolid*	pMdB = m_vObj[i];
		GFIELD->AddObj3D(pMdB);
	}

	return 1;
}


void CMdPack3D::Render()
{
	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		m_vObj[i]->BndBoxRender();
		m_vObj[i]->Render();
	}
}





void CMdPack3D::SetHeight()
{
	if(!m_pLcl)
		return;

	CMpLcl* pLcl = (CMpLcl*)m_pLcl;

	INT		iNx = pLcl->GetNx();
	INT		iWx = pLcl->GetWx();
	VEC3	pos = pLcl->GetPos();

	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		CMdSolid*	pMdB = m_vObj[i];
		VEC3		vcPos= pMdB->GetPos();
		FLOAT		fY	 = pLcl->GetHeight(vcPos);

		vcPos.y = fY;
		pMdB->SetPos(vcPos);
	}
}



void CMdPack3D::AddObj(CMdSolid* pMdB, VEC3 vcP)
{
	if(!m_pLcl)
		return;

	CMpLcl* pLcl = (CMpLcl*)m_pLcl;

	vcP.y = pLcl->GetHeight(vcP);

	CMdMsh*	pSrc = (CMdMsh*)pMdB->GetMshSrc();
	PDEV	pDev = (PDEV)pSrc->GetDev();

	if(pSrc)
	{
		CMdSolid* pObj = NULL;

		_SAFE_NEWCREATE1(pObj, CMdSolid, m_pDev);
		
		pObj->SetCam(GCAMGNL);

		pObj->SetMshSrc(pSrc);
		pObj->SetPos(vcP);
		pObj->SetBndInf(pSrc->GetBndInf());
				
		m_vObj.push_back(pObj);
	}
}