// Interface for the CLnMd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDOBJ_H_
#define _MDOBJ_H_


class CMdBill : public CMdBase
{
public:
	DCLR		m_dC;															// Color

public:
	CMdBill();
	virtual ~CMdBill();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();
	
	virtual	INT		FrameMove();
	virtual	void	Render();

public:
	void			SetColor(DWORD dc)		{	m_dC= dc;			}
};


typedef std::vector<CMdBill* >	lsMdl2D;
typedef lsMdl2D::iterator		itMdl2D;


class CMdSolid : public CMdBase
{
public:
	CMdSolid();
	virtual ~CMdSolid();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();
};


typedef std::vector<CMdSolid* >	lsMdl3D;
typedef lsMdl3D::iterator		itMdl3D;




class CMdPack2D
{
public:
	PDEV		m_pDev;
	
	void*		m_pLcl;
	lsMdl2D		m_vObj;

public:
	CMdPack2D();
	virtual ~CMdPack2D();
	
	virtual	INT		Create(void* p1);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	void	AddObj(CMdBill* pMdB, VEC3 vcP);

	void	SetHeight();
	void	SetLcl(void*	pLcl)			{	m_pLcl = pLcl;	}
};


class CMdPack3D
{
public:
	PDEV		m_pDev;

	void*		m_pLcl;
	lsMdl3D		m_vObj;

public:
	CMdPack3D();
	virtual ~CMdPack3D();
	
	virtual	INT		Create(void* p1);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	void	AddObj(CMdSolid* pMdB, VEC3 vcP);
	
	void	SetHeight();
	void	SetLcl(void*	pLcl)			{	m_pLcl = pLcl;	}
};



#endif