// Interface for the CLnCam class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNCAM_H_
#define _LNCAM_H_


class CLnCam
{
protected:
	PDEV		m_pDev;
	
	char		m_sN[128];														// Camera Name
	VEC3		m_vcEye;														// Camera position
	VEC3		m_vcLook;														// Look vector
	VEC3		m_vcUp;															// up vector

	FLOAT		m_fFv;															// Field of View
    FLOAT		m_fAs;															// Aspect Ratio
    FLOAT		m_fNr;															// Near
    FLOAT		m_fFr;															// Far
	FLOAT		m_fDxBackW;
	FLOAT		m_fDxBackH;

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	MATA		m_mtViw;														// View Matrix
	MATA		m_mtViwI;														// View Inverse Matrix
	MATA		m_mtBill;
	MATA		m_mtPrj;														// Projection Matrix
	MATA		m_mtVwPj;														// m_mtViw * m_mtPrj;

	DPLN		m_Frsm[6];														// Near, Far, Left, Right, Up, Down

	VEC3		m_vcX;
	VEC3		m_vcY;
	VEC3		m_vcZ;

	VEC3		m_vcScnPos;
	VEC3		m_vcRayDir;

	VtxD*		m_pLine;
	
public:
	CLnCam();
	virtual ~CLnCam();

	INT		Create(void* p1, void* p2);
	INT		FrameMove();
	void	Render();

	INT		SetInit();
	INT		Restore();

	char*	GetName()			{	return m_sN;		}
	void	SetName(char* sN)	{	strcpy(m_sN, sN);	}

	MATA	GetMatrixViw()		{	return m_mtViw;		}
	MATA	GetMatrixViwI()		{	return m_mtViwI;	}
	MATA	GetMatrixBll()		{	return m_mtBill;	}
	MATA	GetMatrixPrj()		{	return m_mtPrj;		}
	MATA	GetMatrixViwPrj()	{	return m_mtVwPj;	}
	DPLN*	GetFrustum()		{	return &m_Frsm[0];	}

	VEC3	GetEye()			{	return m_vcEye;		}
	VEC3	GetLook()			{	return m_vcLook;	}
	VEC3	GetUp()				{	return m_vcUp;		}

	void	SetPos(VEC3 vcP)	{	m_vcEye	= vcP;		}
	void	SetLook(VEC3 vcL)	{	m_vcLook= vcL;		}
	void	SetUp(VEC3 vcU)		{	m_vcUp	= vcU;		}

	FLOAT	GetNear()			{	return m_fNr;		}
    FLOAT	GetFar()			{	return m_fFr;		}
	void	SetNear(FLOAT fNr)	{	m_fNr	= fNr;		}
	void	SetFar(FLOAT  fFr)	{	m_fFr	= fFr;		}

	FLOAT	GetFov()			{	return m_fFv;		}
    FLOAT	GetApc()			{	return m_fAs;		}
	void	SetFov(FLOAT fFOV)	{	m_fFv	= fFOV;		}
	
	VEC3	Get3DDir(POINT* pt);
	VEC3	GetX()				{	return m_vcX;		}
	VEC3	GetY()				{	return m_vcY;		}
	VEC3	GetZ()				{	return m_vcZ;		}

	void	SetTransForm();


	// Individual Camera
	void	SetMatrixViw(MATA mtViw){	m_mtViw = mtViw;	}
	void	SetMatrixPrj(MATA mtPrj){	m_mtPrj = mtPrj;	}
	INT		Update();
	
	

public:
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	void	MoveX(FLOAT	fSpeed);
	void	MoveZ(FLOAT	fSpeed);

	void	MoveRotate(FLOAT fYaw, FLOAT fPitch);
};

#endif