// Interface for the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNINPUT_H_
#define _LNINPUT_H_


class CLnInput
{
protected:
	HINSTANCE				m_hInst;
	HWND					m_hWnd;
	PDEV					m_pDev;

	LPDIRECTINPUT8			m_pDInput;
	LPDIRECTINPUTDEVICE8	m_pDiKey;
	LPDIRECTINPUTDEVICE8	m_pDiMs;

	BYTE					KeyCur[256];
	BYTE					KeyOld[256];
	VEC3					vcMsCur;
	VEC3					vcMsOld;
	VEC3					vcDelta;
	DIMOUSESTATE			MsStCur;
	DIMOUSESTATE			MsStOld;

public:
	CLnInput();
	virtual ~CLnInput();

	INT		Create(void* p1);
	INT		FrameMove();

	BOOL	KeyDown(BYTE cKey);
	BOOL	KeyState(BYTE cKey);

	VEC3	GetMousePos();
	VEC3	GetMouseDelta();
	BOOL	GetMouseSt(INT nM);
	BOOL	ButtonDn(INT nM);
	BOOL	ButtonUp(INT nM);
	BOOL	ButtonSt(INT nM);
	BOOL	IsInRect(LnRc& rt);
	
protected:
	INT		InitDInput();
	INT		UpdateDInput();
};

#endif