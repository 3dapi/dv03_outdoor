// Interface for the ILnMdl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILNMDL_H_
#define _ILNMDL_H_


#pragma warning( disable : 4786)
#include <vector>


#ifndef interface
#define interface struct
#endif


#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}


interface ILnMdl
{
	LN_CLASS_DESTROYER(	ILnMdl	);

	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;


	virtual	INT		GetMdType()=0;
	virtual	void	SetMdType(INT eType)=0;

	virtual	FLOAT	GetSortDist()=0;	
};


INT LnMdl_Create(char* sCmd
				 , ILnMdl** pData
				 , void* p1=NULL	// LPDIRECT3DDEVICE9
				 , void* p2=NULL	// Source Mesh
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


typedef std::vector<ILnMdl* >		lsLnMdl;
typedef lsLnMdl::iterator			itLnMdl;



interface ILnMdPack
{
	LN_CLASS_DESTROYER(	ILnMdPack	);
	
	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;
	
	virtual INT		Query(char* sCmd, void* pData)=0;

//	virtual void	SetHeight()=0;
	virtual void	SetLcl(void* pLcl)=0;
	virtual void	AddObj(ILnMdl* pMdB
							, VEC3 vcP		// Position
							, void* p1		// Camera
							, void* p2		// Field
							, void* p3		// Field Local
							, void* p4		// Parent Package
							)=0;

	// For STL
	virtual	void		Push_Back(ILnMdl* pMdB)=0;
	virtual	INT			Size()=0;
	virtual	ILnMdl*		GetObj(int n)=0;
	virtual	void		Erase(int n)=0;	
};


INT LnMdl_CreatePack(char* sCmd
				 , ILnMdPack** pData
				 , void* p1=NULL	// LPDIRECT3DDEVICE9
				 , void* p2=NULL	// Local Field
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


typedef std::vector<ILnMdPack* >	lsLnMdPack;
typedef lsLnMdPack::iterator		itLnMdPack;



#endif