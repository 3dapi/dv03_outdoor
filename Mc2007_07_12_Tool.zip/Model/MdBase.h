// Interface for the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDBASE_H_
#define _MDBASE_H_


class CMdId
{
public:
	union	{	WORD nI1;	WORD wM;	};
	union	{	WORD nI2;	WORD wS;	};
	union	{	WORD nI3;	WORD wT;	};
	union	{	WORD nI4;	WORD wW;	};

	CMdId(): nI1(0xFFFF),nI2(0xFFFF),nI3(0xFFFF),nI4(0xFFFF){}
	virtual ~CMdId(){};

	void SetId(	WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void SetMSTW(WORD I1=0xFFFF
			,	WORD I2=0xFFFF
			,	WORD I3=0xFFFF
			,	WORD I4=0xFFFF){nI1=I1;nI2=I2;nI3=I3;nI4=I4;}

	void	SetM(WORD wV=0xFFFF){	wM = wV;	}
	void	SetS(WORD wV=0xFFFF){	wS = wV;	}
	void	SetT(WORD wV=0xFFFF){	wT = wV;	}
	void	SetW(WORD wV=0xFFFF){	wW = wV;	}

	WORD	GetM()		{	return wM;	}
	WORD	GetS()		{	return wS;	}
	WORD	GetT()		{	return wT;	}
	WORD	GetW()		{	return wW;	}

	WORD	GetId1()	{	return nI1;	}
	WORD	GetId2()	{	return nI2;	}
	WORD	GetId3()	{	return nI3;	}
	WORD	GetId4()	{	return nI4;	}
};


class CMdBase : public ILnMdl, public CMdId
{
public:
	enum	EMdType
	{
		MDL_NONE	=0,
		MDL_BILL	=1,
		MDL_SOLID	=2,
	};

protected:
	EMdType		m_eType;

	PDEV		m_pDev;
	void*		m_pCam;

	void*		m_pMsD;															// Mesh Dest Pointer
	void*		m_pMsS;															// Mesh Source Pointer

	void*		m_pMscl1;														// miscellany	Field
	void*		m_pMscl2;														// miscellany	Local
	void*		m_pMscl3;														// miscellany	Packate
	void*		m_pMscl4;														// miscellany	Not Use

public:
	VEC3		m_vcE;															// Epsilon
	VEC3		m_vcR;															// Rotation
	VEC3		m_vcS;															// Scaling
	VEC3		m_vcT;															// Translation
	MATA		m_mtR;															// Rotation Matrix
	MATA		m_mtS;															// Scaling Matrix
	MATA		m_mtW;															// World which is mtW = mtR * mtS, mtW_41 = pos.x, ....

	FLOAT		m_fDstCam;														// Distance from Camera
	FLOAT		fDistSort;														// Z Direction Value
	
	TBndAABB	m_BndInf;
	
public:
	CMdBase();
	virtual ~CMdBase();

	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Query(char* sCmd, void* pData);

	virtual	INT		GetMdType();
	virtual	void	SetMdType(INT eType);
	
	virtual	FLOAT	GetSortDist();

public:
	void*	GetMshSrc();
	void	SetMshSrc(void* pMshSrc);

	void*	GetMshDst();
	void	SetMshDst(void* pMshDst);

	void	SetDev(void* pDev);
	void	SetCam(void* pCam);

	void*	GetDev();
	void*	GetCam();

	VEC3	GetRot();
	void	SetRot(VEC3 pos);
	
	VEC3	GetScl();
	void	SetScl(VEC3 pos);

	VEC3	GetPos();
	void	SetPos(VEC3 pos);

public:
	void		BndBoxTransform();
	void		BndBoxRender();

	void		SetBndInf(TBndAABB* pBnd);
	TBndAABB*	GetBndInf() const;

protected:
	void	WorldMatrixSetup();
};


typedef std::vector<CMdBase* >	lsMdB;
typedef lsMdB::iterator			itMdB;


#endif