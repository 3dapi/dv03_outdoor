// Implementation of the CMdObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnUtil.h"
#include "../LnInclude/LnVtxFmt.h"

#include "ILnMdl.h"																// Model Base
#include "MdBase.h"																// Model Object
#include "MdMsh.h"																// Model Mesh

#include "MdPack.h"																// Model Pack




CMdPack::CMdPack()
{
	m_pDev = NULL;
}


CMdPack::~CMdPack()
{
	Destroy();
}


INT CMdPack::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;
	m_pLcl = p2;
	
	return 1;
}


void CMdPack::Destroy()
{
	SAFE_DEL_LST(	m_vObj	);
}


INT CMdPack::FrameMove()
{
	INT		i;
	INT		iSize;

	iSize = m_vObj.size();

	for(i=0; i<iSize; ++i)
	{
		ILnMdl*	pMdB = m_vObj[i];
		pMdB->FrameMove();
	}

	return 1;
}


void CMdPack::Render()
{
	INT		i;
	INT		iSize;
	
	iSize = m_vObj.size();
	
	for(i=0; i<iSize; ++i)
	{
		ILnMdl*		pMdB  = m_vObj[i];
		CMdBase*	pObj  = (CMdBase*)pMdB;
		
		pObj->BndBoxRender();
		pObj->Render();
	}
}





INT CMdPack::Query(char* sCmd, void* pData)
{
	if(0==_stricmp("local", sCmd))
	{
		INT nAdd = ((INT)m_pLcl);

		*((INT*)pData) = nAdd;
		
		return 0;
	}

	return -1;
}





void CMdPack::AddObj(ILnMdl* pMdB
							, VEC3 vcP		// Position
							, void* p1		// Camera
							, void* p2		// Field
							, void* p3		// Field Local
							, void* p4		// Parent Package
							)
{
	if(!m_pLcl)
		return;

	CMdBase*	pObj = (CMdBase*)pMdB;
	CMdMsh*		pSrc = (CMdMsh*)pObj->GetMshSrc();

	PDEV		pDev = (PDEV)pSrc->GetDev();
	INT			nType= pMdB->GetMdType();

	ILnMdl*		pMdl = NULL;

	if(!pSrc)
		return;

	if(CMdBase::EMdType::MDL_BILL == nType)
		LnMdl_Create("billboard", &pMdl, m_pDev, pSrc);

	else if(CMdBase::EMdType::MDL_SOLID == nType)
		LnMdl_Create("solid", &pMdl, m_pDev, pSrc);


	if(!pMdl)
		return;

	pObj  = (CMdBase*)pMdl;

	pObj->SetPos(vcP);
	pObj->SetCam(p1);
	pObj->SetBndInf(pSrc->GetBndInf());

	pObj->Query("set field", p2);
	pObj->Query("set local", p3);
	pObj->Query("set package", p4);

	m_vObj.push_back(pMdl);
}





//void CMdPack::SetHeight(VEC3 vcP)
//{
//	if(!m_pLcl)
//		return;
//
//	INT		i;
//	INT		iSize;
//	
//	iSize = m_vObj.size();
//	
//	for(i=0; i<iSize; ++i)
//	{
//		ILnMdl*		pMdB  = m_vObj[i];
//		CMdBase*	pObj  = (CMdBase*)pMdB;
//		
//		VEC3		vcPos=	pObj->GetPos();
//		FLOAT		fY   = pLcl->GetHeight(vcPos);
//		
//		vcPos.y = fY;
//		pObj->SetPos(vcPos);
//	}
//}


void CMdPack::SetLcl(void*	pLcl)
{
	m_pLcl = pLcl;
}



void CMdPack::Push_Back(ILnMdl* pMdB)
{
	m_vObj.push_back(pMdB);
}

INT CMdPack::Size()
{
	return m_vObj.size();
}

ILnMdl*	CMdPack::GetObj(int n)
{
	INT iSize = m_vObj.size();

	if(n<0 || n>=iSize)
		return NULL;

	return m_vObj[n];
}


void CMdPack::Erase(int n)
{
	INT iSize = m_vObj.size();

	if(n<0 || n>=iSize)
		return;

	itLnMdl it = m_vObj.begin() + n;
	ILnMdl* p = (*it);
	delete (p);
	m_vObj.erase(it);
}








