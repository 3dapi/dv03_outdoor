// Implementation of the ILnCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"
#include "LnVtxFmt.h"

#include "LnUtil.h"

#include "ILnCam.h"
#include "LnCam.h"



INT	ILnCam::SetInit()
{
	return 1;
}

INT ILnCam::Restore()
{
	return 1;
}


INT ILnCam::FrameMove()
{
	return 1;
}


INT ILnCam::Update()
{
	return 1;
}


void ILnCam::SetTransForm()
{
}




VEC3 ILnCam::Get3DDir(POINT* pt)
{
	return VEC3(0,0,0);
}


void ILnCam::Render()
{
}


void ILnCam::MoveSideward(FLOAT fSpeed)
{
}


void ILnCam::MoveForward(FLOAT fSpeed, FLOAT fY)
{
}


void ILnCam::MoveX(FLOAT fSpeed)
{
}


void ILnCam::MoveZ(FLOAT fSpeed)
{
}


void ILnCam::MoveRotate(FLOAT fYaw, FLOAT fPitch)
{
}


char* ILnCam::GetName()			{	return NULL;		}
void ILnCam::SetName(char* sN)	{						}

MATA ILnCam::GetMatrixViw()		{	return MATA(0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0);		}
MATA ILnCam::GetMatrixViwI()	{	return MATA(0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0);		}
MATA ILnCam::GetMatrixBll()		{	return MATA(0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0);		}
MATA ILnCam::GetMatrixPrj()		{	return MATA(0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0);		}
MATA ILnCam::GetMatrixViwPrj()	{	return MATA(0,0,0,0, 0,0,0,0, 0,0,0,0, 0,0,0,0);		}
DPLN* ILnCam::GetFrustum()		{	return NULL;		}

VEC3 ILnCam::GetEye()			{	return VEC3(0,0,0);	}
VEC3 ILnCam::GetLook()			{	return VEC3(0,0,0);	}
VEC3 ILnCam::GetUp()			{	return VEC3(0,0,0);	}

void ILnCam::SetPos(VEC3 vcP)	{						}
void ILnCam::SetLook(VEC3 vcL)	{						}
void ILnCam::SetUp(VEC3 vcU)	{						}

FLOAT ILnCam::GetNear()			{	return 0.f;			}
FLOAT ILnCam::GetFar()			{	return 0.f;			}
void ILnCam::SetNear(FLOAT fNr)	{						}
void ILnCam::SetFar(FLOAT  fFr)	{						}

FLOAT ILnCam::GetFov()			{	return 0.f;			}
FLOAT ILnCam::GetApc()			{	return 0.f;			}
void ILnCam::SetFov(FLOAT fFOV)	{						}

VEC3 ILnCam::GetX()				{	return VEC3(0,0,0);	}
VEC3 ILnCam::GetY()				{	return VEC3(0,0,0);	}
VEC3 ILnCam::GetZ()				{	return VEC3(0,0,0);	}

void ILnCam::SetMatrixViw(MATA mtViw)	{				}
void ILnCam::SetMatrixPrj(MATA mtPrj)	{				}






INT LnCam_Create(char* sCmd, ILnCam** pData, void* p1, void* p2, void* p3, void* p4)
{
	(*pData) = NULL;
	
	CLnCam* pCam = NULL;

	pCam = new CLnCam;

	if(FAILED(pCam->Create(p1, p2, p3, p4)))
	{
		// Return Error Notification
		delete pCam;
		return -1;
	}

	(*pData) = pCam;
	
	return 0;
}
