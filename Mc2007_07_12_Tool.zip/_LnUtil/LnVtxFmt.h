// Interface for Ln vertex formats.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LNVTXFMT_H_
#define _LNVTXFMT_H_

struct VtxIdx																	// Index structure
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	VtxIdx()						: a(0),b(1),c(2){}
	VtxIdx(WORD A,WORD B,WORD C)	: a(A),b(B),c(C){}
	VtxIdx(WORD* R)					: a(R[0]),b(R[1]),c(R[2]){}

	operator WORD* ()				{	return (WORD *) &a;					}
	operator CONST WORD* () const	{	return (CONST WORD *) &a;			}
};



struct VtxD																		// Diffuse
{
	D3DXVECTOR3	p;
	D3DCOLOR	d;
	
	VtxD()							: p(0,0,0),d(0XFFFFFFFF){}
	VtxD(FLOAT X,FLOAT Y,FLOAT Z
		,D3DCOLOR D=0xFFFFFFFF)		: p(X,Y,Z),d(D){}

	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE) };
};



struct VtxDUV1																	// Diffuse + Texture 1
{
	D3DXVECTOR3	p;
	D3DCOLOR	d;
	FLOAT		u, v;
	
	VtxDUV1()						: p(0,0,0),u(0),v(0),d(0xFFFFFFFF){}
	VtxDUV1(FLOAT X,FLOAT Y,FLOAT Z
		,FLOAT U,FLOAT V
		, D3DCOLOR D=0xFFFFFFFF)	: p(X,Y,Z),u(U),v(V),d(D){}
	
	enum { FVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) };
};


struct VtxNDUV1																	// Normal + Diffuse + Texture1
{
	D3DXVECTOR3	p;
	D3DXVECTOR3	n;
	D3DCOLOR	d;
	FLOAT		u,v;

	VtxNDUV1()						: p(0,0,0),n(0,0,0),u(0),v(0),d(0xFFFFFFFF){}
	VtxNDUV1(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT nX,FLOAT nY,FLOAT nZ
			,FLOAT U,FLOAT V
			,D3DCOLOR D=0xFFFFFFFF)	: p(X,Y,Z),n(nX,nY,nZ),u(U),v(V),d(D){}

	enum { FVF = (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1) };
};


#endif

