// Program start.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CMain*			g_pApp	= 0	;


#if EXC_MTX_ON
	HANDLE		g_hMtx		= NULL;
#endif


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
#if EXC_MTX_ON
	// ������ ���α׷��� ����ǰ� �ִ��� Ȯ��
	if(g_hMtx = OpenMutex(SYNCHRONIZE, FALSE, EXC_MTX))
		return -1;
#endif


	LnUtil_InitEnvironment();
	
	
	CMain	d3dApp;
	g_pApp  = &d3dApp;

	InitCommonControls();
    	
	
	if( FAILED( d3dApp.Create( hInst ) ) )
        return -1;
	
#if EXC_MTX_ON
		g_hMtx = CreateMutex(NULL, TRUE, EXC_MTX);
#endif
	
    d3dApp.Run();


#if EXC_MTX_ON
	if(g_hMtx)	{	CloseHandle(g_hMtx);	g_hMtx	= NULL;	}
#endif

	return 0;
}





BOOL CALLBACK InfoDlgProc(HWND hDlg,UINT iMessage,WPARAM wParam,LPARAM lParam)
{
	switch(iMessage)
	{
		case WM_INITDIALOG:
		{
			RECT rt1;
			RECT rt2;

			INT iWidth;
			INT iHeight;

			INT iX;
			INT iY;


			GetWindowRect(GHWND, &rt1);
			GetWindowRect(hDlg, &rt2);
				
			iWidth = rt2.right - rt2.left;
			iHeight=  rt2.bottom- rt2.top;

			iX = rt1.left + 100;
			iY = rt1.top + 100;
			
			MoveWindow(hDlg, iX, iY, iWidth, iHeight, TRUE);

			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case IDC_HELP_CLOSE:
				{
					EndDialog(hDlg,IDOK);

					return TRUE;
				}

			}

			break;
		}
	}

	return FALSE;
}



LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_MOVE:
		{
			if(FALSE == m_bLoadingApp)
			{
				RECT rt1;
				RECT rt2;
				INT iWidth;
				INT iHeight;
				INT iX;
				INT iY;
				
				GetWindowRect(GHWND, &rt1);
				GetWindowRect(m_Wrk.m_hWnd, &rt2);
					
				iWidth = rt2.right - rt2.left;
				iHeight=  rt2.bottom- rt2.top;

				iX = rt1.left - iWidth;
				iY = rt1.top;// + iHeight;
				
				MoveWindow(m_Wrk.m_hWnd, iX, iY, iWidth, iHeight, TRUE);


			}

			break;
		}// case WM_MOVE
			

		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDM_TOGGLEFULLSCREEN:
				{
					if(m_bWindowed)
					{
						ShowWindow(m_Wrk.m_hWnd, SW_HIDE);

						if(m_Wrk.m_WndLyr.m_bShow)
						{
							ShowWindow(m_Wrk.m_WndLyr.m_hWnd, SW_HIDE);
						}
					}
					else
					{
						ShowWindow(m_Wrk.m_hWnd, SW_SHOW);
						
						if(m_Wrk.m_WndLyr.m_bShow)
						{
							ShowWindow(m_Wrk.m_WndLyr.m_hWnd, SW_SHOW);
						}
					}


					break;
				}

				case IDM_SOLID:
				{
					if( D3DFILL_SOLID == m_bMnFill)
						m_bMnFill = D3DFILL_WIREFRAME;

					else
						m_bMnFill = D3DFILL_SOLID;

					if( D3DFILL_SOLID == m_bMnFill)
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LGT:
				{
					m_bMnLgt ^=1;

					if(m_bMnLgt)
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_FOG:
				{
					m_bMnFog ^=1;

					if(m_bMnFog)
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}
				
				case IDM_LINE_CAMERA:
				{
					m_bMnCam ^=1;

					if(m_bMnCam)
						CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LINE_LOCAL:
				{
					m_bMnLcl ^=1;

					if(m_bMnLcl)
						CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}


				case IDM_SHOW_FRAME:
				{
					m_bMnFrame ^=1;

					if(m_bMnFrame)
						CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_SHOW_SKY:
				{
					m_bMnSkydome ^=1;

					if(m_bMnSkydome)
						CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_SHOW_BNDBOX:
				{
					m_bMnBndBox ^=1;

					if(m_bMnBndBox)
						CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}


				case IDM_HELP:
				{
					if (DialogBox(m_hInst,MAKEINTRESOURCE(IDD_HELP),	hWnd,InfoDlgProc)==IDOK)
					{
					}

					break;
				}

			}

			break;

		}// case WM_COMMAND

	}
	
	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}