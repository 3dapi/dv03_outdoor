// Interface for the CMpFld class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MPFLD_H_
#define _MPFLD_H_


class CMpFld																	// Field Mananger
{
public:
	struct MpInf																	// Field Information
	{
		INT		nI;																	// Index
		char	sN[128];															// Name
		INT		iNfX;																// Number of Field for X Direction
		INT		iNfZ;																// Number of Field for Z Direction

		INT		iExt;																// Extent of Local for X Direction

		MpInf()
		{
			nI = -1;
			memset(sN, 0, sizeof(sN));
		}
	};


	struct MpEnv
	{
		DWORD		m_dAb;															// Ambient color
		DMTL		m_Mtl;															// Material
		
		DWORD		m_dFt;															// Fog Table Mode
		DWORD		m_dFc;															// Fog Color
		FLOAT		m_fFb;															// Fog Begin
		FLOAT		m_fFe;															// Fog End
		FLOAT		m_fFd;															// fog Density

		INT			m_iNl;															// Lighting Num
		DLGT*		m_pLg;															// Lighting

		MpEnv()
		{
			m_dAb	= 0;																// Ambient color
			memset(&m_Mtl, 0, sizeof(m_Mtl));											// Material

			m_dFt	= D3DFOG_LINEAR;
			m_dFc	= 0;																// Fog Color
			m_fFb	= 0;																// Fog Begin
			m_fFe	= 0;																// Fog End
			m_fFd	= 1.f;

			m_iNl	= 0;																// Lighting Num
			m_pLg	= 0;
		}

		~MpEnv()
		{
			SAFE_DELETE_ARRAY(	m_pLg	);
		}
	};


	struct Vec3T
	{
		INT 	iZ;
		INT 	iX;
		INT 	iK;
		VEC3	p;
		Vec3T(){}
		Vec3T(INT Z, INT X, INT K, VEC3 P) : iZ(Z), iX(X), iK(K), p(P){}
	};


protected:
	MpInf		m_Inf	;
	MpEnv		m_Env	;
	CMpLcl**	m_ppLcl	;


protected:	
	CMpLcl*		m_pLcT	;														// Local Temp

	CMpLcl*		m_pPkLc	;														// Picking Local
	lsTlPkT		m_vPkLc	;														// Picking Triangle from Local
	BOOL		m_bClck	;
	VEC3		m_vcPkLc;														// Final Picking Position from Local

	lsPkBndA	m_vPkObj;														// Picking Object Bound Box
	ILnMdl*		m_pPkObj;														// Picking Object
	VEC3		m_vcPkObj;														// Final Picking Object Position

	lsLnMdl		m_vObj2D;														// 2D Object List
	lsLnMdl		m_vObj3D;														// 3D Object List
	lsLnMdl		m_vObj;															// Object List

protected:
	PDEV		m_pDev;

public:
	CMpFld();
	virtual ~CMpFld();

	INT		Create(void* p1);
	void	Destroy();

	INT		FrameMove();
	void	Render();

	INT		Update();

	void	AddObj2D(ILnMdl* pMdB);
	void	AddObj3D(ILnMdl* pMdB);


public:
	void	RenderPck();
	void	CreateFld(char* sN, INT iNfX, INT iNfZ, INT iExt
						, BOOL bAll, INT iNx, INT iWx, FLOAT fUV);				// Create Field

	MpInf*	GetFldInf()	{	return &m_Inf;		}
	char*	GetFldName(){	return m_Inf.sN;	}


	INT		CreateLcl(INT iNx, INT iWx, FLOAT fUV, VEC3 pos);					// Create Local
	void	SetTx(CMpLcl* pLcl);


	void	SetMaterial(DMTL& mtrl);
	void	SetAmbientLight(DWORD& dAmLgt);
	void	SetLight(DLGT* pLgt, INT iSize);
	void	SetFog(DWORD dT, DWORD dC, FLOAT fBgn, FLOAT fEnd, FLOAT fDns);

	const MpEnv*	GetEnv()	const;


	void	EraseObj();


public:
	void*	GetPckObj()	{	return m_pPkObj;	}
	
protected:
	INT		PickField();
	INT		PickLocal();
	INT		PickObj();


public:
	INT		FileLoad();
	INT		FileSave();
};

#endif