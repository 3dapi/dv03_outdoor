// Implementation of the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnUtil.h"

#include "ILnMdl.h"
#include "MdBase.h"
#include "MdObj.h"
#include "MdPack.h"


INT LnMdl_Create(char* sCmd, ILnMdl** pData, void* p1, void* p2, void* p3, void* p4)
{
	(*pData) = NULL;

	if(0==_stricmp("billboard", sCmd))
	{
		CMdBill* pMdB = NULL;

		pMdB = new CMdBill;

		if(FAILED(pMdB->Create(p1, p2, p3, p4)))
		{
			// Return Error Notification
			delete pMdB;
			return -1;
		}

		(*pData) = pMdB;
		
		return 0;
	}

	else if(0==_stricmp("solid", sCmd))
	{
		CMdSolid* pMdB = NULL;

		pMdB = new CMdSolid;

		if(FAILED(pMdB->Create(p1, p2, p3, p4)))
		{
			// Return Error Notification
			delete pMdB;
			return -1;
		}

		(*pData) = pMdB;
		
		return 0;
	}


	return -1;
}




INT LnMdl_CreatePack(char* sCmd, ILnMdPack** pData, void* p1, void* p2, void* p3, void* p4)
{
	CMdPack* pMdPck = NULL;

	pMdPck = new CMdPack;

	if(FAILED(pMdPck->Create(p1, p2, p3, p4)))
	{
		// Return Error Notification
		delete pMdPck;
		return -1;
	}

	(*pData) = pMdPck;
	
	return 0;
}

