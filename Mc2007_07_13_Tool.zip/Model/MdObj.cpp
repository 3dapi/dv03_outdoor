// Implementation of the CMdObj class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnUtil.h"
#include "../LnInclude/LnVtxFmt.h"

#include "../LnInclude/ILnCam.h"

#include "ILnMdl.h"
#include "MdBase.h"														// Model Object
#include "IMdMsh.h"														// Model Mesh

#include "MdObj.h"														// Model Object


CMdBill::CMdBill()
{
	m_eType	= MDL_BILL;
}



CMdBill::~CMdBill()
{
	Destroy();
}



INT CMdBill::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;

	m_pMsS = p2;
	m_pMsD = p3;

	if(NULL == m_pMsD)
	{
		IMdMsh*	pMshS = (IMdMsh*)m_pMsS;
		IMdMsh* pMshDst = NULL;

		if(FAILED(LnMdl_CreateMsh(NULL, &pMshDst, m_pDev, pMshS)))
			return -1;

		pMshDst->Copy(pMshS);
		m_pMsD = pMshDst;
	}

	return 1;
}


void CMdBill::Destroy()
{
}



INT CMdBill::FrameMove()
{
	if(!m_pMsS)
		return 0;

	int	 i =0;

	IMdMsh*	pMshS = (IMdMsh*)m_pMsS;
	IMdMsh*	pMshD = (IMdMsh*)m_pMsD;
	ILnCam*	pCam  = (ILnCam*)m_pCam;	

	int		iSize = pMshS->GetNumVtx() * pMshS->GetZeroStrd();
	void*	pMshDst = pMshD->GetBufVtx();
	void*	pMshSrc = pMshS->GetBufVtx();

	m_mtR  = pCam->GetMatrixViwI();
	VEC3	vcCam= VEC3(m_mtR._41, m_mtR._42, m_mtR._43);
	VEC3	vcZ	 = VEC3(m_mtR._31, m_mtR._32, m_mtR._33);
	VEC3	vcTmp;

	m_mtR._41 =0.f;
	m_mtR._42 =0.f;
	m_mtR._43 =0.f;

	m_mtW = m_mtR * m_mtS;
	
	m_mtW._41 = m_vcT.x;
	m_mtW._42 = m_vcT.y;
	m_mtW._43 = m_vcT.z;

	vcTmp = m_vcT - vcCam;
	fDistSort = D3DXVec3Dot(&vcZ, &vcTmp);

	memcpy(pMshDst, pMshSrc, iSize);

	VtxDUV1* pVtx = (VtxDUV1*)(pMshD->GetBufVtx());

	m_vcE.y = -pVtx[2].p.y*.9f;

	SetColor( D3DXCOLOR( 1, 1, 1,  (1000.f)/fabsf(fDistSort)  ));

	for(i=0; i<4; ++i)
	{
		pVtx[i].d = m_dC;
		
		D3DXVec3TransformCoord(&pVtx[i].p, &pVtx[i].p, &m_mtW);
		pVtx[i].p += m_vcE;
	}

	//Transform Bound Box
	BndBoxTransform();


	return 1;
}

void CMdBill::Render()
{
	if(!m_pMsD)
		return;

	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);

	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x30);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	m_pDev->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	m_pDev->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );

	IMdMsh* pMsD = (IMdMsh*)m_pMsD;
	pMsD->Render();


	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}












CMdSolid::CMdSolid()
{
	m_eType	= MDL_SOLID;
}



CMdSolid::~CMdSolid()
{
	Destroy();
}



INT CMdSolid::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;
	m_pMsS = p2;

	FLOAT	fRotY = rand()%360;
	FLOAT	fRotZ = -7 + rand()%15;
	FLOAT	fRotX = -7 + rand()%15;
	fRotY = fRotY;
	fRotZ = fRotZ;
	fRotX = fRotX;

	SetRot( VEC3(fRotX, fRotY, fRotZ));
	
	return 1;
}


void CMdSolid::Destroy()
{
}


INT CMdSolid::FrameMove()
{
	IMdMsh*	pMshS	= (IMdMsh*)m_pMsS;
	ILnCam*	pCam	= (ILnCam*)m_pCam;

	MATA	mtViwI	= pCam->GetMatrixViwI();
	
	VEC3 vcCam	= VEC3(mtViwI._41, mtViwI._42, mtViwI._43);
	VEC3 vcZ	= VEC3(mtViwI._31, mtViwI._32, mtViwI._33);
	VEC3 vcTmp	= m_vcT-vcCam;

	fDistSort = D3DXVec3Dot(&vcZ, &vcTmp);


	//Transform Bound Box
	BndBoxTransform();

	return 1;
}


void CMdSolid::Render()
{
	if(!m_pMsS)
		return;

	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);

	m_pDev->SetTransform(D3DTS_WORLD, &m_mtW);

//	m_pDev->SetRenderState(D3DRS_LIGHTING, FALSE);
//	m_pDev->SetRenderState(D3DRS_CULLMODE, D3DCULL_CCW);
	m_pDev->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_ALPHAREF, 0x80);
	m_pDev->SetRenderState(D3DRS_ALPHAFUNC, D3DCMP_GREATEREQUAL);
	

	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	m_pDev->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	m_pDev->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	m_pDev->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );

	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	m_pDev->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	
	IMdMsh* pMsS = (IMdMsh*)m_pMsS;
	pMsS->Render();

	LnUtil_SetWorldIdentity(m_pDev);
	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}


