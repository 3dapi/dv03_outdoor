// Implementation of the CLnDxMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include <d3d9.h>
#include <d3dx9.h>
#include <dxfile.h>
#include <rmxfguid.h>
#include <rmxftmpl.h>
#include "LnD3DFile.h"



#ifndef SAFE_DELETE
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#endif

#ifndef SAFE_DELETE_ARRAY
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }
#endif

#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)      { if(p) { (p)->Release(); (p)=NULL; } }
#endif




CLnDxMsh::CLnDxMsh()
{
	m_pDev		= NULL;
	
	memset(m_sFile, 0, sizeof m_sFile);
	
	m_pMshSys	= NULL;
	m_pMshLcl	= NULL;
	m_dMtrl		= 0L;
	m_pMtrl     = NULL;
	m_pTxs      = NULL;
	m_bMtrl		= FALSE;
}


CLnDxMsh::~CLnDxMsh()
{
	Destroy();
}


INT CLnDxMsh::Create(void* pDev, void* sFile)
{
	LPD3DXBUFFER pAdjacencyBuffer = NULL;
	LPD3DXBUFFER pMtrlBuffer = NULL;
	HRESULT      hr;
	
	m_pDev = (LPDIRECT3DDEVICE9)pDev;
	
	
	// Load the mesh
	if( FAILED( hr = D3DXLoadMeshFromX( (char*)sFile
		, D3DXMESH_SYSTEMMEM
		, m_pDev
		, &pAdjacencyBuffer
		, &pMtrlBuffer
		, NULL
		, &m_dMtrl
		, &m_pMshSys ) ) )
	{
		return hr;
	}
	
	// Optimize the mesh for performance
	if( FAILED( hr = m_pMshSys->OptimizeInplace(
		D3DXMESHOPT_COMPACT | D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE,
		(DWORD*)pAdjacencyBuffer->GetBufferPointer(), NULL, NULL, NULL ) ) )
	{
		SAFE_RELEASE( pAdjacencyBuffer );
		SAFE_RELEASE( pMtrlBuffer );
		return hr;
	}
	
	if( pMtrlBuffer && m_dMtrl > 0 )
	{
		// Allocate memory for the materials and textures
		D3DXMATERIAL* d3dxMtrls = (D3DXMATERIAL*)pMtrlBuffer->GetBufferPointer();
		m_pMtrl = new D3DMATERIAL9[m_dMtrl];
		if( m_pMtrl == NULL )
		{
			hr = E_OUTOFMEMORY;
			goto LEnd;
		}
		m_pTxs  = new LPDIRECT3DTEXTURE9[m_dMtrl];
		if( m_pTxs == NULL )
		{
			hr = E_OUTOFMEMORY;
			goto LEnd;
		}
		
		// Copy each material and create its texture
		for( DWORD i=0; i<m_dMtrl; i++ )
		{
			// Copy the material
			m_pMtrl[i]         = d3dxMtrls[i].MatD3D;
			m_pTxs[i]          = NULL;
			
			// Create a texture
			if( d3dxMtrls[i].pTextureFilename )
			{
				char strTexture[MAX_PATH];
				
				strcpy(strTexture, d3dxMtrls[i].pTextureFilename);
				
				if( FAILED( D3DXCreateTextureFromFile( m_pDev, strTexture,
					&m_pTxs[i] ) ) )
					m_pTxs[i] = NULL;
			}
		}
	}
	hr = S_OK;
	
LEnd:
	SAFE_RELEASE( pAdjacencyBuffer );
	SAFE_RELEASE( pMtrlBuffer );
	
	return hr;
}





void CLnDxMsh::SetFVF(DWORD dFVF)
{
	LPD3DXMESH pTempSysMemMesh = NULL;
	LPD3DXMESH pTempLocalMesh  = NULL;
	
	if( m_pMshSys )
	{
		if( FAILED( m_pMshSys->CloneMeshFVF( D3DXMESH_SYSTEMMEM
			, dFVF
			, m_pDev
			, &pTempSysMemMesh ) ) )
			return;
	}
	
	if( m_pMshLcl )
	{
		if( FAILED( m_pMshLcl->CloneMeshFVF( 0L, dFVF, m_pDev,
			&pTempLocalMesh ) ) )
		{
			SAFE_RELEASE( pTempSysMemMesh );
			return;
		}
	}
	
	
	SAFE_RELEASE( m_pMshSys );
	SAFE_RELEASE( m_pMshLcl );
	
	if( pTempSysMemMesh ) m_pMshSys = pTempSysMemMesh;
	if( pTempLocalMesh )  m_pMshLcl  = pTempLocalMesh;
	
	// Compute normals in case the meshes have them
	if( m_pMshSys )
		D3DXComputeNormals( m_pMshSys, NULL );
	if( m_pMshLcl )
		D3DXComputeNormals( m_pMshLcl, NULL );
}



INT CLnDxMsh::Restore()
{
	if( NULL == m_pMshSys )
		return 0;
	
	
	if( FAILED( m_pMshSys->CloneMeshFVF( 0L
		, m_pMshSys->GetFVF()
		, m_pDev
		, &m_pMshLcl ) ) )
		return -1;
	
	return S_OK;
}



void CLnDxMsh::Invalidate()
{
	SAFE_RELEASE( m_pMshLcl );
}



void CLnDxMsh::Destroy()
{
	Invalidate();
	
	for( UINT i=0; i<m_dMtrl; i++ )
		SAFE_RELEASE( m_pTxs[i] );
	
	SAFE_DELETE_ARRAY( m_pTxs );
	SAFE_DELETE_ARRAY( m_pMtrl );
	
	SAFE_RELEASE( m_pMshSys );
	
	m_dMtrl = 0L;
}



void CLnDxMsh::Render(bool bDrawOpaqueSubsets, bool bDrawAlphaSubsets )
{
	if( NULL == m_pMshLcl )
		return;
	
	// Frist, draw the subsets without alpha
	if( bDrawOpaqueSubsets )
	{
		for( DWORD i=0; i<m_dMtrl; i++ )
		{
			if( m_bMtrl )
			{
				if( m_pMtrl[i].Diffuse.a < 1.0f )
					continue;
				m_pDev->SetMaterial( &m_pMtrl[i] );
				m_pDev->SetTexture( 0, m_pTxs[i] );
			}
			
			m_pMshLcl->DrawSubset( i );
		}
	}
	
	// Then, draw the subsets with alpha
	if( bDrawAlphaSubsets && m_bMtrl )
	{
		for( DWORD i=0; i<m_dMtrl; i++ )
		{
			if( m_pMtrl[i].Diffuse.a == 1.0f )
				continue;
			
			// Set the material and texture
			m_pDev->SetMaterial( &m_pMtrl[i] );
			m_pDev->SetTexture( 0, m_pTxs[i] );
			m_pMshLcl->DrawSubset( i );
		}
	}
	
	D3DXMATRIX mtW(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1);
	m_pDev->SetTransform(D3DTS_WORLD, &mtW);
}






void CLnDxMsh::UseMaterial(bool bVal)
{
	m_bMtrl = bVal;
}


//LPD3DXMESH CLnDxMsh::GetSysMemMesh()
//{
//	return m_pMshSys;
//}
//
//LPD3DXMESH CLnDxMsh::GetLocalMesh()
//{
//	return m_pMshLcl;
//}	