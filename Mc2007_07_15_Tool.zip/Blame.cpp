// Program start.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CMain*			g_pApp	= 0	;


#if EXC_MTX_ON
	HANDLE		g_hMtx		= NULL;
#endif


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
#if EXC_MTX_ON
	if(g_hMtx = OpenMutex(SYNCHRONIZE, FALSE, EXC_MTX))
		return -1;
#endif


	LnUtil_InitEnvironment();
	
	
	CMain	d3dApp;
	g_pApp  = &d3dApp;

	InitCommonControls();
    	
	if( FAILED( d3dApp.Create( hInst ) ) )
        return -1;
	


#if EXC_MTX_ON
		g_hMtx = CreateMutex(NULL, TRUE, EXC_MTX);
#endif
	

	d3dApp.Run();


#if EXC_MTX_ON
	if(g_hMtx)	{	CloseHandle(g_hMtx);	g_hMtx	= NULL;	}
#endif

	return 0;
}





