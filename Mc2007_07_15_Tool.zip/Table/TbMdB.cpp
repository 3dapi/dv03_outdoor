// Implementation of the CTbMdB class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


char* sCmdMd[] =
{
	"Version",			//0
		"TbMst",		//1
		"NumC",			//2
		
		"TbSub",		//3
		"Index",		//4
		"NumS",			//5
		"Path",			//6
		"Rec*",			//7
};



CTbMdB::CTbMdB()
:	m_iN	(-1)
,	m_pM	(0)
{
	m_pDev	= NULL;
}


CTbMdB::~CTbMdB()
{
	Destroy();
}

void CTbMdB::Destroy()
{
	INT i, j;
	
	for( i=0 ; i< m_iN; ++i)
	{
		for( j=0 ; j< m_pM[i].iN; ++j)
		{
			if(m_pM[i].pS[j].pSrc)
			{
				IMdMsh*	pMsh = (IMdMsh*)m_pM[i].pS[j].pSrc;

				SAFE_DELETE(	pMsh	);
				
				m_pM[i].pS[j].pSrc = NULL;
			}
		}
	}
	
	SAFE_DELETE_ARRAY(	m_pM	);
}


INT CTbMdB::Create(void* p1)
{
	m_pDev = (PDEV)p1;

	if(FAILED(Load("Data/TbMdB.dat")))
		return -1;
	
	return 1;
}


INT CTbMdB::Create(INT nM, INT nS, DWORD dwColor)
{
	char sFile[512] ="\0";
	
	sprintf(sFile, "%s%s", m_pM[nM].sP, m_pM[nM].pS[nS].sF);
	
	if(12==m_pM[nM].pS[nS].nTp || 13==m_pM[nM].pS[nS].nTp)
	{
		INT		nTm=-1, nTs=-1;
		IMdMsh*	pMsh = NULL;
		PDTX	pTx	= NULL;

		if(SUCCEEDED(LnMdl_CreateMsh(NULL, &pMsh, m_pDev)))
		{
			pMsh->SetMdlName(m_pM[nM].pS[nS].sF);
			pMsh->Load(sFile);

			TBTX->SelectIdx(&nTm, &nTs,	pMsh->GetTxName() );
			pTx	= TBTX->SelectTx(nTm, nTs);
			pMsh->SetTx(pTx);
			
			m_pM[nM].pS[nS].pSrc = pMsh;

			return 1;
		}
	}

	return -1;
}


void* CTbMdB::SelectMdB(INT nM, INT nS)
{
	if( nM < 0 || nM >= m_iN || nS<0 || nS >= m_pM[nM].iN)
		return NULL;
	
	if(!m_pM[nM].pS[nS].pSrc)
		Create(nM, nS, 0x00FFFFFF);
	
	if(!m_pM[nM].pS[nS].pSrc)
		return NULL;
		
	return m_pM[nM].pS[nS].pSrc;
}


INT	CTbMdB::SelectIdx(INT* nM/*Out*/, INT* nS/*Out*/, char* sFile)
{
	INT i, j;
	
	for( i=0 ; i< m_iN; ++i)
	{
		for( j=0 ; j< m_pM[i].iN; ++j)
		{
			if ( !_stricmp( m_pM[i].pS[j].sF, sFile) )
			{
				*nM = i;
				*nS = j;
				
				return 1;
			}
		}
	}

	*nM = -1;
	*nS = -1;
	
	return -1;
}


INT CTbMdB::Load(char * pcFileName)
{
	FILE * fp = NULL;
	char sLine[512]="\0";
	
	fp = fopen(pcFileName, "rt");
	
	if(NULL == fp)
		return -1;
	
#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sCmdMd[index], strlen(sCmdMd[index])))
	
	while(!feof(fp))
	{
		LnUtil_ReadFileLine(fp, sLine);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_sV);
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				LnUtil_ReadFileLine(fp, sLine);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE(2)
				{
					sscanf(sLine,"%*s %d", &m_iN);
					
					if(m_iN>0)
						m_pM = new TbMdM[m_iN];
				}
				
				
				READ_TEXT_LINE(3)
				{
					INT nM=-1;
					INT nS=0;
					
					while(!feof(fp))
					{
						LnUtil_ReadFileLine(fp, sLine);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(4)
						{
							sscanf(sLine, "%*s %d", &nM);
						}
						
						READ_TEXT_LINE(5)
						{
							INT iNumS=0;
							
							sscanf(sLine, "%*s %d", &iNumS);							
							
							if(iNumS>0)
							{
								m_pM[nM].iN =iNumS;
								m_pM[nM].pS = new TbMdS[iNumS];
							}
						}
						
						
						READ_TEXT_LINE(6)
						{
							sscanf(sLine, "%*s %s", m_pM[nM].sP);
							
							INT iLen = strlen(m_pM[nM].sP);
							
							if('/' != m_pM[nM].sP[ iLen-1] )
							{
								m_pM[nM].sP[iLen] ='/';
								m_pM[nM].sP[ iLen+1] ='\0';
							}
							
						}
						
						
						READ_TEXT_LINE(7)
						{
							sscanf(sLine, "%*s %*s %d %s"
								,	&m_pM[nM].pS[nS].nTp
								,	m_pM[nM].pS[nS].sF);
							
							++nS;
						}// if
					}//while
				}// if
			}// while
		}// if
		
#undef	READ_TEXT_LINE
	}// while
	
	fclose(fp);
	
	return 1;
}


void CTbMdB::Confirm()
{
	INT i, j;
	FILE * fp;
	
	fp = fopen("Data/TxConf.dat", "wt");
	
	fprintf(fp, "////////////////////////////////////////////////////\n//\n\n");
	fprintf(fp, "%s	%s\n\n", sCmdMd[0], m_sV);
	
	fprintf(fp, "%s\n",	sCmdMd[1]);
	fprintf(fp, "{\n");
	fprintf(fp, "	%s	%d\n", sCmdMd[2], m_iN);
	fprintf(fp, "\n");
	
	for(i=0; i< m_iN; ++i)
	{
		fprintf(fp, "	%s\n", sCmdMd[3]);
		fprintf(fp, "	{\n");
		fprintf(fp, "		%s	%d\n", sCmdMd[4], i);
		fprintf(fp, "		%s	%d\n", sCmdMd[5], m_pM[i].iN);
		fprintf(fp, "		%s	%s\n", sCmdMd[6], m_pM[i].sP);
		fprintf(fp, "\n");
		
		for(j=0; j< m_pM[i].iN; ++j)
			fprintf(fp, "		%s	%d	%d	%s\n",sCmdMd[7], j,	LnUtil_DWtoStr(m_pM[i].pS[j].nTp, TRUE),	m_pM[i].pS[j].sF);

		fprintf(fp, "	}\n\n");
	}

	fprintf(fp, "}");
	
	fclose(fp);
}