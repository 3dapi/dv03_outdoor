// Implementation of the CMdBase class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnVtxFmt.h"
#include "../LnInclude/LnUtil.h"

#include "ILnMdl.h"
#include "MdBase.h"
#include "IMdMsh.h"


CMdBase::CMdBase()
: m_eType(MDL_NONE)
, m_fDstCam	(0)
, fDistSort	(0)

, m_vcE	(0,0,0)
, m_vcR	(0,0,0)
, m_vcS	(1,1,1)
, m_vcT	(0,0,0)
, m_mtR	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtS	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
, m_mtW	(1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1)
{
	m_pDev	= NULL;
	m_pCam	= NULL;

	m_pMsD	= NULL;
	m_pMsS	= NULL;

	m_BndInf.SetColor(0xFF666666);
	m_BndInf.SetOwner(this);


	m_pMscl1	= NULL;					// miscellany	Field
	m_pMscl2	= NULL;					// miscellany	Local
	m_pMscl3	= NULL;
	m_pMscl4	= NULL;
}

CMdBase::~CMdBase()
{
	if(m_pMsD)
	{
		IMdMsh* pMshDst = (IMdMsh*)m_pMsD;
		delete pMshDst;
		m_pMsD = NULL;
	}
}


INT CMdBase::Create(void* p1, void* p2, void* p3, void* p4)
{
	return -1;
}

void CMdBase::Destroy()
{
}

INT CMdBase::FrameMove()
{
	return -1;
}

void CMdBase::Render()
{
}



INT CMdBase::Query(char* sCmd, void* pData)
{
	if(0==_stricmp("set bound", sCmd))
	{
		this->SetBndInf(pData);
	
		return 0;
	}

	else if(0==_stricmp("get bound", sCmd))
	{
		TBndAABB* pBnd = GetBndInf();
		INT nAddress = ((INT)pBnd);
		*((INT*)pData) = nAddress;

		return 0;
	}

	else if(0==_stricmp("set local", sCmd))
	{
		m_pMscl2	= pData;
	
		return 0;
	}

	else if(0==_stricmp("get local", sCmd))
	{
		INT nAddress = ((INT)m_pMscl2);
		*((INT*)pData) = nAddress;
		
		return 0;
	}

	else if(0==_stricmp("set field", sCmd))
	{
		m_pMscl1	= pData;
		
		return 0;
	}

	else if(0==_stricmp("get field", sCmd))
	{
		INT nAddress = ((INT)m_pMscl1);
		*((INT*)pData) = nAddress;
		
		return 0;
	}

	else if(0==_stricmp("set package", sCmd))
	{
		m_pMscl3	= pData;
		
		return 0;
	}

	else if(0==_stricmp("get package", sCmd))
	{
		INT nAddress = ((INT)m_pMscl3);
		*((INT*)pData) = nAddress;
		
		return 0;
	}

	else if(0==_stricmp("set ids", sCmd))
	{
		WORD*	wIds = (WORD*)pData;

		this->SetId(wIds[0], wIds[1], wIds[2], wIds[3]);
		
		return 0;
	}

	else if(0==_stricmp("get ids", sCmd))
	{
		WORD nI0 = this->GetId1();
		WORD nI1 = this->GetId2();
		WORD nI2 = this->GetId3();
		WORD nI3 = this->GetId4();

		*((WORD*)(pData)+0) = nI0;
		*((WORD*)(pData)+1) = nI1;
		*((WORD*)(pData)+2) = nI2;
		*((WORD*)(pData)+3) = nI3;
		
		return 0;
	}

	else if(0==_stricmp("bound box render", sCmd))
	{
		this->BndBoxRender();
		return 0;
	}


	return -1;
}



void CMdBase::BndBoxTransform()
{
	//Transform Bound Box
	IMdMsh*	pMshS = (IMdMsh*)m_pMsS;
	
	for(int i=0; i<8; ++i)
	{
		TBndAABB*	pBndInf= (TBndAABB*)pMshS->GetBndInf();
		D3DXVECTOR3  vcSrc = pBndInf->vcEdge[i].p;
		D3DXVECTOR3* vcDst = &(m_BndInf.vcEdge[i].p);
		
		D3DXVec3TransformCoord(vcDst, &vcSrc, &m_mtW);
		*vcDst += m_vcE;
	}

	m_BndInf.vcCent = m_BndInf.vcEdge[0].p + m_BndInf.vcEdge[7].p;
	m_BndInf.vcCent *=0.5f;

	m_BndInf.fR = D3DXVec3Length( &(m_BndInf.vcCent - m_BndInf.vcEdge[0].p));
}

void CMdBase::BndBoxRender()
{
	DWORD dMnLgt;
	m_pDev->GetRenderState( D3DRS_LIGHTING, &dMnLgt);
	
	// Render BoundBox
	m_pDev->SetRenderState( D3DRS_LIGHTING, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);

	m_BndInf.RenderBox(m_pDev);

	m_pDev->SetRenderState( D3DRS_LIGHTING, dMnLgt);
}




INT CMdBase::GetMdType()
{
	return m_eType;
}

void CMdBase::SetMdType(INT eType)
{
	m_eType = (EMdType) eType;
}


FLOAT CMdBase::GetSortDist()
{
	return fDistSort;
}



void* CMdBase::GetMshSrc()
{
	return m_pMsS;
}

void CMdBase::SetMshSrc(void* pMshSrc)
{
	m_pMsS = pMshSrc;
}


void* CMdBase::GetMshDst()
{
	return m_pMsD;
}

void CMdBase::SetMshDst(void* pMshDst)
{
	m_pMsD = pMshDst;
}


void CMdBase::SetDev(void* pDev)
{
	m_pDev = (PDEV)pDev;
}

void CMdBase::SetCam(void* pCam)
{
	m_pCam=pCam;
}


void* CMdBase::GetDev()
{
	return m_pDev;
}

void* CMdBase::GetCam()
{
	return m_pCam;
}




FLOAT* CMdBase::GetRot()
{
	return (FLOAT*)&m_vcR;
}

void CMdBase::SetRot(FLOAT* pVal)
{
	MATA	mtY;
	MATA	mtZ;
	MATA	mtX;

	VEC3*	pvcVal = (VEC3*)pVal;

	m_vcR = *pvcVal;

	D3DXMatrixRotationY(&mtY, D3DXToRadian(m_vcR.y));
	D3DXMatrixRotationZ(&mtZ, D3DXToRadian(m_vcR.z));
	D3DXMatrixRotationX(&mtX, D3DXToRadian(m_vcR.x));

	m_mtR = mtY * mtZ * mtX;

	WorldMatrixSetup();
}


FLOAT* CMdBase::GetScl()
{
	return (FLOAT*)&m_vcS;
}

void CMdBase::SetScl(FLOAT* pVal)
{
	VEC3*	pvcVal = (VEC3*)pVal;

	m_vcS = *pvcVal;

	m_mtS._11 = m_vcS.x;
	m_mtS._22 = m_vcS.y;
	m_mtS._33 = m_vcS.z;

	WorldMatrixSetup();
}


FLOAT* CMdBase::GetPos()
{
	return (FLOAT*)&m_vcT;
}

void CMdBase::SetPos(FLOAT* pVal)
{
	VEC3*	pvcVal = (VEC3*)pVal;

	m_vcT = *pvcVal;

	WorldMatrixSetup();
}



void CMdBase::WorldMatrixSetup()
{
	m_mtW = m_mtR * m_mtS;
	m_mtW._41 = m_vcT.x;
	m_mtW._42 = m_vcT.y;
	m_mtW._43 = m_vcT.z;
}



void CMdBase::SetBndInf(void* pBnd)
{
	memcpy(&m_BndInf, pBnd, sizeof(TBndAABB));

	m_BndInf.SetColor(0xFF666666);
	m_BndInf.SetOwner(this);
}


TBndAABB* CMdBase::GetBndInf() const
{
	return (TBndAABB*)&m_BndInf;
}