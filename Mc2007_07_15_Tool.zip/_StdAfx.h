// All Header files.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef __STDAFX_H_
#define __STDAFX_H_

#define STRICT
#define WIN32_LEAN_AND_MEAN														// Exclude rarely-used stuff from Windows headers
#define _WIN32_WINNT			0x0500
#define	WINVER					0x0400
#define DIRECTINPUT_VERSION		0x0800

#pragma once

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4238)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)


// Static Library
#pragma comment(lib, "shell32.lib"		)
#pragma comment(lib, "comctl32.lib"		)
#pragma comment(lib, "dinput8.lib"		)										// for Direct Input
#pragma comment(lib, "Version.lib"		)										// DX version Check


#ifdef _DEBUG
#pragma comment(lib, "LnD3D_.lib"	)											// DX Library
#pragma comment(lib, "LnUtil_.lib"	)											// Util Library
#pragma comment(lib, "LnMdl_.lib"	)											// Model
#else
#pragma comment(lib, "LnD3D.lib"	)											// DX Library
#pragma comment(lib, "LnUtil.lib"	)											// Util Library
#pragma comment(lib, "LnMdl.lib"	)											// Model
#endif

// STL
#include <vector>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;



#include <windows.h>

#include <comdef.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <atlbase.h>
#include <malloc.h>
#include <math.h>
#include <mmsystem.h>
#include <process.h>
#include <shellapi.h>
#include <shlobj.h>
#include <stdio.h>
#include <tchar.h>
#include <time.h>


#include <D3D9.h>
#include <d3dx9.h>

#include <dinput.h>
#include <rmxfguid.h>

#include "resource.h"


////////////////////////////////////////////////////////////////////////////////
// Global pointer Macro..

// Blame File version
#define BL_DX_VER		0x00090002

// Blame File version
#define BL_FL_VER		0x00000101


#define EXC_TITLE	"BLAME_MAP"
#define EXC_VER		"0.10.01"
#define EXC_MTX		EXC_TITLE"_"EXC_VER
#define EXC_MTX_ON	1


#define GMAIN				g_pApp
#define GHWND				g_pApp->GetDxHwnd()
#define GDEVICE				g_pApp->GetDxDevice()
#define GSPRITE				g_pApp->GetDxSprite()
#define GBACKSF				g_pApp->GetDxSurface()

#define GINPUT				g_pApp->m_pInput

#define TBTX				g_pApp->m_pTbTx
#define TBMDB				g_pApp->m_pTbMd

#define GCAMGNL				g_pApp->m_pCamG
#define GCAMOBJ				g_pApp->m_pCamO
#define GFIELD				g_pApp->m_pFld


////////////////////////////////////////////////////////////////////////////////
//

// LnInclude files
#include "LnInclude/D3DApp.h"
#include "LnInclude/LnType.h"													// Base type
#include "LnInclude/LnVtxFmt.h"													// vertex format

// Utilities
#include "LnInclude/LnD3Dfile.h"												// D3DX X-file

#include "LnInclude/LnUtil.h"													// Util
#include "LnInclude/ILnInput.h"													// Keyboard and Mouse class
#include "LnInclude/ILnCam.h"													// Camera

// Model
#include "LnInclude/ILnMdl.h"													// Model Object
#include "LnInclude/IMdMsh.h"													// Model Mesh


// Table
#include "Table/TbTx.h"
#include "Table/TbMdB.h"


// Field
#include "Field/MpLcl.h"
#include "Field/MpFld.h"


// Main class
#include "Main/WndFld.h"
#include "Main/WndLcl.h"
#include "Main/WndMtrl.h"
#include "Main/WndLght.h"
#include "Main/WndFog.h"
#include "Main/WndLyr.h"
#include "Main/WndObj.h"
#include "Main/WndWrk.h"

#include "Main/Main.h"															// Main class

#endif
