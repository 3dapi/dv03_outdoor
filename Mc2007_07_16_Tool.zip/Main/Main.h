// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CD3DApplication
{
public:
	char			m_sMsg[512]	;
	LPD3DXFONT		m_pDxFnt	;
	ILnInput*		m_pInput	;												// Keyboard Mouse
	ILnCam*			m_pCamG		;												// for Global World
	ILnCam*			m_pCamO		;												// for Object World

	PDTX			m_pSkyTexture;
	CLnDxMsh*		m_pSkyDome	;

	CTbTx*			m_pTbTx		;
	CTbMdB*			m_pTbMd		;

public:
	CMpFld*			m_pFld		;
	CWndWrk			m_WndWrk	;

	TlSwpWn			m_SwpWn		;												// Swap Chain Window
	DVWP			m_Vp		;												// View port

public:
	INT				m_bMnLgt	;
	INT				m_bMnFog	;
	INT				m_bMnFill	;
	INT				m_bMnCam	;
	INT				m_bMnLcl	;
	INT				m_bMnFrame	;
	INT				m_bMnSkydome;
	INT				m_bMnBndBox	;
	INT				m_bCulling	;

public:
	CMain();
	virtual ~CMain();

	virtual HRESULT		Init();
	virtual HRESULT		Destroy();

	virtual HRESULT		Restore();
	virtual HRESULT		Invalidate();

	virtual HRESULT		FrameMove();
	virtual HRESULT		Render();

	virtual LRESULT		MsgProc(HWND, UINT, WPARAM, LPARAM);

	static BOOL WINAPI	AboutPrc(HWND,UINT,WPARAM,LPARAM);
};

// Extern
extern	CMain*			g_pApp	;												// Main application

#endif
