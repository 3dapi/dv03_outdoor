// Implementation of the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#define DIRECTINPUT_VERSION		0x0800
#include <dinput.h>

#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"

#include "LnUtil.h"														// Util
#include "ILnInput.h"
#include "LnInput.h"



INT LnInput_Create(char* sCmd
				 , ILnInput** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2			// Window Handle
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{
	(*pData) = NULL;

	CLnInput* pInput = NULL;

	pInput	= new CLnInput;

	if(FAILED(pInput->Create(p1, p2, p3, p4)))
	{
		// Return Error Notification
		delete pInput;
		return -1;
	}

	(*pData) = pInput;
	
	return 0;
}