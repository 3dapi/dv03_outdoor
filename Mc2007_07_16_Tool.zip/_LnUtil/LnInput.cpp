// Implementation of the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include <windows.h>

#define DIRECTINPUT_VERSION		0x0800
#include <dinput.h>

#include <D3D9.h>
#include <d3dx9.h>

#include "LnType.h"

#include "LnUtil.h"														// Util
#include "ILnInput.h"
#include "LnInput.h"


CLnInput::CLnInput()
{
	m_hInst		= NULL;
	m_hWnd		= NULL;
	m_pDev		= NULL;

	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMs		= NULL;
}

CLnInput::~CLnInput()
{
	SAFE_RELEASE(	m_pDiKey	);
	SAFE_RELEASE(	m_pDiMs		);
	SAFE_RELEASE(	m_pDInput	);
}


void CLnInput::Destroy()
{
	if(m_pDiKey)
	{
		m_pDiKey->Release();
		m_pDiKey = NULL;
	}

	if(m_pDiMs)
	{
		m_pDiMs->Release();
		m_pDiMs = NULL;
	}

	if(m_pDInput)
	{
		m_pDInput->Release();
		m_pDInput = NULL;
	}
}



INT CLnInput::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;

	if(!p2)
		m_hInst = (HINSTANCE) GetModuleHandle(NULL);
	else
		m_hInst = (HINSTANCE)p2;

	if(!p3)
	{
		D3DDEVICE_CREATION_PARAMETERS d3Parameter;
		m_pDev->GetCreationParameters(&d3Parameter);
		m_hWnd = d3Parameter.hFocusWindow;
	}
	else
		m_hWnd = (HWND)p3;


	memset(m_KeyCur, 0, sizeof(m_KeyCur));
	memset(m_KeyOld, 0, sizeof(m_KeyOld));
	memset(m_KeyMap, 0, sizeof(m_KeyMap));
	
	memset(m_BtnCur, 0, sizeof(m_BtnCur));
	memset(m_BtnOld, 0, sizeof(m_BtnOld));
	memset(m_BtnMap, 0, sizeof(m_BtnMap));
	
	memset(&m_vcMsCur, 0, sizeof(m_vcMsCur));
	memset(&m_vcMsOld, 0, sizeof(m_vcMsOld));
	memset(&m_MsStCur, 0, sizeof(m_MsStCur));
	memset(&m_MsStOld, 0, sizeof(m_MsStOld));

	InitDInput();
	
	return 1;
}




INT CLnInput::FrameMove()
{
	INT i=0;

	m_vcDelta = m_vcMsCur - m_vcMsOld;

	memcpy(m_KeyOld		, m_KeyCur	, sizeof(m_KeyCur	));

	memcpy(m_BtnOld		, m_BtnCur	, sizeof(m_BtnCur	));
	memcpy(&m_vcMsOld	, &m_vcMsCur, sizeof(m_vcMsCur	));
	memcpy(&m_MsStOld	, &m_MsStCur, sizeof(m_MsStCur	));

	memset(&m_MsStCur, 0  , sizeof(m_MsStCur));

	UpdateDInput();


	POINT	MsPos;
	GetCursorPos(&MsPos);
	::ScreenToClient(m_hWnd, &MsPos);

	m_pDev->SetCursorPosition( MsPos.x, MsPos.y, 0 );

	m_vcMsCur.x = FLOAT(MsPos.x);
	m_vcMsCur.y = FLOAT(MsPos.y);

	m_vcMsCur.z += FLOAT(m_MsStCur.lZ);


	for(i=0; i<256; ++i)
	{
		m_KeyCur[i] = (m_KeyCur[i] & 0x80)? 1: 0;

		INT nOld = m_KeyOld[i];
		INT nCur = m_KeyCur[i];

		if		(0 == nOld && 1 ==nCur)	m_KeyMap[i] = INPUTST_DOWN	;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_KeyMap[i] = INPUTST_UP	;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_KeyMap[i] = INPUTST_PRESS	;		// Press
	}

	for(i=0; i<8; ++i)
	{
		m_BtnCur[i] = (m_MsStCur.rgbButtons[i] & 0x80)? 1: 0;

		INT nOld = m_BtnOld[i];
		INT nCur = m_BtnCur[i];

		if		(0 == nOld && 1 ==nCur)	m_BtnMap[i] = INPUTST_DOWN	;		// Down
		else if	(1 == nOld && 0 ==nCur)	m_BtnMap[i] = INPUTST_UP	;		// Up
		else if	(1 == nOld && 1 ==nCur)	m_BtnMap[i] = INPUTST_PRESS	;		// Press
	}


	//	m_BtnMap[0] = m_MsStCur.rgbButtons[0];	// L BUTTON
	//	m_BtnMap[1] = m_MsStCur.rgbButtons[1];	// R BUTTON
	//	m_BtnMap[2] = m_MsStCur.rgbButtons[2];	// M BUTTON

	
	return 1;
}




INT CLnInput::Query(char* sCmd, void* pData)
{
	printf("CLnInput Query:%s\n", sCmd);
	return 0;
}






BYTE* CLnInput::GetKeyMap() const
{
	return (BYTE*)m_KeyMap;
}



BOOL CLnInput::KeyDown(INT nKey)
{
	return (INPUTST_DOWN == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInput::KeyUp(INT nKey)
{
	return (INPUTST_UP == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInput::KeyPress(INT nKey)
{
	return (INPUTST_PRESS == m_KeyMap[nKey])? 1: 0;
}

BOOL CLnInput::KeyState(INT nKey)
{
	return m_KeyMap[nKey];
}



BOOL CLnInput::ButtonDown(INT nBtn)
{
	return (INPUTST_DOWN == m_BtnMap[nBtn])? 1: 0;
}

BOOL CLnInput::ButtonUp(INT nBtn)
{
	return (INPUTST_UP == m_BtnMap[nBtn])? 1: 0;
}

BOOL CLnInput::ButtonPress(INT nBtn)
{
	return (INPUTST_PRESS == m_BtnMap[nBtn])? 1: 0;
}


BOOL CLnInput::ButtonState(INT nBtn)
{
	return m_BtnMap[nBtn];
}


FLOAT* CLnInput::GetMousePos()
{
	return (FLOAT*)&m_vcMsCur;
}

FLOAT* CLnInput::GetMouseDelta()
{
	return (FLOAT*)&m_vcDelta;
}


BOOL CLnInput::GetMouseMove()
{
	return (m_vcMsCur != m_vcMsOld) ? 1: 0;
}


BOOL CLnInput::IsInRect(INT left, INT top, INT right, INT bottom)
{
	return (	m_vcMsCur.x>=left
			&&	m_vcMsCur.y>=top
			&&	m_vcMsCur.x<=right
			&&	m_vcMsCur.y<=bottom);
}




INT CLnInput::InitDInput()
{
	if (FAILED(DirectInput8Create(	m_hInst,	DIRECTINPUT_VERSION,	IID_IDirectInput8,	(void **)&m_pDInput,	NULL)))
		return -1;
	
	
	
	// Keyboard
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
		return -1;
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		return -1;
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		return -1;


	
	// Mouse
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMs, NULL)))
		return -1;
	
	if (FAILED(m_pDiMs->SetDataFormat(&c_dfDIMouse2)))
		return -1;
	
	if (FAILED(m_pDiMs->SetCooperativeLevel(m_hWnd, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY)))
		return -1;

	
	
	return 1;
}


INT CLnInput::UpdateDInput()
{
	// Keyboard
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(m_KeyCur), (LPVOID)m_KeyCur)))
	{
		memset(m_KeyCur, 0, sizeof(m_KeyCur));
		
		if (FAILED(m_pDiKey->Acquire()))
			return -1;
	}



	// Mouse
	if (FAILED(m_pDiMs->GetDeviceState(sizeof(m_MsStCur), &m_MsStCur)))
	{
		if (FAILED(m_pDiMs->Acquire()))
			return -1;
	}


	return 1;
}