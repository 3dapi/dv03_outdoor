// Interface for the CLnXml class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LNXML_H_
#define _LNXML_H_


class CLnXml : public ILnXml
{
protected:
	BOOL	m_bCoInit;
	void*	m_pxmlDoc;															// IXMLDOMDocument*

public:
	CLnXml();
	virtual ~CLnXml();
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual void	Destroy();
	
	virtual INT		FileLoad(const char* sFile);


	virtual void*	ElmList(const char* sElm, void* pNodeParent);
	virtual void*	ElmNode(void* pNode, INT nIdx);
	virtual INT		ElmSize(void* pNode);
	virtual INT		ElmText(char* sOutput, void* pNode);
	virtual INT		ElmAttrb(char* sOutput, int sOutputSize, void* pNode, const char* sAttName);
};


#endif

