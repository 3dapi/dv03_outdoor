// Implementation of the IMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnVtxFmt.h"
#include "../LnInclude/LnUtil.h"

#include "IMdMsh.h"
#include "MdMsh.h"



INT LnMdl_CreateMsh(char* sCmd , IMdMsh** pData , void* p1, void* p2, void* p3, void* p4)
{
	(*pData) = NULL;

	CMdMsh* pMsh = NULL;

	pMsh = new CMdMsh;

	if(FAILED(pMsh->Create(p1, p2, p3, p4)))
	{
		// Return Error Notification
		delete pMsh;
		return -1;
	}

	(*pData) = pMsh;
	
	return 0;;
}