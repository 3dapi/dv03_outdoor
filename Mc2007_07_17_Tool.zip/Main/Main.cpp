// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "../_StdAfx.h"


CMain::CMain()
{
	SetClsName(EXC_MTX);

	m_dHicon		= IDI_MAIN_ICON;
	m_dHmenu		= IDR_MENU;
	m_dHdevalt		= IDM_CHANGEDEVICE;
	m_dHtoggle		= IDM_TOGGLEFULLSCREEN;
	m_dHexit		= IDM_EXIT;
	m_dHaccel		= IDR_MAIN_ACCEL;


	m_pDxFnt		= NULL;
	m_pInput		= NULL;
	m_pCamG			= NULL;
	m_pCamO			= NULL;

	m_pSkyTexture	= NULL;
	m_pSkyDome		= NULL;

	m_pTbTx			= NULL;
	m_pTbMd			= NULL;

	m_pFld			= NULL;

	m_bMnLgt		= FALSE;
	m_bMnFog		= FALSE;
	m_bMnFill		= D3DFILL_SOLID;
	m_bMnCam		= TRUE;
	m_bMnLcl		= TRUE;
	m_bMnFrame		= TRUE;
	m_bMnSkydome	= FALSE;

	m_bMnBndBox		= FALSE;
	m_bCulling		= TRUE;

	m_dScnPosX		=230;
	m_dScnPosY		=0;
}


CMain::~CMain()
{
}



HRESULT CMain::Init()
{
	SAFE_NEWCREATE1(m_pTbTx	,	CTbTx, GDEVICE	);
	SAFE_NEWCREATE1(m_pTbMd	,	CTbMdB, GDEVICE	);


	FLOAT fBack[2]={ FLOAT( GMAIN->GetDxBackW() ), FLOAT( GMAIN->GetDxBackH())};

	if(FAILED(LnCam_Create(NULL, &m_pCamG,	GDEVICE, fBack)))
		return -1;

	if(FAILED(LnCam_Create(NULL, &m_pCamO,	GDEVICE, fBack)))
		return -1;

	SAFE_NEWCREATE1(m_pFld	,	CMpFld, GDEVICE	);


	m_WndWrk.Create(m_hWnd);
	SetFocus(GHWND);


	if(FAILED(LnInput_Create(NULL, &m_pInput,	GDEVICE, m_hInst, m_hWnd)))
		return -1;


	m_pCamG->SetPos( VEC3(500, 50, -100));
	m_pCamG->SetLook(VEC3(500, 0, 500));
	m_pCamG->SetFar(6000);

	m_pCamG->Update();
	m_pCamG->SetTransForm();



	LOGFONT  lFnt= {16, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 1, VARIABLE_PITCH | FF_ROMAN, "Arial"};
	D3DXCreateFontIndirect(GDEVICE, &lFnt, &m_pDxFnt);


	SAFE_NEWCREATE2(m_pSkyDome,	CLnDxMsh, GDEVICE, "Model/SKY/skydome.x");

	INT nM=-1, nS=-1;
	TBTX->SelectIdx(&nM, &nS,	"Env_Sky.jpg");
	m_pSkyTexture = TBTX->SelectTx(nM, nS);



	if( D3DFILL_SOLID == m_bMnFill)
		CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnLgt)
		CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnFog)
		CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnCam)
		CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnLcl)
		CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnFrame)
		CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnSkydome)
		CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_UNCHECKED);


	if(m_bMnBndBox)
		CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_CHECKED);
	else
		CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_UNCHECKED);


	return S_OK;
}


HRESULT CMain::Destroy()
{
	SAFE_RELEASE(	m_pDxFnt	);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamG		);
	SAFE_DELETE(	m_pCamO		);
	SAFE_DELETE(	m_pTbTx		);
	SAFE_DELETE(	m_pTbMd		);

	SAFE_DELETE(	m_pFld		);

	SAFE_DESTROY(	&m_WndWrk	);

	SAFE_DELETE(	m_pSkyDome	);

	return S_OK;
}


HRESULT CMain::Restore()
{
	GDEVICE->GetViewport(&m_Vp);

	if(m_bWindowed)
	{
		GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &m_SwpWn.pB);
		GDEVICE->GetDepthStencilSurface(&m_SwpWn.pS);
	}

	SAFE_RESTORE(	&m_WndWrk	);
	SAFE_RESTORE(	m_pSkyDome	);

	m_pDxFnt->OnResetDevice();

	return S_OK;
}



HRESULT CMain::Invalidate()
{
	m_pDxFnt->OnLostDevice();

	SAFE_INVALID(	&m_WndWrk	);
	SAFE_INVALID(	m_pSkyDome	);

	m_SwpWn.Release();

	return S_OK;
}


HRESULT CMain::FrameMove()
{
	ILnMdl* pObj = NULL;

	if(m_pFld)
		pObj= (ILnMdl*)m_pFld->GetPckObj();

	HWND hWnd = GetActiveWindow();

	sprintf(m_sMsg, "%s %s", m_strDeviceStats, m_strFrameStats );

	SAFE_FRMOV(	m_pInput	);													// Update Input

	VEC3 vcD = GINPUT->GetMouseDelta();
	FLOAT fCamSpeed = 10.f;

	if(hWnd && hWnd == GHWND)
	{
		if(vcD.z !=0.f)
			m_pCamG->MoveForward(-vcD.z* 1.f, 1.f);

		if(GINPUT->KeyPress(DIK_W))					// W
			m_pCamG->MoveForward( fCamSpeed, 1.f);

		if(GINPUT->KeyPress(DIK_S))					// S
			m_pCamG->MoveForward(-fCamSpeed, 1.f);

		if(GINPUT->KeyPress(DIK_A))					// A
			m_pCamG->MoveSideward(-fCamSpeed);

		if(GINPUT->KeyPress(DIK_D))					// D
			m_pCamG->MoveSideward(fCamSpeed);

		if(GINPUT->ButtonPress(1))
		{
			FLOAT	fYaw	= D3DXToRadian(vcD.x * 0.1f);
			FLOAT	fPitch	= D3DXToRadian(vcD.y * 0.1f);
			m_pCamG->MoveRotate(fYaw, fPitch);
		}
	}

	else if(hWnd == m_WndWrk.m_hWnd && GMAIN->IsWindow())
	{
		if( GetAsyncKeyState(VK_ADD)&0X8000 )
			m_pCamO->MoveForward(-2.f, 1.f);

		if( GetAsyncKeyState(VK_SUBTRACT)&0X8000 )
			m_pCamO->MoveForward(2.f, 1.f);
	}


	if(GINPUT->KeyPress(DIK_DELETE))
	{
		if(pObj)
		{
			m_pFld->EraseObj();
			pObj = NULL;
		}
	}


	if(pObj)
	{
		VEC3	vcPos = pObj->GetPos();

		if(GINPUT->KeyPress(DIK_LEFT))
			vcPos.x -=1;

		if(GINPUT->KeyPress(DIK_RIGHT))
			vcPos.x +=1;

		if(GINPUT->KeyPress(DIK_UP))
			vcPos.z +=1;

		if(GINPUT->KeyPress(DIK_DOWN))
			vcPos.z -=1;

		if(GINPUT->KeyPress(DIK_ADD))
			vcPos.y +=1;

		if(GINPUT->KeyPress(DIK_SUBTRACT))
			vcPos.y -=1;

		pObj->SetPos(vcPos);
	}


//	if(GINPUT->KeyDown(DIK_C))
//		m_bCulling ^=1;



	SAFE_FRMOV(	m_pCamG		);
	SAFE_FRMOV(	m_pCamO		);

	SAFE_FRMOV(	m_pFld		);
	SAFE_FRMOV(	&m_WndWrk	);


	return S_OK;
}


HRESULT CMain::Render()
{
	if(m_bLoadingRnd)
		return 1;

	if(!GDEVICE)
		return -1;


	m_WndWrk.Render();


	if(m_bWindowed)
	{
		GDEVICE->SetRenderTarget(0, m_SwpWn.pB);
		GDEVICE->SetDepthStencilSurface(m_SwpWn.pS);
	}

	m_pCamG->SetTransForm();
	GDEVICE->SetViewport(&m_Vp);

	GDEVICE->Clear( 0, 0, GMAIN->GetDxClearMode(), 0x00006699, 1.0f, 0L );

	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;


	if(GMAIN->m_bMnCam)
		SAFE_RENDER( m_pCamG	);


	if(GMAIN->m_bMnSkydome)
	{
		static DOUBLE	angle =0;
		DWORD			dBgn = timeGetTime();

		D3DXMATRIX	mtR;
		D3DXMATRIX	mtW;

		VEC3		vcCam = m_pCamG->GetEye();

		angle += dBgn/2000000000.f;

		if( angle> 360.)
			angle -=360.;

		D3DXMatrixRotationY(&mtR, D3DXToRadian(angle));

		D3DXMatrixScaling( &mtW, 16, 10, 16);

		mtW *=mtR;

		mtW._41 = vcCam.x;
		mtW._42 = vcCam.y-3800;
		mtW._43 = vcCam.z;

		GDEVICE->SetTransform( D3DTS_WORLD, &mtW );
		GDEVICE->SetRenderState( D3DRS_LIGHTING,     FALSE );
		GDEVICE->SetTexture( 0, m_pSkyTexture );

		SAFE_RENDER(	m_pSkyDome	);
	}


	SAFE_RENDER(	m_pFld	);


	if(GMAIN->m_bMnFrame)
	{
		RECT rt={5,5, 800,20};
		GMAIN->m_pDxFnt->DrawText(GMAIN->m_sMsg, -1, &rt, 0, 0XFFFFFF00);
	}


	GDEVICE->EndScene();

	return S_OK;
}






LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	WPARAM	wparHi = HIWORD(wParam);
	WPARAM	wparLo = LOWORD(wParam);

	switch( msg )
	{
		case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				HDC hDC = GetDC( hWnd );
				ReleaseDC( hWnd, hDC );
			}
			break;
		}

		case WM_MOVE:
		{
			if(FALSE == m_bLoadingApp)
			{
				RECT rt1;
				RECT rt2;
				INT iWidth;
				INT iHeight;
				INT iX;
				INT iY;

				GetWindowRect(GHWND, &rt1);
				GetWindowRect(m_WndWrk.m_hWnd, &rt2);

				iWidth = rt2.right - rt2.left;
				iHeight=  rt2.bottom- rt2.top;

				iX = rt1.left - iWidth;
				iY = rt1.top;// + iHeight;

				MoveWindow(m_WndWrk.m_hWnd, iX, iY, iWidth, iHeight, TRUE);


			}

			break;
		}// case WM_MOVE


		case WM_COMMAND:
		{
			switch(wparLo)
			{
				case IDM_TOGGLEFULLSCREEN:
				{
					if(m_bWindowed)
					{
						ShowWindow(m_WndWrk.m_hWnd, SW_HIDE);

						if(m_WndWrk.m_WndLyr.m_bShow)
						{
							ShowWindow(m_WndWrk.m_WndLyr.m_hWnd, SW_HIDE);
						}
					}
					else
					{
						ShowWindow(m_WndWrk.m_hWnd, SW_SHOW);

						if(m_WndWrk.m_WndLyr.m_bShow)
						{
							ShowWindow(m_WndWrk.m_WndLyr.m_hWnd, SW_SHOW);
						}
					}


					break;
				}

				case IDM_NEW:
				{
					this->m_WndWrk.m_WndFog.Init();
					this->m_WndWrk.m_WndLght.Init();
					this->m_WndWrk.m_WndFld.Create(GHWND);
					this->m_WndWrk.m_WndFld.ShowWindow();

					break;
				}

				case IDM_OPEN:
				{
					if(GFIELD)
					{
						GFIELD->FileLoad();

						const CMpFld::MpEnv* pEnv = GFIELD->GetEnv();
						m_WndWrk.m_WndLght.m_iNl	= pEnv->m_iNl;				// Lighting Num

						memset(m_WndWrk.m_WndLght.m_pLg, 0, sizeof(m_WndWrk.m_WndLght.m_pLg));
						memcpy(m_WndWrk.m_WndLght.m_pLg, pEnv->m_pLg, m_WndWrk.m_WndLght.m_iNl* sizeof(DLGT));

						m_WndWrk.m_WndFog.m_dFt	=	pEnv->m_dFt;				// Fog Table Mode
						m_WndWrk.m_WndFog.m_dFc	=	pEnv->m_dFc;				// Fog Color
						m_WndWrk.m_WndFog.m_fFb	=	pEnv->m_fFb;				// Fog Begin
						m_WndWrk.m_WndFog.m_fFe	=	pEnv->m_fFe;				// Fog End
						m_WndWrk.m_WndFog.m_fFd	=	pEnv->m_fFd;				// Fog Density
					}

					break;
				}

				case IDM_SAVE:
				{
					if(GFIELD)
						GFIELD->FileSave();

					MessageBox(hWnd, "File Saved", "Msg", MB_OK);

					break;
				}

				case IDM_SOLID:
				{
					if( D3DFILL_SOLID == m_bMnFill)
						m_bMnFill = D3DFILL_WIREFRAME;

					else
						m_bMnFill = D3DFILL_SOLID;

					if( D3DFILL_SOLID == m_bMnFill)
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SOLID, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LGT:
				{
					m_bMnLgt ^=1;

					if(m_bMnLgt)
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LGT, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_FOG:
				{
					m_bMnFog ^=1;

					if(m_bMnFog)
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_FOG, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LINE_CAMERA:
				{
					m_bMnCam ^=1;

					if(m_bMnCam)
						CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LINE_CAMERA, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_LINE_LOCAL:
				{
					m_bMnLcl ^=1;

					if(m_bMnLcl)
						CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_LINE_LOCAL, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}


				case IDM_SHOW_FRAME:
				{
					m_bMnFrame ^=1;

					if(m_bMnFrame)
						CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_FRAME, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_SHOW_SKY:
				{
					m_bMnSkydome ^=1;

					if(m_bMnSkydome)
						CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_SKY, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}

				case IDM_SHOW_BNDBOX:
				{
					m_bMnBndBox ^=1;

					if(m_bMnBndBox)
						CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_SHOW_BNDBOX, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}


				case IDM_CULLING_FRUSTUM:
				{
					m_bCulling ^=1;

					if(m_bCulling)
						CheckMenuItem(m_hMenu, IDM_CULLING_FRUSTUM, MF_BYCOMMAND | MF_CHECKED);
					else
						CheckMenuItem(m_hMenu, IDM_CULLING_FRUSTUM, MF_BYCOMMAND | MF_UNCHECKED);

					break;
				}


				case IDM_HELP:
				{
					if(IDOK == DialogBox( GetModuleHandle(NULL), MAKEINTRESOURCE(IDD_HELP),	hWnd, CMain::AboutPrc))
					{
					}

					break;
				}

			}

			break;

		}// case WM_COMMAND

	}

	return CD3DApplication::MsgProc( hWnd, msg, wParam, lParam );
}



BOOL WINAPI CMain::AboutPrc(HWND hDlg,UINT nMsg,WPARAM wParam,LPARAM lParam)
{
	switch(nMsg)
	{
		case WM_INITDIALOG:
		{
			RECT rt1;
			RECT rt2;

			INT iWidth;
			INT iHeight;

			INT iX;
			INT iY;


			GetWindowRect(GHWND, &rt1);
			GetWindowRect(hDlg, &rt2);

			iWidth = rt2.right - rt2.left;
			iHeight=  rt2.bottom- rt2.top;

			iX = rt1.left + 100;
			iY = rt1.top + 100;

			MoveWindow(hDlg, iX, iY, iWidth, iHeight, TRUE);

			return TRUE;
		}

		case WM_COMMAND:
		{
			switch (wParam)
			{
				case IDC_HELP_CLOSE:
				{
					EndDialog(hDlg,IDOK);

					return TRUE;
				}

			}

			break;
		}
	}

	return FALSE;
}

