// Interface for the CWndFog class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _WNDFOG_H_
#define _WNDFOG_H_

class CWndFog
{
public:
	HWND		m_hWnd		;
	HWND		m_hWPrn		;

public:
	HWND		m_hWfc		;

	DWORD		m_dFt		;													// Fog Table Mode
	DWORD		m_dFc		;													// Fog Color
	FLOAT		m_fFb		;													// Fog Begin
	FLOAT		m_fFe		;													// Fog End
	FLOAT		m_fFd		;													// Fog Density

	COLORREF	m_crT[32];

public:
	CLSS_DLG_DECLEAR( CWndFog );

	INT		Init();
	void	Destroy();

	INT		Create(HWND hWnd);
	LRESULT	MsgPrc(HWND, UINT, WPARAM, LPARAM);
	
	void	ShowWindow(int _ishw = SW_SHOW);

	

	DWORD	GetFogTable()	{	return	m_dFt	;	}
	DWORD	GetFogColor()	{	return	m_dFc	;	}
	FLOAT	GetFogBegin()	{	return	m_fFb	;	}
	FLOAT	GetFogEnd  ()	{	return	m_fFe	;	}
	FLOAT	GetFogDns  ()	{	return	m_fFd	;	}

protected:
	void	SetPickColor(DWORD&	clrOut,DWORD& clrIn,INT nID, BOOL IsBGR=FALSE);
	void	OnChangeColor(HWND hWnd, INT nID);
};

#endif