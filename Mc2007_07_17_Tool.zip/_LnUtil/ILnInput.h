// Interface for the ILnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnInput_H_
#define _ILnInput_H_


#ifndef interface
#define interface struct
#endif


#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}


interface ILnInput
{
	LN_CLASS_DESTROYER(	ILnInput	);
	
	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual void	Destroy()=0;

	virtual INT		FrameMove()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;


	virtual BYTE*	GetKeyMap()	const=0;

	virtual BOOL	KeyDown(INT nKey)=0;
	virtual BOOL	KeyUp(INT nKey)=0;
	virtual BOOL	KeyPress(INT nKey)=0;
	virtual BOOL	KeyState(int nKey)=0;

	virtual BOOL	ButtonDown(INT nBtn)=0;
	virtual BOOL	ButtonUp(INT nBtn)=0;
	virtual BOOL	ButtonPress(INT nBtn)=0;
	virtual BOOL	ButtonState(int nBtn)=0;

	virtual FLOAT*	GetMousePos()=0;
	virtual FLOAT*	GetMouseDelta()=0;
	virtual BOOL	GetMouseMove()=0;

	virtual BOOL	IsInRect(INT left, INT top, INT right, INT bottom)=0;
};


INT LnInput_Create(char* sCmd
				 , ILnInput** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2=NULL	// HINSTANCE
				 , void* p3=NULL	// HWND
				 , void* p4=NULL	// No Use
				 );


#endif


