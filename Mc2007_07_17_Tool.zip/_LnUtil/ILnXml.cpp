// Implementation of the ILnXml class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "ILnXml.h"
#include "LnXml.h"


INT LnXml_Create(char* sCmd
				 , ILnXml** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2			// Source Mesh
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{
	CLnXml*	pxmObj = new CLnXml;


	if(FAILED(pxmObj->Create(p1, p2, p3, p4)))
	{
		delete pxmObj;
		return -1;
	}

	(*pData) = pxmObj;

	return 1;
}