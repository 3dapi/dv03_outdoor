// Interface for the ILnXml class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnXml_H_
#define _ILnXml_H_


#pragma warning( disable : 4786)
#include <vector>


#ifndef interface
#define interface struct
#endif


#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}


interface ILnXml
{
	LN_CLASS_DESTROYER(	ILnXml	);
	
	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;
	
	virtual INT		FileLoad(const char* sFile)=0;


	virtual void*	ElmList(const char* sElm, void* pNodeParent)=0;
	virtual void*	ElmNode(void* pNode, INT nIdx)=0;
	virtual INT		ElmSize(void* pNode)=0;
	virtual INT		ElmText(char* sOutput, void* pNode)=0;
	virtual INT		ElmAttrb(char* sOutput, int sOutputSize, void* pNode, const char* sAttName)=0;
};

INT LnXml_Create(char* sCmd
				 , ILnXml** pData
				 , void* p1=NULL	// No Use
				 , void* p2=NULL	// No Use
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


typedef std::vector<ILnXml* >	lsLnXml;
typedef lsLnXml::iterator		itLnXml;

#endif


