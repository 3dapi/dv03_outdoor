// Interface for the CLnDxMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LNDXMSH_H_
#define _LNDXMSH_H_


class CLnDxMsh : public ILnXmsh
{
protected:
	LPDIRECT3DDEVICE9		m_pDev;

	char					m_sFile[MAX_PATH];
	LPD3DXMESH				m_pMshSys;			// SysMem mesh, lives through resize
	LPD3DXMESH				m_pMshLcl;			// Local mesh, rebuilt on resize

	DWORD					m_dMtrl;			// Materials Number
	D3DMATERIAL9*			m_pMtrl;
	LPDIRECT3DTEXTURE9*		m_pTxs;
	BOOL					m_bMtrl;

	bool					m_bDrawOpaqueSubsets;
	bool					m_bDrawAlphaSubsets;

public:
	CLnDxMsh();
	virtual ~CLnDxMsh();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Query(char* sCmd, void* pData);

	virtual INT		Restore();
	virtual void	Invalidate();

	virtual void	SetFVF(DWORD dFVF);
	virtual void	UseMaterial(bool bVal);
};



#endif


