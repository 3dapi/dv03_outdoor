// Interface for the CLnInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LnInput_H_
#define _LnInput_H_


class CLnInput : public ILnInput
{
public:
	enum	EInputState
	{
		INPUTST_NONE	=0,
		INPUTST_DOWN	=1,
		INPUTST_UP		=2,
		INPUTST_PRESS	=3,
	};

protected:
	HINSTANCE				m_hInst		;
	HWND					m_hWnd		;
	PDEV					m_pDev		;

	LPDIRECTINPUT8			m_pDInput	;
	LPDIRECTINPUTDEVICE8	m_pDiKey	;
	LPDIRECTINPUTDEVICE8	m_pDiMs		;

	DIMOUSESTATE2			m_MsStCur	;
	DIMOUSESTATE2			m_MsStOld	;

	BYTE					m_KeyCur[256];										// Current Keyboard
	BYTE					m_KeyOld[256];										// Old Keyboard
	BYTE					m_KeyMap[256];										// Key Map down: 1, up: 2, Press 3

	BYTE					m_BtnCur[8]	;										// Current Button
	BYTE					m_BtnOld[8]	;										// Old Bttton
	BYTE					m_BtnMap[8]	;										// Button Map down: 1, up: 2, Press 3 

	VEC3					m_vcMsCur	;										// Mouse Current Position
	VEC3					m_vcMsOld	;										// Mouse Old Position
	VEC3					m_vcDelta	;										// Delta Mouse Position


public:
	CLnInput();
	virtual ~CLnInput();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();

	virtual INT		Query(char* sCmd, void* pData);


	virtual BYTE*	GetKeyMap()	const;

	virtual BOOL	KeyDown(INT nKey);
	virtual BOOL	KeyUp(INT nKey);
	virtual BOOL	KeyPress(INT nKey);
	virtual BOOL	KeyState(INT nKey);

	virtual BOOL	ButtonDown(INT nBtn);
	virtual BOOL	ButtonUp(INT nBtn);
	virtual BOOL	ButtonPress(INT nBtn);
	virtual BOOL	ButtonState(INT nBtn);

	virtual FLOAT*	GetMousePos();
	virtual FLOAT*	GetMouseDelta();
	virtual BOOL	GetMouseMove();

	virtual BOOL	IsInRect(INT left, INT top, INT right, INT bottom);
	
protected:
	INT		InitDInput();
	INT		UpdateDInput();
};

#endif