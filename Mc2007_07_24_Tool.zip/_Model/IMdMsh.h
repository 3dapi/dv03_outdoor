// Interface for the IMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _IMdMsh_H_
#define _IMdMsh_H_


#pragma warning( disable : 4786)
#include <vector>


#ifndef interface
#define interface struct
#endif


#ifndef LN_CLASS_DESTROYER
#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface IMdMsh
{
	LN_CLASS_DESTROYER(	IMdMsh	);

	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;

	virtual INT		GetType()		=0;											// Mesh Type, Billboard ,solid, etc.
	virtual INT		GetNumFce()		=0;											// Count Vertex Index
	virtual	INT		GetNumVtx()		=0;											// Count Vertex
	virtual	DWORD	GetFVF()		=0;											// Flexible vertex Format
	virtual	INT		GetZeroStrd()	=0;											// Zero Stride size

	virtual	void*	GetBufFce()		=0;											// Get Index Pointer
	virtual	void*	GetBufVtx()		=0;											// Get Vertex Pointer
	

	virtual	char*	GetTxName()		=0;											// Get Texture Name
	virtual	void	SetTxName(char*)=0;											// Set Texture Name

	virtual	void*	GetTx()			=0;											// Tet Texture Point
	virtual	void	SetTx(void*)	=0;											// Set Texture Point
	
	
	virtual INT		Load(char*)		=0;
	virtual void	Copy(IMdMsh*)	=0;

	virtual void	SetMdlName(char*)=0;
	virtual char*	GetMdlName()	=0;

	virtual void*	GetDev()		=0;
	virtual void*	GetBndInf()		=0;
};


INT LnMdl_CreateMsh(char* sCmd
				 , IMdMsh** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2=NULL	// Source Mesh
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


typedef std::vector<IMdMsh* >		lsMdMsh;
typedef lsMdMsh::iterator			itMdMsh;


#endif


