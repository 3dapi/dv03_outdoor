// Interface for the CLnMd class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MDOBJ_H_
#define _MDOBJ_H_


class CMdBill : public CMdBase
{
public:
	DCLR		m_dC;															// Color

public:
	CMdBill();
	virtual ~CMdBill();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();
	
	virtual	INT		FrameMove();
	virtual	void	Render();

public:
	void			SetColor(DWORD dc)		{	m_dC= dc;			}
};



class CMdSolid : public CMdBase
{
public:
	CMdSolid();
	virtual ~CMdSolid();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();
};



#endif

