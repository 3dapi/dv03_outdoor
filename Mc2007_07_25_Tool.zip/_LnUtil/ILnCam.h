// Interface for the ILnCam class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILnCam_H_
#define _ILnCam_H_


#pragma warning( disable : 4786)
#include <vector>


#ifndef interface
#define interface struct
#endif


#ifndef LN_CLASS_DESTROYER
#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILnCam
{
	LN_CLASS_DESTROYER(	ILnCam	);
	
	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

	virtual	INT		SetInit();
	virtual	INT		Restore();

	virtual	char*	GetName()				;
	virtual	void	SetName(char* sN)		;

	virtual	D3DXMATRIX	GetMatrixViw()		;
	virtual	D3DXMATRIX	GetMatrixViwI()		;
	virtual	D3DXMATRIX	GetMatrixBll()		;
	virtual	D3DXMATRIX	GetMatrixPrj()		;
	virtual	D3DXMATRIX	GetMatrixViwPrj()	;
	virtual	D3DXPLANE*	GetFrustum()		;

	virtual	D3DXVECTOR3	GetEye()			;
	virtual	D3DXVECTOR3	GetLook()			;
	virtual	D3DXVECTOR3	GetUp()				;

	virtual	void		SetPos(D3DXVECTOR3)	;
	virtual	void		SetLook(D3DXVECTOR3);
	virtual	void		SetUp(D3DXVECTOR3)	;

	virtual	FLOAT		GetNear()			;
    virtual	FLOAT		GetFar()			;
	virtual	void		SetNear(FLOAT fNr)	;
	virtual	void		SetFar(FLOAT  fFr)	;

	virtual	FLOAT		GetFov()			;
    virtual	FLOAT		GetApc()			;
	virtual	void		SetFov(FLOAT fFOV)	;
	
	virtual	D3DXVECTOR3	Get3DDir(POINT*)	;
	virtual	D3DXVECTOR3	GetX()				;
	virtual	D3DXVECTOR3	GetY()				;
	virtual	D3DXVECTOR3	GetZ()				;

	virtual	void		SetTransForm()		;


	// Individual Camera
	virtual	void	SetMatrixViw(D3DXMATRIX);
	virtual	void	SetMatrixPrj(D3DXMATRIX);
	virtual	INT		Update();
	
	virtual	void	MoveForward	(FLOAT fSpd, FLOAT fY=0);
	virtual	void	MoveSideward(FLOAT fSpd);
	virtual	void	MoveX(FLOAT	fSpd)		;
	virtual	void	MoveZ(FLOAT	fSpd)		;

	virtual	void	MoveRotate(FLOAT fYaw, FLOAT fPitch);
};


INT LnCam_Create(char* sCmd
				 , ILnCam** pData
				 , void* p1=NULL	// LPDIRECT3DDEVICE9
				 , void* p2=NULL	// ScreenWidth and Heigt Float Array
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


#endif


