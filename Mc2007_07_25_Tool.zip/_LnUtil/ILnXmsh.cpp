// Implementation of the CLnDxMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "ILnXmsh.h"
#include "LnD3DFile.h"



INT LnXmsh_Create(char* sCmd
				 , ILnXmsh** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2			// X-file Name
				 , void* p3			// No Use
				 , void* p4			// No Use
				 )
{

	(*pData) = NULL;

	CLnDxMsh* pObj = NULL;

	pObj = new CLnDxMsh;

	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		// Return Error Notification
		delete pObj;
		return -1;
	}

	(*pData) = pObj;
	
	return 0;
}