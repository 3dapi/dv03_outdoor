// Interface for the ILnXmsh class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _ILnXmsh_H_
#define _ILnXmsh_H_


#pragma warning( disable : 4786)
#include <vector>


#ifndef interface
#define interface struct
#endif


#ifndef LN_CLASS_DESTROYER
#define LN_CLASS_DESTROYER( CLASS_NAME )	\
virtual ~CLASS_NAME(){}
#endif


interface ILnXmsh
{
	LN_CLASS_DESTROYER(	ILnXmsh	);

	virtual	INT		Create(void* p1=NULL /*Device*/, void* p2=NULL /*X File Name*/, void* p3=NULL, void* p4=NULL)=0;
	virtual	void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual	void	Render()=0;

	virtual INT		Query(char* sCmd, void* pData)=0;

	virtual INT		Restore()=0;
	virtual void	Invalidate()=0;

	virtual void	SetFVF(DWORD dFVF)=0;
	virtual void	UseMaterial(bool bVal)=0;
};


INT LnXmsh_Create(char* sCmd
				 , ILnXmsh** pData
				 , void* p1			// LPDIRECT3DDEVICE9
				 , void* p2			// X-file Name
				 , void* p3=NULL	// No Use
				 , void* p4=NULL	// No Use
				 );


typedef std::vector<ILnXmsh* >		lsLnXmsh;
typedef lsLnXmsh::iterator			itLnXmsh;


#endif


