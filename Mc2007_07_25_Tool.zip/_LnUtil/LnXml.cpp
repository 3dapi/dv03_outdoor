// Implementation of the CLnXml class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include <msxml2.h>
#include <comdef.h>

//#import <msxml4.dll> raw_interfaces_only
//using namespace MSXML2;


#include "ILnXml.h"
#include "LnXml.h"


#ifndef SAFE_RELEASE
#define SAFE_RELEASE(p)	{	if( p ){	(p)->Release();	(p) = NULL;	} 	}
#endif

CLnXml::CLnXml()
{
	m_pxmlDoc = NULL;
	m_bCoInit	= -1;		// S_OK, S_FALSE, -1
							// S_OK: the COM library was initialized successfully.
							// S_FALSE: the COM library is already initialized.
}


CLnXml::~CLnXml()
{
	Destroy();
}


void CLnXml::Destroy()
{
	if(S_OK== m_bCoInit)
		CoUninitialize();
}



INT CLnXml::Create(void* p1, void* p2, void* p3, void* p4)
{
	HRESULT	hr=-1;
	IXMLDOMDocument* pxmDoc = NULL;

	m_bCoInit = CoInitialize(NULL);

	hr = CoCreateInstance(	__uuidof(DOMDocument40)
						,	NULL
						,	CLSCTX_INPROC_SERVER
						,	__uuidof(IXMLDOMDocument)
						,	(void**)&pxmDoc);

	
	if(FAILED(hr))
	{
		hr = CoCreateInstance(	__uuidof(DOMDocument30)
						,	NULL
						,	CLSCTX_INPROC_SERVER
						,	__uuidof(IXMLDOMDocument)
						,	(void**)&pxmDoc);

		if(FAILED(hr))
		{
			hr = CoCreateInstance(CLSID_DOMDocument
							,	NULL
							,	CLSCTX_ALL
							,	IID_IXMLDOMDocument
							,	(void**)&pxmDoc);

			if(FAILED(hr))
			{
				SAFE_RELEASE(	pxmDoc	);
				return hr;
			}
		}
	}

	hr = pxmDoc->put_async(VARIANT_FALSE);
	hr = pxmDoc->put_validateOnParse(VARIANT_FALSE);
	hr = pxmDoc->put_resolveExternals(VARIANT_FALSE);

	m_pxmlDoc = pxmDoc;
	
	return hr;
}


INT CLnXml::FileLoad(const char* sFile)
{
	HRESULT	hr=-1;
	IXMLDOMDocument* pxmDoc = (IXMLDOMDocument*)m_pxmlDoc;

	try
	{
		FILE* fp = fopen(sFile, "r");

		if(!fp)
			return -1;

		fclose(fp);

		SHORT iR = FALSE;

		_bstr_t varString = (const char*)sFile;
		VARIANT path;
		path.vt = VT_BSTR;
		path.bstrVal = varString;

		hr = pxmDoc->load(path, &iR);
	}
	catch (...)
	{
		return -1;
	}

	return hr;
}


void* CLnXml::ElmList(const char* sElm, void* pNode)
{
	IXMLDOMNodeList* pxmLst	= NULL;
		
	_bstr_t bstrPath = sElm;

	try 
	{
		IXMLDOMNode*	 pxmNode = NULL;
		pxmNode = (pNode)? (IXMLDOMNode*)pNode:(IXMLDOMDocument*)m_pxmlDoc;
		pxmNode->selectNodes(bstrPath, &pxmLst);
	}
	catch(...)
	{
		return NULL;
	}

	return pxmLst;
}


void* CLnXml::ElmNode(void* pNode, INT nIdx)
{
	IXMLDOMNodeList*	pxmLst = NULL;
	IXMLDOMNode*		pxmNod = NULL;

	pxmLst = (IXMLDOMNodeList*)pNode;

	if(!pxmLst)
		return NULL;

	try
	{ 
		pxmLst->get_item(nIdx, &pxmNod);
	}
	catch(...)
	{
		return NULL;
	}

	return pxmNod;
}


INT CLnXml::ElmSize(void* pNode)
{
	HRESULT	hr=-1;
	IXMLDOMNodeList* pxmLst = (IXMLDOMNodeList*)pNode;
	long	nCount=0;

	
	if(!pxmLst)
		return -1;

	try
	{ 
		hr = pxmLst->get_length(&nCount);
	}
	catch(...)
	{
		return -1;
	}

	return nCount;
}



INT	CLnXml::ElmText(char* sOutput, void* pNode)
{
	IXMLDOMNode* pxmNode = (IXMLDOMNode*)pNode;
	BSTR	bstr = NULL;

	try
	{ 
		pxmNode->get_text(&bstr);
		strcpy(sOutput,(const char*)_bstr_t(bstr,FALSE));
	}
	catch(...)
	{
		return -1;
	}

	return 1;
}

INT CLnXml::ElmAttrb(char* sOutput, int sOutputSize, void* pNode, const char* sAttName)
{
	IXMLDOMNode*			pxmNode	= (IXMLDOMNode*)pNode;
	IXMLDOMNode*			pAttNod = NULL;
	IXMLDOMNamedNodeMap*	pxmMap	= NULL;

	wchar_t					wstrAttr[2048]={0};
	VARIANT					varValue;

	try
	{ 
		INT n = mbstowcs(wstrAttr, sAttName, sOutputSize);
		pxmNode->get_attributes(&pxmMap);
		pxmMap->getNamedItem(wstrAttr, &pAttNod);
		pAttNod->get_nodeValue(&varValue);

		strcpy(sOutput,(const char*)_bstr_t(varValue.bstrVal, FALSE));
	}
	catch(...)
	{
		SAFE_RELEASE(	pAttNod	);
		SAFE_RELEASE(	pxmMap	);

		return -1;
	}

	SAFE_RELEASE(	pAttNod	);
	SAFE_RELEASE(	pxmMap	);

	return 1;
}


