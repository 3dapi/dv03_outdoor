// Implementation of the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <d3d9.h>
#include <d3dx9.h>

#include "../LnInclude/LnType.h"
#include "../LnInclude/LnVtxFmt.h"
#include "../LnInclude/LnUtil.h"

#include "IMdMsh.h"
#include "MdMsh.h"


CMdMsh::CMdMsh()
:	m_iNix	(0)	
,	m_iNvx	(0)
,	m_dFVF	(0)
,	m_iVxS	(0)
,	m_pIdx	(0)
,	m_pVtx	(0)
{
	m_pTx	= NULL;
	m_pDev	= NULL;

	memset(m_sMd, 0, sizeof(m_sMd));
	memset(m_sTx, 0, sizeof(m_sTx));

	m_BndInf.SetColor(0xFF666666);
}


CMdMsh::~CMdMsh()
{
	Destroy();
}

void CMdMsh::Destroy()
{
	SAFE_FREE(	m_pIdx	);
	SAFE_FREE(	m_pVtx	);
}


INT CMdMsh::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (PDEV)p1;

	return 1;
}


INT CMdMsh::FrameMove()
{
	return 1;
}


void CMdMsh::Render()
{
	m_pDev->SetTexture(0, m_pTx);
	
	m_pDev->SetFVF(m_dFVF);
	m_pDev->DrawIndexedPrimitiveUP(
		D3DPT_TRIANGLELIST, 0
		, m_iNvx, m_iNix
		, m_pIdx, D3DFMT_INDEX16
		, m_pVtx, m_iVxS);

//	m_pDev->SetRenderState(D3DRS_ALPHATESTENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);
//	m_pDev->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
//
//	m_BndInf.RenderBox(m_pDev);
}



INT CMdMsh::Query(char* sCmd, void* pData)
{
	return -1;
}



INT CMdMsh::GetType()
{
	return m_nType;
}

INT CMdMsh::GetNumFce()
{
	return m_iNix;
}
INT CMdMsh::GetNumVtx()
{
	return m_iNvx;
}

DWORD CMdMsh::GetFVF()
{
	return m_dFVF;
}

INT	CMdMsh::GetZeroStrd()
{
	return m_iVxS;
}


void* CMdMsh::GetBufFce()
{
	return m_pIdx;
}


void* CMdMsh::GetBufVtx()
{
	return m_pVtx;
}


char* CMdMsh::GetTxName()
{
	return m_sTx;
}


void CMdMsh::SetTxName(char* sTx)
{
	strcpy(m_sTx, sTx);
}


void* CMdMsh::GetTx()
{
	return m_pTx;
}

void CMdMsh::SetTx(void* pTx)
{
	m_pTx = (PDTX)pTx;
}





INT CMdMsh::Load(char* sFile)
{
	INT		i=0;
	char	sTmp[512];

	GetPrivateProfileString("Header", "nType", NULL, sTmp, sizeof(sTmp), sFile);
	m_nType = atoi(sTmp);

	GetPrivateProfileString("Header", "dFvf", NULL, sTmp, sizeof(sTmp), sFile);
	m_dFVF = atol(sTmp);

	GetPrivateProfileString("Header", "iVcS", NULL, sTmp, sizeof(sTmp), sFile);
	m_iVxS= atoi(sTmp);

	GetPrivateProfileString("Header", "iNfce", NULL, sTmp, sizeof(sTmp), sFile);
	m_iNix = atoi(sTmp);

	GetPrivateProfileString("Header", "iNvtx", NULL, sTmp, sizeof(sTmp), sFile);
	m_iNvx = atoi(sTmp);


	GetPrivateProfileString("Header", "Texture", NULL, sTmp, sizeof(sTmp), sFile);
	strcpy(m_sTx, sTmp);

	if(0 == m_iNix || 0 == m_iNvx)
		return -1;

	m_pIdx = (VtxIdx*) malloc(m_iNix * sizeof(VtxIdx));
	m_pVtx = malloc(m_iNvx * m_iVxS);

	for(i=0; i<m_iNix; ++i)
	{
		VtxIdx	idx;
		GetPrivateProfileString("Idx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);
		sscanf(sTmp, "%d %d %d", &idx.a, &idx.b, &idx.c);

		m_pIdx[i] = idx;
	}

	if( VtxDUV1::FVF == m_dFVF)
	{
		for(i=0; i<m_iNvx; ++i)
		{
			VtxDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			((VtxDUV1*)m_pVtx)[i] = tVtx;
		}
	}

	else if(VtxNDUV1::FVF == m_dFVF)
	{
		for(i=0; i<m_iNvx; ++i)
		{
			VtxNDUV1	tVtx;
			GetPrivateProfileString("Vtx", LnStr_Format("%d", i), NULL, sTmp, sizeof(sTmp), sFile);

			sscanf(sTmp, "%f %f %f   %f %f %f  %f %f %x"
				, &tVtx.p.x, &tVtx.p.y, &tVtx.p.z
				, &tVtx.n.x, &tVtx.n.y, &tVtx.n.z
				, &tVtx.u, &tVtx.v
				, &tVtx.d
				);

			tVtx.p *= 0.4f;
			((VtxNDUV1*)m_pVtx)[i] = tVtx;
		}
	}


	D3DXVECTOR3 vcMin;
	D3DXVECTOR3 vcMax;

	// Set Max and Min vertex Position
	D3DXComputeBoundingBox(	(D3DXVECTOR3*)m_pVtx
							, m_iNvx
							, D3DXGetFVFVertexSize( m_dFVF)
							, &vcMin
							, &vcMax);

	m_BndInf.Set(vcMin, vcMax);

	return 1;
}



void CMdMsh::Copy(IMdMsh* pRhs)
{
	strcpy(m_sMd, pRhs->GetMdlName());
	strcpy(m_sTx, pRhs->GetTxName());

	this->m_nType= pRhs->GetType();
	this->m_iNix = pRhs->GetNumFce();
	this->m_iNvx = pRhs->GetNumVtx();

	this->m_dFVF = pRhs->GetFVF();
	this->m_iVxS = pRhs->GetZeroStrd();

	memcpy(&this->m_BndInf, pRhs->GetBndInf(), sizeof m_BndInf);

	m_pIdx	= (VtxIdx*) malloc(m_iNix * sizeof(VtxIdx));
	m_pVtx	= malloc(m_iNvx * m_iVxS);

	memcpy(m_pIdx, pRhs->GetBufFce(), m_iNix * sizeof(VtxIdx));
	memcpy(m_pVtx, pRhs->GetBufVtx(), m_iNvx * m_iVxS);
	
	this->m_pTx = (PDTX)pRhs->GetTx();
}



void* CMdMsh::GetDev()
{
	return m_pDev;
}


void* CMdMsh::GetBndInf()
{
	return (void*)&m_BndInf;
}