// Interface for the CMdMsh class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdMsh_H_
#define _MdMsh_H_


class CMdMsh : public IMdMsh													// For Rendering
{
public:
	PDEV		m_pDev;
	INT			m_nType;														// Model Type

	char		m_sTx[128];
	PDTX		m_pTx;

	char		m_sMd[128];

	INT			m_iNix	;														// Count Vertex Index
	INT			m_iNvx	;														// Count Vertex

	DWORD		m_dFVF	;														// FVF
	INT			m_iVxS	;														// vertex structure size

	TBndAABB	m_BndInf;

	VtxIdx*		m_pIdx	;														// Vertex Face Index
	void*		m_pVtx	;														//	VtxD, VtxUV, VtxNUV, VtxNDUV	

public:
	CMdMsh();
	virtual ~CMdMsh();

	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual	void	Destroy();

	virtual	INT		FrameMove();
	virtual	void	Render();

	virtual INT		Query(char* sCmd, void* pData);


	virtual INT		GetType()		;											// Mesh Type, Billboard ,solid, etc.
	virtual INT		GetNumFce()		;											// Count Vertex Index
	virtual	INT		GetNumVtx()		;											// Count Vertex
	virtual	DWORD	GetFVF()		;											// Flexible vertex Format
	virtual	INT		GetZeroStrd()	;											// Zero Stride size

	virtual	void*	GetBufFce()		;											// Get Index Pointer
	virtual	void*	GetBufVtx()		;											// Get Vertex Pointer
	

	virtual	char*	GetTxName()		;											// Get Texture Name
	virtual	void	SetTxName(char*);											// Set Texture Name

	virtual	void*	GetTx()			;											// Tet Texture Point
	virtual	void	SetTx(void*)	;											// Set Texture Point


	virtual	INT		Load(char* sFile);
	virtual	void	Copy(IMdMsh* pRhs);

public:
	virtual	void	SetMdlName(char* sMdl)	{	strcpy(m_sMd, sMdl);	}
	virtual	char*	GetMdlName()			{	return m_sMd;			}

	virtual	void*	GetDev()			;
	virtual	void*	GetBndInf()			;
};

#endif