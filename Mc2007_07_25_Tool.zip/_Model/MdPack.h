// Interface for the CMdPack class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MdPack_H_
#define _MdPack_H_


class CMdPack : public ILnMdPack
{
public:
	PDEV		m_pDev;
	
	void*		m_pLcl;
	lsLnMdl		m_vObj;

public:
	CMdPack();
	virtual ~CMdPack();
	
	virtual	INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		Query(char* sCmd, void* pData);

	virtual void		SetLcl(void* pLcl);
	virtual void		AddObj(ILnMdl* pMdB
							, VEC3 vcP		// Position
							, void* p1		// Camera
							, void* p2		// Field
							, void* p3		// Field Local
							, void* p4		// Parent Package
							);

	virtual	void		Push_Back(ILnMdl* pMdB);
	virtual	INT			Size();
	virtual	ILnMdl*		GetObj(int n);
	virtual	void		Erase(int n);
};


#endif
